export const CATEGORIES = [
  "Fridges",
  "Stoves & ovens",
  "Washing machines",
  "TVs",
  "Microwaves",
  "Freezers",
  "Dishwashers",
  "Tumble dryers",
  "Small appliances",
  "Other",
] as const;

export const CONDITIONS = [
  "Excellent",
  "Good",
  "Fair",
  "Spares or repair",
] as const;

export const CONDITION_BLURB: Record<string, string> = {
  Excellent: "Looks and works like new. Hardly a mark on it.",
  Good: "Works well. Small marks you would expect on a used appliance.",
  Fair: "Works, but it shows its age — priced for it.",
  "Spares or repair": "Sold as it is, for parts or for repair. No guarantee.",
};

/** Spec rows the owner most often needs, offered per category. */
export const SPEC_SUGGESTIONS: Record<string, string[]> = {
  Fridges: ["Capacity", "Doors", "Colour", "Age"],
  "Stoves & ovens": ["Plates", "Oven", "Width", "Power"],
  "Washing machines": ["Load", "Type", "Spin", "Age"],
  TVs: ["Screen size", "Smart", "Remote", "Ports"],
  Microwaves: ["Capacity", "Power", "Turntable", "Finish"],
  Freezers: ["Capacity", "Type", "Baskets", "Age"],
  Dishwashers: ["Place settings", "Programmes", "Finish", "Age"],
  "Tumble dryers": ["Load", "Type", "Heat settings", "Age"],
  "Small appliances": ["Type", "Power", "Age"],
  Other: ["Type", "Size", "Age"],
};

/** Example answers, so the value box never looks like it wants a litre count. */
export const SPEC_HINTS: Record<string, string> = {
  Capacity: "235 litres",
  Doors: "2 (fridge + freezer)",
  Colour: "Silver",
  Age: "About 3 years",
  Plates: "4 solid",
  Oven: "Yes, with grill",
  Width: "600mm",
  Power: "1000W",
  Load: "7 kg",
  Type: "Front loader",
  Spin: "1200 rpm",
  "Screen size": "50 inch",
  Smart: "Yes — WiFi, apps",
  Remote: "Included",
  Ports: "3 x HDMI",
  Turntable: "Yes",
  Finish: "Stainless steel",
  Baskets: "1 included",
  "Place settings": "12",
  Programmes: "5",
  "Heat settings": "2",
  Size: "600mm wide",
};

export type ShopSettings = {
  shopName: string;
  tagline: string;
  town: string;
  address?: string;
  phoneDisplay: string;
  phoneDial: string;
  whatsapp: string;
  hours: string;
  deliveryFee: number;
  deliveryNote: string;
  warrantyDays: number;
};

export function waLink(whatsapp: string, message: string) {
  return `https://wa.me/${whatsapp}?text=${encodeURIComponent(message)}`;
}

export function rands(amount: number) {
  return `R${Math.round(amount).toLocaleString("en-ZA")}`;
}

export function daysOld(createdAt: number) {
  return Math.max(0, Math.floor((Date.now() - createdAt) / 86400000));
}

export function todayStamp() {
  return new Date().toLocaleDateString("en-ZA", {
    day: "2-digit",
    month: "short",
    year: "numeric",
  });
}
