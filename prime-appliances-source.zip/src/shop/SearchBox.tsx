import { useEffect, useRef, useState } from "react";

const PHRASES = [
  "Search a fridge…",
  "Search a stove, a washing machine…",
  "Search 50 inch, Defy, 235 litre…",
  "Search a microwave…",
];

export function SearchBox({
  value,
  onChange,
}: {
  value: string;
  onChange: (v: string) => void;
}) {
  const [placeholder, setPlaceholder] = useState("");
  const state = useRef({ phrase: 0, char: 0, deleting: false });

  useEffect(() => {
    if (value) return;
    let timer: ReturnType<typeof setTimeout>;
    const tick = () => {
      const s = state.current;
      const full = PHRASES[s.phrase];
      if (!s.deleting) {
        s.char++;
        if (s.char >= full.length) {
          s.deleting = true;
          timer = setTimeout(tick, 1600);
          setPlaceholder(full);
          return;
        }
      } else {
        s.char--;
        if (s.char <= 0) {
          s.deleting = false;
          s.phrase = (s.phrase + 1) % PHRASES.length;
        }
      }
      setPlaceholder(full.slice(0, s.char));
      timer = setTimeout(tick, s.deleting ? 35 : 65);
    };
    timer = setTimeout(tick, 400);
    return () => clearTimeout(timer);
  }, [value]);

  return (
    <div className="flex items-stretch overflow-hidden rounded-full bg-white shadow-md ring-1 ring-black/5 focus-within:ring-2 focus-within:ring-[#e0622a]">
      <input
        value={value}
        onChange={e => onChange(e.target.value)}
        placeholder={value ? "" : placeholder || "Search…"}
        aria-label="Search appliances"
        className="min-w-0 flex-1 bg-transparent px-4 py-3 text-[15px] outline-none placeholder:text-neutral-400 sm:px-5"
      />
      {value && (
        <button
          type="button"
          aria-label="Clear search"
          onClick={() => onChange("")}
          className="shrink-0 px-2 text-xl leading-none text-neutral-400 transition hover:text-neutral-700"
        >
          ×
        </button>
      )}
      <button
        type="button"
        className="m-1 shrink-0 rounded-full bg-[#e0622a] px-5 text-sm font-bold text-white transition active:scale-95 sm:px-7"
      >
        Search
      </button>
    </div>
  );
}
