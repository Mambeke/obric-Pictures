import { useEffect, useState } from "react";
import { useNavigate } from "react-router";
import { useCart } from "./CartContext";
import { CartIcon, SearchIcon, WhatsAppIcon } from "./icons";
import { cartMessage, money, type Settings, waLink } from "./lib";

export function useBodyClass(cls: string) {
  useEffect(() => {
    document.body.classList.add(cls);
    return () => document.body.classList.remove(cls);
  }, [cls]);
}

export function ShopHeader({
  settings,
  search,
}: {
  settings: Settings;
  search?: {
    term: string;
    setTerm: (t: string) => void;
    placeholder: string;
    run: () => void;
  };
}) {
  const nav = useNavigate();
  const cart = useCart();
  const [open, setOpen] = useState(false);

  return (
    <>
      <div className="wrap">
        <div className="hd">
          <button
            type="button"
            className="logo"
            onClick={() => nav("/")}
            style={{ background: "none", border: 0, cursor: "pointer" }}
          >
            <span className="dot" />
            {settings.shopName}
          </button>
          <div className="sp" />
          {search && (
            <button
              type="button"
              className="iconbtn searchic mobileonly"
              onClick={() => setOpen(o => !o)}
              aria-label="Search"
            >
              <SearchIcon />
            </button>
          )}
          {search && (
            <a
              className="callbtn"
              href={waLink(settings.whatsapp, `Hi ${settings.shopName}, I am looking for...`)}
              target="_blank"
              rel="noreferrer"
            >
              <WhatsAppIcon />
              <span>WhatsApp</span>
            </a>
          )}
          <button type="button" className="cartbtn" onClick={() => cart.setOpen(true)}>
            <CartIcon />
            <span>Cart</span>
            <i>{cart.items.length}</i>
          </button>
        </div>
      </div>
      {search && (
        <div className={`searchwrap${open ? " open" : ""}`}>
          <div className="wrap">
            <div className="searchrow">
              <div className="sfield">
                <input
                  className="search"
                  value={search.term}
                  placeholder={search.placeholder}
                  onChange={e => search.setTerm(e.target.value)}
                  onKeyDown={e => e.key === "Enter" && search.run()}
                />
                <button type="button" className="goic" onClick={search.run} aria-label="Search">
                  <SearchIcon stroke="#fff" />
                </button>
              </div>
              <button type="button" className="searchbtn desktoponly" onClick={search.run}>
                Search
              </button>
              <button type="button" className="searchbtn mobileonly" onClick={() => setOpen(false)}>
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}

export function Ribbon({ items }: { items: string[] }) {
  const line = items.length ? items : ["NEW PIECES EVERY WEEK"];
  return (
    <div className="ribbon">
      <div className="rib-track">
        {[0, 1].map(k =>
          line.map(t => (
            <span key={`${k}-${t}`}>{t} ·</span>
          )),
        )}
      </div>
    </div>
  );
}

export function ShopFooter({ settings }: { settings: Settings }) {
  const pretty = `+${settings.whatsapp.slice(0, 2)} ${settings.whatsapp.slice(2, 4)} ${settings.whatsapp.slice(4, 7)} ${settings.whatsapp.slice(7)}`;
  return (
    <footer>
      <div className="wrap">
        <b>{settings.shopName}</b>
        <br />
        {settings.footerLine} ·{" "}
        <a href={`https://wa.me/${settings.whatsapp}`} target="_blank" rel="noreferrer">
          WhatsApp us any time — {pretty}
        </a>
        <br />
        Prices in USD. EcoCash, InnBucks, bank transfer or cash on delivery.
        <div className="footer-admin">
          <a href="/owner">Admin login</a>
        </div>
      </div>
    </footer>
  );
}

export function CartDrawer({ settings }: { settings: Settings }) {
  const cart = useCart();
  const nav = useNavigate();
  return (
    <>
      <div className={`scrim${cart.open ? " on" : ""}`} onClick={() => cart.setOpen(false)} />
      <aside className={`drawer${cart.open ? " on" : ""}`}>
        <header>
          <h3>Your cart</h3>
          <button type="button" className="back" onClick={() => cart.setOpen(false)}>
            Close
          </button>
        </header>
        <div className="body">
          {cart.items.length === 0 && (
            <div className="small">
              Nothing in the cart yet. Tap the cart button on a piece to keep it here, then send the
              whole list to the shop in one WhatsApp message.
            </div>
          )}
          {cart.items.map(p => (
            <div key={p._id} className="crow">
              <img
                src={p.photoUrls[0]}
                alt={p.name}
                onClick={() => {
                  cart.setOpen(false);
                  nav(`/piece/${p._id}`);
                }}
              />
              <div className="t">
                <b>{p.brand}</b>
                {p.name}
                <br />
                size {p.size} · <b style={{ display: "inline" }}>{money(p.price)}</b>
                <br />
                <button type="button" onClick={() => cart.remove(p._id)}>
                  Remove
                </button>
              </div>
            </div>
          ))}
        </div>
        <div className="foot">
          <div className="tot">
            <span>Total</span>
            <span>{money(cart.total)}</span>
          </div>
          <a
            className="btn wa"
            style={{ display: "flex" }}
            target="_blank"
            rel="noreferrer"
            href={waLink(settings.whatsapp, cartMessage(settings.shopName, cart.items))}
          >
            <WhatsAppIcon />
            <span>Send the whole cart on WhatsApp</span>
          </a>
          <div className="small" style={{ marginTop: 8 }}>
            This opens WhatsApp with your list already typed. The shop confirms and sends payment
            details.
          </div>
        </div>
      </aside>
    </>
  );
}
