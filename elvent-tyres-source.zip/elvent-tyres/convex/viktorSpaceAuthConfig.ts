import { Password } from "@convex-dev/auth/providers/Password";
import type { AuthProviderConfig } from "@convex-dev/auth/server";
import { createViktorAuthJsProvider } from "../src/lib/viktor-spaces-access/authjs";
import { checkInviteToken } from "./inviteToken";
import { isOwnerEmail } from "./owner";
import { TestCredentials } from "./testAuth";
import {
  ViktorSpacesEmail,
  ViktorSpacesPasswordReset,
} from "./ViktorSpacesEmail";
import { configuredProductAuthEnabled } from "./viktorSpaceAuthEnv";

declare const process: { env: Record<string, string | undefined> };

const DEFAULT_AUTH_PROVIDER_NAMES = ["email_password", "viktor"] as const;
type AuthProviderName = (typeof DEFAULT_AUTH_PROVIDER_NAMES)[number];

function configuredAuthProviderNames(): Set<AuthProviderName> {
  const configured =
    process.env.VIKTOR_SPACES_AUTH_PROVIDERS ||
    process.env.VITE_VIKTOR_SPACES_AUTH_PROVIDERS;
  if (!configured) {
    return new Set(DEFAULT_AUTH_PROVIDER_NAMES);
  }

  let parsed: unknown;
  try {
    parsed = JSON.parse(configured);
  } catch {
    throw new Error(`Invalid VIKTOR_SPACES_AUTH_PROVIDERS: ${configured}`);
  }

  if (!Array.isArray(parsed) || parsed.length === 0) {
    throw new Error(`Invalid VIKTOR_SPACES_AUTH_PROVIDERS: ${configured}`);
  }

  const providerNames = new Set<AuthProviderName>();
  for (const provider of parsed) {
    if (provider !== "email_password" && provider !== "viktor") {
      throw new Error(`Invalid VIKTOR_SPACES_AUTH_PROVIDERS: ${configured}`);
    }
    if (providerNames.has(provider)) {
      throw new Error(`Invalid VIKTOR_SPACES_AUTH_PROVIDERS: ${configured}`);
    }
    providerNames.add(provider);
  }
  return providerNames;
}

function viktorWorkspaceSignInProviders(): AuthProviderConfig[] {
  const resourceId = process.env.VIKTOR_AUTH_RESOURCE_ID || "";
  const viktorAuthBaseUrl = process.env.VIKTOR_AUTH_BASE_URL || "";
  if (!resourceId || !viktorAuthBaseUrl) {
    // Deployments without a Viktor control plane (local dev) still get
    // email + password auth; "Sign in with Viktor" is simply absent.
    return [];
  }
  return [
    // Hand-rolled Auth.js-style OAuth config; structurally compatible with
    // the provider shape Convex Auth consumes.
    createViktorAuthJsProvider({
      clientId: process.env.VIKTOR_AUTH_CLIENT_ID || `space-${resourceId}`,
      resourceId,
      viktorAuthBaseUrl,
    }) as unknown as AuthProviderConfig,
  ];
}

/**
 * Password reset, but only for addresses that can actually administer the
 * shop. The stock provider mails a code to anyone who asks, unauthenticated
 * and unthrottled — every send being a billed API call, and every reply
 * confirming whether an address exists. Non-staff requests are dropped
 * silently: the form still says "check your email", so nothing is revealed.
 */
function staffOnlyPasswordReset() {
  const base = ViktorSpacesPasswordReset as unknown as {
    sendVerificationRequest: (args: {
      identifier: string;
      token: string;
    }) => Promise<void>;
  };
  const original = base.sendVerificationRequest.bind(base);
  return {
    ...ViktorSpacesPasswordReset,
    async sendVerificationRequest(args: { identifier: string; token: string }) {
      const email = String(args.identifier ?? "")
        .trim()
        .toLowerCase();
      if (!isOwnerEmail(email)) return;
      await original(args);
    },
  } as unknown as typeof ViktorSpacesPasswordReset;
}

function configuredSpaceAuthProviders(): AuthProviderConfig[] {
  const providerNames = configuredAuthProviderNames();
  const isPreview = process.env.VIKTOR_SPACES_IS_PREVIEW === "true";
  const providers: AuthProviderConfig[] = [];
  if (providerNames.has("email_password")) {
    providers.push(
      Password({
        verify: ViktorSpacesEmail,
        reset: staffOnlyPasswordReset(),
        // Elvent Tyres is a shop, not a community site: customers never need
        // an account. Only addresses on the staff allow-list may register.
        // Without this, anyone on the internet could create a session here.
        profile(params) {
          const email = String(params.email ?? "")
            .trim()
            .toLowerCase();
          if (!email) throw new Error("An email address is required.");
          // Two ways in, and only two: you are a permanent owner, or you
          // are holding an invite the owner issued for this exact address.
          // The invite is checked by signature, not by a database lookup,
          // because this callback is synchronous — see convex/inviteToken.ts.
          const invited = checkInviteToken(
            email,
            String(params.invite ?? ""),
          );
          if (params.flow === "signUp" && !isOwnerEmail(email) && !invited) {
            // Deliberately the same message the sign-up form gives for any
            // other failure. A specific "not on the staff list" reply told a
            // stranger exactly which addresses CAN change stock, which turned
            // the gate into a list of targets to guess passwords against.
            throw new Error(
              "Sign-up could not be completed. Contact the shop owner.",
            );
          }
          return { email };
        },
      }),
    );
  }
  if (providerNames.has("viktor")) {
    const viktorProviders = viktorWorkspaceSignInProviders();
    if (
      viktorProviders.length === 0 &&
      !providerNames.has("email_password") &&
      !isPreview
    ) {
      throw new Error(
        "Viktor sign-in is the only configured provider but the Viktor OAuth " +
          "deployment env (VIKTOR_AUTH_RESOURCE_ID, VIKTOR_AUTH_BASE_URL) is " +
          "missing. Configure it or include email_password in auth.providers.",
      );
    }
    providers.push(...viktorProviders);
  }
  if (isPreview) {
    providers.push(TestCredentials);
  }
  return providers;
}

export function configuredAuthProviders(): AuthProviderConfig[] {
  return configuredProductAuthEnabled() ? configuredSpaceAuthProviders() : [];
}
