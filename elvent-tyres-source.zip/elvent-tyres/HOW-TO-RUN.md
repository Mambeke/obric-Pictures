# Elvent Tyres — running the shop on your own machine

This is the real source code of the live shop. Nothing here is a mock-up.

- **Front end:** React 19 + TypeScript, built with Vite. Styling is Tailwind.
- **Back end:** Convex — the database, the login system and the photo storage.
  Back-end code is in `convex/` and it is TypeScript too.

## What you need

- Node.js 22 or newer
- VS Code

## Running it

```bash
npm install
npx convex dev      # first run: log in, then pick "create a new project"
npm run dev
```

Two terminals is easiest — leave `npx convex dev` running in one and
`npm run dev` in the other. The shop opens at http://localhost:5173.

`npx convex dev` writes a `.env.local` for you with your own deployment URL.
That file is deliberately not included here; it holds credentials.

## Important: this connects to a NEW, EMPTY database

Running the steps above gives you your own Convex project with no tyres in it.
It does **not** touch the live shop's data. To work against the live
deployment you need that deployment's credentials from the account that owns
it — see `.env.example` for the variable names.

## Where things are

| Path | What's in it |
|---|---|
| `convex/schema.ts` | Database tables — tyres, staff, users |
| `convex/tyres.ts` | Public queries: search, listing, the tyre page |
| `convex/admin.ts` | Stock changes — add, edit, delete, mark sold |
| `convex/owner.ts` | Who is allowed to do what |
| `convex/staff.ts` | Granting and revoking staff access |
| `src/` | Everything the customer sees |
| `public/` | Logo, favicons |

## Access levels

`convex/owner.ts` holds a hardcoded list of owner accounts. Owners manage stock
*and* manage who else has access, and cannot be revoked from inside the app.
Staff rows in the `staff` table can be granted and revoked by an owner, and can
only manage stock.

## Checks before shipping a change

```bash
npm run typecheck
npm run lint
npm run build
```
