import { useQuery } from "convex/react";
import { useEffect } from "react";
import { Link, useNavigate, useParams } from "react-router";
import { api } from "../../convex/_generated/api";
import type { Id } from "../../convex/_generated/dataModel";
import { PhoneIcon, ShopFooter, ShopHeader, WhatsAppIcon } from "@/shop/Chrome";
import { CONDITION_BLURB, rands, type ShopSettings, waLink } from "@/shop/config";
import { Gallery } from "@/shop/Gallery";
import type { Appliance } from "@/shop/types";

export function ProductPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const item = useQuery(api.shop.getAppliance, {
    id: id as Id<"appliances">,
  }) as Appliance | null | undefined;
  const settings = useQuery(api.shop.getSettings) as ShopSettings | undefined;

  // Opening an appliance must start at the top of the page. Without this the
  // browser keeps the scroll position of the shop page, so the buyer lands
  // halfway down the photo and has to scroll up to see the whole thing.
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "auto" });
  }, [id]);

  if (!settings) return <div className="min-h-screen bg-[#f5f7fa]" />;
  const s = settings;

  if (item === undefined) {
    return (
      <div className="min-h-screen bg-[#f5f7fa]">
        <ShopHeader s={s} />
        <div className="mx-auto mt-8 h-96 max-w-5xl animate-pulse rounded-2xl bg-white" />
      </div>
    );
  }

  if (item === null) {
    return (
      <div className="min-h-screen bg-[#f5f7fa]">
        <ShopHeader s={s} />
        <div className="mx-auto max-w-lg px-4 py-20 text-center">
          <p className="text-lg font-bold">That appliance is gone</p>
          <p className="mt-2 text-sm text-stone-600">
            It has either sold or been taken off the floor.
          </p>
          <Link
            to="/"
            className="mt-5 inline-block rounded-full bg-[#e0622a] px-6 py-3 text-sm font-bold text-white"
          >
            ← Back to the shop
          </Link>
        </div>
        <ShopFooter s={s} />
      </div>
    );
  }

  const orderText = `Hi ${s.shopName}, I'd like the ${item.title} at ${rands(item.price)}. Is it still available?`;

  return (
    <div className="min-h-screen bg-[#f5f7fa] text-[#111820]">
      <ShopHeader s={s} />

      <div className="mx-auto max-w-[1400px] px-3 pt-4 sm:px-5">
        <button
          type="button"
          onClick={() => navigate(-1)}
          className="text-[13.5px] font-semibold text-[#e0622a] hover:underline"
        >
          ← Back to the shop
        </button>
      </div>

      <main className="mx-auto grid max-w-[1400px] grid-cols-1 gap-6 px-3 py-4 sm:px-5 lg:grid-cols-[1fr_1.1fr]">
        <div className="pa-gallery-col min-w-0 lg:sticky lg:top-[92px] lg:self-start">
          <Gallery photos={item.photoUrls} alt={item.title} />
        </div>

        <div className="min-w-0">
          {item.sold && (
            <p className="mb-3 inline-block rounded-md bg-[#8a94a2] px-3 py-1 text-[12px] font-bold text-white">
              SOLD
            </p>
          )}
          <h1 className="text-[22px] font-extrabold leading-tight sm:text-[28px]">
            {item.title}
          </h1>
          <p className="mt-1 text-[14px] text-stone-500">{item.category}</p>

          <p className="mt-3 text-[30px] font-extrabold tracking-tight sm:text-[36px]">
            {rands(item.price)}
            {item.wasPrice && item.wasPrice > item.price ? (
              <span className="ml-3 text-[16px] font-medium text-stone-400 line-through">
                {rands(item.wasPrice)}
              </span>
            ) : null}
          </p>

          <div className="mt-4 rounded-2xl border border-stone-200 bg-white p-4">
            <table className="w-full text-[14px]">
              <tbody>
                {item.specs.map(sp => (
                  <tr key={sp.label} className="border-b border-stone-100 last:border-0">
                    <td className="py-2 text-stone-500">{sp.label}</td>
                    <td className="py-2 text-right font-semibold">{sp.value}</td>
                  </tr>
                ))}
                <tr className="border-b border-stone-100">
                  <td className="py-2 text-stone-500">Condition</td>
                  <td className="py-2 text-right font-semibold">{item.condition}</td>
                </tr>
                {item.testedOn && (
                  <tr className="border-b border-stone-100">
                    <td className="py-2 text-stone-500">Tested on</td>
                    <td className="py-2 text-right font-semibold">{item.testedOn}</td>
                  </tr>
                )}
                <tr>
                  <td className="py-2 text-stone-500">Delivery</td>
                  <td className="py-2 text-right font-semibold">
                    {item.freeDelivery
                      ? `Free in ${s.town}`
                      : `${rands(s.deliveryFee)} in ${s.town}`}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

          <p className="mt-3 text-[13.5px] text-stone-600">
            {CONDITION_BLURB[item.condition]}
          </p>
          {item.description && (
            <p className="mt-2 whitespace-pre-line text-[14px] leading-relaxed text-stone-700">
              {item.description}
            </p>
          )}

          {item.condition !== "Spares or repair" && (
            <div className="mt-4 rounded-xl border border-[#cfe6db] bg-[#f0f7f3] p-3.5 text-[13px] leading-relaxed text-[#155f45]">
              <b>Switched on and tested by us.</b> If it stops working within{" "}
              {s.warrantyDays} days, bring it back.
            </div>
          )}

          {item.sold ? (
            <div className="mt-5 rounded-xl bg-stone-100 p-4 text-center text-[14px] text-stone-600">
              This one is sold. WhatsApp us — we can look out for another.
              <a
                href={waLink(s.whatsapp, `Hi ${s.shopName}, do you have another ${item.title}?`)}
                target="_blank"
                rel="noreferrer"
                className="mt-3 flex items-center justify-center gap-2 rounded-full bg-[#25d366] py-3 text-sm font-bold text-white"
              >
                <WhatsAppIcon /> Ask for another one
              </a>
            </div>
          ) : (
            <div className="mt-5">
              <div className="flex items-stretch gap-2.5">
                <a
                  href={waLink(s.whatsapp, orderText)}
                  target="_blank"
                  rel="noreferrer"
                  className="flex flex-1 items-center justify-center gap-2 whitespace-nowrap rounded-full bg-[#25d366] px-3 py-3.5 text-[14px] font-bold text-white shadow-sm active:scale-[.99] sm:text-[15px]"
                >
                  <WhatsAppIcon /> WhatsApp us
                </a>
                <a
                  href={`tel:${s.phoneDial}`}
                  className="flex flex-1 items-center justify-center gap-2 whitespace-nowrap rounded-full border border-stone-300 bg-white px-3 py-3.5 text-[14px] font-bold active:scale-[.99] sm:text-[15px]"
                >
                  <PhoneIcon /> Call us
                </a>
              </div>
              <p className="pt-1 text-center text-[12.5px] text-stone-500">
                No online payment. Pay cash, card or EFT when you collect or when
                we deliver.
              </p>
            </div>
          )}
        </div>
      </main>

      <ShopFooter s={s} />
    </div>
  );
}
