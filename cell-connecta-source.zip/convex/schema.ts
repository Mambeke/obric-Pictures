import { authTables } from "@convex-dev/auth/server";
import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";

const schema = defineSchema({
  ...authTables,

  phones: defineTable({
    // "Apple" | "Samsung" | "Other" | "Accessory"
    brand: v.string(),
    model: v.string(),
    // "certified_refurbished" | "pre_owned" | "accessory"
    condition: v.string(),
    colour: v.string(),
    description: v.optional(v.string()),
    // cosmetic grade, pre-owned only: "Excellent" | "Good" | "Fair"
    grade: v.optional(v.string()),
    // battery health %, pre-owned only
    battery: v.optional(v.number()),
    photos: v.array(v.string()),
    variants: v.array(
      v.object({
        storage: v.string(),
        price: v.number(),
        wasPrice: v.optional(v.number()),
        inStock: v.number(),
      }),
    ),
    demo: v.optional(v.boolean()),
    createdAt: v.number(),
  }).index("by_condition", ["condition"]),
});

export default schema;
