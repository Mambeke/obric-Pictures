export const APP_NAME = "Cell Connecta";
