export type Variant = {
  storage: string;
  price: number;
  wasPrice?: number;
  inStock: number;
};

export type Phone = {
  _id: string;
  brand: string;
  model: string;
  condition: string;
  colour: string;
  description?: string;
  grade?: string;
  battery?: number;
  photos: string[];
  photoUrls: string[];
  variants: Variant[];
  demo?: boolean;
  createdAt: number;
};

export function cheapestInStock(p: Phone): Variant | undefined {
  const inStock = p.variants.filter(v => v.inStock > 0);
  const pool = inStock.length > 0 ? inStock : p.variants;
  return [...pool].sort((a, b) => a.price - b.price)[0];
}

export function savePercent(v: Variant | undefined): number | null {
  if (!v?.wasPrice || v.wasPrice <= v.price) return null;
  return Math.round(((v.wasPrice - v.price) / v.wasPrice) * 100);
}
