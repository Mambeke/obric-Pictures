import { useMutation, useQuery } from "convex/react";
import { useState } from "react";
import { api } from "../../convex/_generated/api";

/**
 * "Give this guy access, and take it away when he leaves."
 *
 * Only the shop's permanent owners see this panel. Everything here is about
 * people, never about stock, so it lives well below the tyre list.
 */
export function StaffPanel() {
  const amOwner = useQuery(api.staff.amIOwner, {});
  const data = useQuery(api.staff.list, amOwner ? {} : "skip");
  const grant = useMutation(api.staff.grant);
  const revoke = useMutation(api.staff.revoke);
  const forget = useMutation(api.staff.forget);
  const resetLogin = useMutation(api.staff.resetLogin);

  const [email, setEmail] = useState("");
  const [note, setNote] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const [copied, setCopied] = useState("");

  if (!amOwner) return null;

  const linkFor = (addr: string, token: string) =>
    `${window.location.origin}/signup?e=${encodeURIComponent(addr)}&i=${token}`;

  async function copy(text: string, key: string) {
    try {
      await navigator.clipboard.writeText(text);
    } catch {
      // Clipboard is blocked on some phone browsers; the link is on screen
      // anyway, so this must never look like a failure.
    }
    setCopied(key);
    setTimeout(() => setCopied(""), 2200);
  }

  async function add(e: React.FormEvent) {
    e.preventDefault();
    setErr("");
    setBusy(true);
    try {
      const res = await grant({ email, note: note || undefined });
      await copy(linkFor(res.email, res.inviteToken), res.email);
      setEmail("");
      setNote("");
    } catch (ex) {
      setErr(ex instanceof Error ? ex.message : "Could not add that person.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="panel staffpanel">
      <h2>Who can change stock</h2>
      <p className="hint" style={{ marginTop: -6 }}>
        Give someone access and they can add, edit and remove tyres — the same
        as you. They cannot add other people, and they never see this box.
        Revoke and they are out immediately, even if they are signed in.
      </p>

      <form className="staffadd" onSubmit={add}>
        <input
          type="email"
          value={email}
          onChange={e => setEmail(e.target.value)}
          placeholder="his@email.com"
          aria-label="Email address to give access to"
          required
        />
        <input
          value={note}
          onChange={e => setNote(e.target.value)}
          placeholder="Who is this? e.g. Sipho — front desk"
          aria-label="Note"
        />
        <button type="submit" className="pbtn" disabled={busy}>
          {busy ? "Adding…" : "Give access"}
        </button>
      </form>
      {err && <div className="formerr">{err}</div>}

      <div className="stafflist">
        {data?.owners.map(o => (
          <div className="staffrow owner" key={o.email}>
            <div className="sinfo">
              <b>{o.email}</b>
              <span>Owner · permanent · can manage people</span>
            </div>
            <span className="pill on">Full access</span>
          </div>
        ))}

        {data?.staff.length === 0 && (
          <div className="hint" style={{ padding: "14px 2px" }}>
            Nobody else has access yet. Add an email above and send the person
            the link — they set their own password, you never see it.
          </div>
        )}

        {data?.staff.map(s => (
          <div className={`staffrow ${s.active ? "" : "off"}`} key={s.id}>
            <div className="sinfo">
              <b>{s.email}</b>
              <span>
                {s.note ? `${s.note} · ` : ""}
                {s.active
                  ? s.hasAccount
                    ? "Can add and edit tyres"
                    : "Invited — has not made his password yet"
                  : "Access revoked"}
              </span>
              {s.active && (
                <div className="invite">
                  <code>{linkFor(s.email, s.inviteToken)}</code>
                  <button
                    type="button"
                    onClick={() =>
                      void copy(linkFor(s.email, s.inviteToken), s.email)
                    }
                  >
                    {copied === s.email ? "Copied ✓" : "Copy link"}
                  </button>
                </div>
              )}
            </div>

            <div className="sacts">
              <span className={`pill ${s.active ? "on" : ""}`}>
                {s.active ? "Active" : "Revoked"}
              </span>
              {s.active ? (
                <>
                  <button
                    type="button"
                    className="danger"
                    onClick={() => {
                      if (
                        window.confirm(
                          `Revoke access for ${s.email}? He will not be able to touch stock again until you give it back.`,
                        )
                      )
                        void revoke({ id: s.id });
                    }}
                  >
                    Revoke
                  </button>
                  {s.hasAccount && (
                    <button
                      type="button"
                      onClick={() => {
                        if (
                          window.confirm(
                            `Wipe ${s.email}'s password? He keeps his access and uses the same link to set a new one.`,
                          )
                        )
                          void resetLogin({ id: s.id });
                      }}
                    >
                      Forgot password
                    </button>
                  )}
                </>
              ) : (
                <>
                  <button
                    type="button"
                    onClick={() => void grant({ email: s.email })}
                  >
                    Give back
                  </button>
                  <button
                    type="button"
                    className="danger"
                    onClick={() => {
                      if (window.confirm(`Remove ${s.email} from this list?`))
                        void forget({ id: s.id });
                    }}
                  >
                    Remove
                  </button>
                </>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
