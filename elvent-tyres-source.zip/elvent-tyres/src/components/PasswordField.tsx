import { useState } from "react";

/**
 * Password input with a Show/Hide toggle.
 *
 * The shop owner locked himself out on day one by mistyping a password he
 * could not see at sign-up, so every password box in this app must be
 * readable on demand. Phones with aggressive autocorrect make this worse.
 */
export function PasswordField({
  id,
  name,
  label,
  placeholder,
  autoComplete,
}: {
  id: string;
  name: string;
  label: string;
  placeholder?: string;
  autoComplete: string;
}) {
  const [shown, setShown] = useState(false);
  return (
    <div className="field" style={{ marginBottom: 16 }}>
      <div className="fieldhead">
        <label htmlFor={id}>{label}</label>
        <button
          type="button"
          className="peek"
          onClick={() => setShown(v => !v)}
          aria-pressed={shown}
        >
          {shown ? "Hide" : "Show"}
        </button>
      </div>
      <input
        id={id}
        name={name}
        type={shown ? "text" : "password"}
        autoComplete={autoComplete}
        placeholder={placeholder}
        required
        minLength={8}
      />
    </div>
  );
}
