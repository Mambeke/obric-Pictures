import { runTest } from "./auth";

runTest("Screenshots v5", async helper => {
  const { page } = helper;
  await page.setViewportSize({ width: 1280, height: 860 });
  await helper.goto("/");
  await page.waitForSelector("text=Defy gas hob", { timeout: 25000 });
  await page.waitForTimeout(2000);
  await page.screenshot({ path: "tmp/v5-chips.png" });
  // Scroll down first: opening an item must still land at the top.
  await page.evaluate(() => window.scrollTo(0, 1200));
  await page.waitForTimeout(400);
  await page.locator("a[href^='/item/']").first().click();
  await page.waitForTimeout(2500);
  const y = await page.evaluate(() => window.scrollY);
  if (y > 5) throw new Error(`product page opened at scrollY ${y}`);
  await page.screenshot({ path: "tmp/v5-product.png" });
  await page.evaluate(() => window.scrollTo(0, 700));
  await page.waitForTimeout(600);
  await page.screenshot({ path: "tmp/v5-product-scrolled.png" });

  await page.setViewportSize({ width: 390, height: 844 });
  await page.evaluate(() => window.scrollTo(0, 0));
  await page.waitForTimeout(800);
  await page.screenshot({ path: "tmp/v5-product-mobile.png" });

  // Owner panel
  await page.setViewportSize({ width: 390, height: 844 });
  await helper.goto("/admin");
  await page.waitForSelector("text=Add an appliance", { timeout: 25000 });
  await page.waitForTimeout(1500);
  await page.screenshot({ path: "tmp/v5-admin-mobile.png" });
  await page.locator("text=+ Add an appliance").first().click();
  await page.waitForTimeout(1500);
  await page.screenshot({ path: "tmp/v5-admin-form.png" });
  await page.setViewportSize({ width: 1280, height: 860 });
  await page.waitForTimeout(800);
  await page.screenshot({ path: "tmp/v5-admin-desktop.png" });
  console.log("shots done");
}).catch(() => process.exit(1));
