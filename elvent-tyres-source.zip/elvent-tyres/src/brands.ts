/**
 * Tyre brands actually sold in South Africa, for the admin brand box.
 *
 * Ordered the way a tyre man thinks, not alphabetically: the premium names
 * first because they carry the price, then the mid-range, then the budget
 * imports that make up most of a used-tyre wall in Cape Town.
 *
 * This is a suggestion list, not a restriction — the field stays free text so
 * an unusual brand, or "Bridgestone Turanza" with the pattern name, still goes
 * in exactly as typed.
 */
export const SA_TYRE_BRANDS: string[] = [
  // Premium
  "Bridgestone",
  "Michelin",
  "Continental",
  "Goodyear",
  "Pirelli",
  "Dunlop",
  "Yokohama",
  "Toyo",
  "Hankook",
  "Kumho",
  "Falken",
  "BFGoodrich",
  "Firestone",
  "General Tire",
  "Nexen",
  "Maxxis",
  "Cooper",
  "Vredestein",
  "Uniroyal",
  "Semperit",
  "Barum",
  "GT Radial",
  "Apollo",
  "Nankang",
  "Federal",
  "Sumitomo",
  "Riken",
  "Sava",
  // Mid-range and common imports
  "Aeolus",
  "Sailun",
  "Linglong",
  "Triangle",
  "Westlake",
  "Goodride",
  "Trazano",
  "Rovelo",
  "Landsail",
  "Zeetex",
  "Radar",
  "Achilles",
  "Accelera",
  "Delinte",
  "Minerva",
  "Petlas",
  "Rotalla",
  "Tracmax",
  "Wanli",
  "Sunny",
  "Sunfull",
  "Ovation",
  "Roadmarch",
  "Hifly",
  "Leao",
  // Budget / value
  "Lanvigator",
  "Autogrip",
  "Comforser",
  "Windforce",
  "Compasal",
  "Grenlander",
  "Habilead",
  "Haida",
  "Headway",
  "Ilink",
  "Joyroad",
  "Kapsen",
  "Kinforest",
  "Farroad",
  "Fortune",
  "Goform",
  "Powertrac",
  "Rapid",
  "Roadcruza",
  "Royal Black",
  "Saferich",
  "Superia",
  "Three-A",
  "Torque",
  "Winrun",
  "Double Coin",
  "Doublestar",
  "Durun",
  "Boto",
  "Jinyu",
  "Keter",
  "Mazzini",
  "Onyx",
  "Sonar",
  "Duraturn",
  // 4x4 / bakkie specialists
  "Mickey Thompson",
  "Pro Comp",
  "Roadstone",
  "Silverstone",
  "Trailblazer",
];

/**
 * Format a tyre size while it is being typed, so the shop front never shows
 * "2054017" because somebody was in a hurry.
 *
 * Only touches input that is still pure digits: 205 -> "205/", then two more
 * -> "205/40R". The moment a letter or a symbol is typed the text is left
 * exactly as entered, which is what makes 195R15C, 31x10.50R15 and 750R16
 * still possible to enter by hand.
 */
export function autoFormatSize(next: string, previous: string): string {
  if (next.length <= previous.length) return next; // never fight a backspace

  const t = next.replace(/\s+/g, "").toUpperCase();

  // Only ever touch text that is still in the shape this formatter itself
  // produces: digits, then an optional /NN, then an optional R. The moment
  // anything else is typed — 195R15C, 31X10.50R15, 750R16 — the text is left
  // exactly as entered. Someone loading stock knows what is on the sidewall;
  // the formatter is there to stop "2054017", not to argue.
  const plainDigits = /^\d{1,7}$/.test(t);
  const ourShape = /^\d{3}\/\d{0,5}(R\d{0,2})?$/.test(t);
  if (!plainDigits && !ourShape) return next;

  const digits = t.replace(/\D/g, "");
  // The separators appear only once the digit that needs them is typed. An
  // eager "/" after three digits would block 195R15C and 750R16, where the
  // very next keystroke is a letter.
  if (digits.length <= 3) return t;
  if (digits.length <= 5) return `${digits.slice(0, 3)}/${digits.slice(3)}`;
  return `${digits.slice(0, 3)}/${digits.slice(3, 5)}R${digits.slice(5, 7)}`;
}
