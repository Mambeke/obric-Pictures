import { authTables } from "@convex-dev/auth/server";
import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";

const schema = defineSchema({
  ...authTables,

  tyres: defineTable({
    // "195/65R15" exactly as it should be displayed
    sizeLabel: v.string(),
    // digits only, e.g. "1956515" — what the forgiving search matches against
    sizeKey: v.string(),
    width: v.string(),
    profile: v.string(),
    rim: v.string(),
    brand: v.string(),
    condition: v.union(v.literal("used"), v.literal("new")),
    price: v.number(),
    stock: v.number(),
    notes: v.optional(v.string()),
    photos: v.array(v.id("_storage")),
    // Photos that are not in Convex storage (seeded demo images, or a photo
    // already hosted elsewhere). Shown after the uploaded ones.
    photoUrls: v.optional(v.array(v.string())),
    // false = sold out / hidden from the shop, kept in the admin list
    active: v.boolean(),
    createdAt: v.number(),
    // "metric" = 195/65R15. "lt" = bakkie / light-truck sizes such as
    // 31x10.50R15 or 750R16, whose numbers must stay out of the customer's
    // width/profile dropdowns — "31" and "10.5" mean nothing on a sidewall.
    sizeSystem: v.optional(v.union(v.literal("metric"), v.literal("lt"))),
  })
    .index("by_active", ["active"])
    .index("by_condition", ["active", "condition"])
    .index("by_sizeKey", ["sizeKey"])
    // Related stock on a tyre page looks up by rim. Without this index the
    // .take(12) after a .filter() walks the whole active set whenever the rim
    // size is rare — and rare rims are common in used tyres.
    .index("by_rim", ["active", "rim"]),

  /**
   * Who may change stock, beyond the two permanent owners in convex/owner.ts.
   *
   * A row is an access grant, not a login. Revoking flips `active` to false:
   * the person's account still exists, they can still sign in, and they see
   * nothing but the shop — which is exactly what "your access is revoked"
   * should mean. Restoring is one click, with no new invite needed.
   */
  staff: defineTable({
    email: v.string(),
    active: v.boolean(),
    invitedBy: v.string(),
    invitedAt: v.number(),
    revokedBy: v.optional(v.string()),
    revokedAt: v.optional(v.number()),
    note: v.optional(v.string()),
  }).index("by_email", ["email"]),
});

export default schema;
