/** Everything the shop owner might want to change, in one place. */
export const SHOP = {
  name: "Elvent Tyres",
  addressShort: "44 Voortrekker Rd, Goodwood",
  addressCity: "Cape Town",
  addressFull: "44 Voortrekker Rd, Goodwood, Cape Town, 7460",
  hoursShort: "Mon–Sat 09:00–16:30",
  hoursLong: "Monday to Saturday, 09:00 – 16:30",
  whatsapp: "27685302223",
  phoneDisplay: "068 530 2223",
  phoneRaw: "+27685302223",
  mapsUrl:
    "https://www.google.com/maps/search/?api=1&query=44+Voortrekker+Road+Goodwood+Cape+Town",
} as const;

export const SERVICES: [string, string][] = [
  ["Free fitting", "on every tyre you buy"],
  ["Wheel alignment", "R300"],
  ["Puncture plug", "R50"],
  ["Patch", "R100"],
  ["Hot patch", "R150"],
  ["Tyre swap", "R50 per tyre"],
  ["Wheel balancing", "R50"],
];

/**
 * Tyre sizes common on South African roads. These fill the dropdowns even
 * before the shop has that size in stock, because a customer picks the numbers
 * off their own sidewall — they are not browsing our stock list.
 */
export const WIDTHS = [
  135, 145, 155, 165, 175, 185, 195, 205, 215, 225, 235, 245, 255, 265, 275,
  285, 295, 305, 315, 325, 335,
];
export const PROFILES = [
  25, 30, 35, 40, 45, 50, 55, 60, 65, 70, 75, 80, 82, 85,
];
export const RIMS = [12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 24];

export const TAGLINES = [
  "Every tyre photographed. What you see is the tyre you get.",
  "Used and new tyres — checked, priced and ready to fit today.",
  "Send us your size on WhatsApp and we'll tell you straight away.",
  "Buy a tyre from us and the fitting is free. Balancing and alignment on site.",
];

export type Card = {
  id: string;
  sizeLabel: string;
  brand: string;
  condition: "used" | "new";
  price: number;
  stock: number;
  notes?: string;
  photos: string[];
  photoCount: number;
};

export function waLink(t: Card): string {
  const msg = `Hi ${SHOP.name}, I'm interested in the ${t.sizeLabel} ${t.brand} (${
    t.condition === "new" ? "New" : "Used"
  }) at R${t.price}. Is it available?`;
  return `https://wa.me/${SHOP.whatsapp}?text=${encodeURIComponent(msg)}`;
}

export const waGeneral = `https://wa.me/${SHOP.whatsapp}?text=${encodeURIComponent(
  `Hi ${SHOP.name}, I'm looking for a tyre size. Do you have it in stock?`,
)}`;

export const FALLBACK_PHOTO = "/demo/face.webp";
