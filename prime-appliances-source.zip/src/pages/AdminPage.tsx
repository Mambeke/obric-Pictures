import { useAuthActions } from "@convex-dev/auth/react";
import { useMutation, useQuery } from "convex/react";
import { useState } from "react";
import { Link } from "react-router";
import { api } from "../../convex/_generated/api";
import type { Id } from "../../convex/_generated/dataModel";
import {
  CATEGORIES,
  CONDITIONS,
  daysOld,
  rands,
  type ShopSettings,
  SPEC_HINTS,
  SPEC_SUGGESTIONS,
  todayStamp,
} from "@/shop/config";
import type { Appliance, Spec } from "@/shop/types";

const inputClass =
  "w-full rounded-xl border border-stone-300 bg-white px-3 py-2.5 text-[14.5px] outline-none transition focus:border-[#e0622a] focus:ring-2 focus:ring-[#e0622a]/20";
const labelClass = "mb-1 block text-[12.5px] font-bold text-stone-500";

type Draft = {
  id?: string;
  category: string;
  title: string;
  condition: string;
  price: string;
  wasPrice: string;
  description: string;
  specs: Spec[];
  testedOn: string;
  freeDelivery: boolean;
  photos: string[];
  photoUrls: string[];
};

const emptyDraft = (category: string): Draft => ({
  category,
  title: "",
  condition: "Good",
  price: "",
  wasPrice: "",
  description: "",
  specs: (SPEC_SUGGESTIONS[category] ?? []).map(label => ({ label, value: "" })),
  testedOn: todayStamp(),
  freeDelivery: false,
  photos: [],
  photoUrls: [],
});

export function AdminPage() {
  const me = useQuery(api.shop.amIOwner);
  const items = useQuery(api.shop.listAppliances) as Appliance[] | undefined;
  const settings = useQuery(api.shop.getSettings) as ShopSettings | undefined;
  const saveAppliance = useMutation(api.shop.saveAppliance);
  const deleteAppliance = useMutation(api.shop.deleteAppliance);
  const setSold = useMutation(api.shop.setSold);
  const clearDemo = useMutation(api.shop.clearDemoStock);
  const generateUploadUrl = useMutation(api.shop.generateUploadUrl);
  const [dragIdx, setDragIdx] = useState<number | null>(null);
  const { signOut } = useAuthActions();

  const [draft, setDraft] = useState<Draft | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [shelf, setShelf] = useState<"live" | "sold">("live");
  const [find, setFind] = useState("");
  const [dropping, setDropping] = useState(false);
  const [tab, setTab] = useState<"stock" | "shop">("stock");

  if (me === undefined) {
    return <div className="p-10 text-center text-stone-500">Loading…</div>;
  }

  if (!me.isOwner) {
    return (
      <div className="mx-auto max-w-md p-10 text-center">
        <h1 className="text-xl font-black">This account can't manage stock</h1>
        <p className="mt-2 text-sm text-stone-600">
          You are signed in as {me.email ?? "an unknown account"}. Only the shop
          owner's account can open the stock manager.
        </p>
        <button
          type="button"
          onClick={() => void signOut()}
          className="mt-5 rounded-full bg-[#111820] px-5 py-2.5 text-sm font-bold text-white"
        >
          Sign out
        </button>
      </div>
    );
  }

  const update = (patch: Partial<Draft>) =>
    setDraft(d => (d ? { ...d, ...patch } : d));

  const uploadPhotos = async (files: FileList) => {
    if (!draft) return;
    setBusy(true);
    setError("");
    try {
      const ids: string[] = [];
      const urls: string[] = [];
      for (const file of Array.from(files)) {
        // A photo straight off a phone camera is 4-8 MB. Shrinking it here
        // keeps the shop quick to load on a customer's data bundle.
        const small = await shrink(file);
        const url = await generateUploadUrl({});
        const res = await fetch(url, {
          method: "POST",
          headers: { "Content-Type": small.type },
          body: small,
        });
        const json = (await res.json()) as { storageId: string };
        ids.push(json.storageId);
        urls.push(URL.createObjectURL(small));
      }
      setDraft(d =>
        d
          ? { ...d, photos: [...d.photos, ...ids], photoUrls: [...d.photoUrls, ...urls] }
          : d,
      );
    } catch (e) {
      setError(e instanceof Error ? e.message : "Upload failed");
    } finally {
      setBusy(false);
    }
  };

  const movePhoto = (from: number, to: number) =>
    setDraft(d => {
      if (!d || to < 0 || to >= d.photos.length || from === to) return d;
      const photos = [...d.photos];
      const urls = [...d.photoUrls];
      const [p] = photos.splice(from, 1);
      const [u] = urls.splice(from, 1);
      photos.splice(to, 0, p);
      urls.splice(to, 0, u);
      return { ...d, photos, photoUrls: urls };
    });

  const startEdit = (item: Appliance) =>
    setDraft({
      id: item._id,
      category: item.category,
      title: item.title,
      condition: item.condition,
      price: String(item.price),
      wasPrice: item.wasPrice ? String(item.wasPrice) : "",
      description: item.description ?? "",
      specs: item.specs.length
        ? item.specs
        : (SPEC_SUGGESTIONS[item.category] ?? []).map(label => ({ label, value: "" })),
      testedOn: item.testedOn ?? todayStamp(),
      freeDelivery: item.freeDelivery,
      photos: item.photos,
      photoUrls: item.photoUrls,
    });

  const publish = async () => {
    if (!draft) return;
    const price = Number(draft.price);
    if (!draft.title.trim()) return setError("Give it a name — make and model.");
    if (!price || price <= 0) return setError("Put a price on it.");
    setBusy(true);
    setError("");
    try {
      await saveAppliance({
        id: draft.id ? (draft.id as Id<"appliances">) : undefined,
        category: draft.category,
        title: draft.title.trim(),
        condition: draft.condition,
        price,
        wasPrice: draft.wasPrice ? Number(draft.wasPrice) : undefined,
        description: draft.description.trim() || undefined,
        specs: draft.specs.filter(s => s.label.trim() && s.value.trim()),
        testedOn: draft.testedOn.trim() || undefined,
        freeDelivery: draft.freeDelivery,
        photos: draft.photos,
      });
      setDraft(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not save");
    } finally {
      setBusy(false);
    }
  };

  const live = (items ?? []).filter(i => !i.sold);
  const soldItems = (items ?? []).filter(i => i.sold);
  // The owner's own list: plain "does it contain what I typed", no fuzz.
  const needle = find.trim().toLowerCase();
  const shown = (shelf === "live" ? live : soldItems).filter(i =>
    `${i.title} ${i.category} ${i.condition}`.toLowerCase().includes(needle),
  );


  return (
    <div className="min-h-screen bg-[#eef1f5] text-[#111820]">
      <header className="sticky top-0 z-40 bg-[#111820] text-white shadow-md">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center gap-3 px-4 py-3">
          <div className="flex items-center gap-2">
            <span className="grid size-8 place-items-center rounded-lg bg-[#e0622a] text-[13px] font-black">
              PA
            </span>
            <span className="text-[15px] font-extrabold">
              {settings?.shopName ?? "Prime Appliances"} — owner panel
            </span>
          </div>
          <div className="ml-auto flex items-center gap-3 text-[12.5px]">
            <Link
              to="/"
              className="rounded-full bg-[#e0622a] px-3 py-1 font-bold text-white shadow-sm transition hover:bg-[#c9541f]"
            >
              View the shop →
            </Link>
            <button
              type="button"
              onClick={() => void signOut()}
              className="rounded-full border border-white/30 px-3 py-1 font-semibold"
            >
              Sign out
            </button>
          </div>
        </div>
        <div className="mx-auto flex max-w-6xl gap-2 px-4 pb-3">
          {(["stock", "shop"] as const).map(t => (
            <button
              key={t}
              type="button"
              onClick={() => setTab(t)}
              className={`rounded-lg px-4 py-1.5 text-[13px] font-bold ${
                tab === t ? "bg-white text-[#111820]" : "bg-white/10 text-stone-300"
              }`}
            >
              {t === "stock" ? "Stock" : "Shop details"}
            </button>
          ))}
        </div>
      </header>

      {tab === "shop" ? (
        <ShopDetails settings={settings} />
      ) : (
        <main className="mx-auto grid max-w-6xl grid-cols-1 gap-5 px-4 py-5 lg:grid-cols-[minmax(0,1fr)_380px]">
          <section className="min-w-0">
            <div className="rounded-2xl border border-stone-200 bg-white p-4">
              <div className="flex flex-wrap items-center gap-2">
                {(["live", "sold"] as const).map(sh => (
                  <button
                    key={sh}
                    type="button"
                    onClick={() => setShelf(sh)}
                    className={`rounded-lg px-3.5 py-1.5 text-[13px] font-bold ${
                      shelf === sh
                        ? "bg-[#111820] text-white"
                        : "bg-stone-100 text-stone-600"
                    }`}
                  >
                    {sh === "live" ? `On the floor (${live.length})` : `Sold (${soldItems.length})`}
                  </button>
                ))}
                <label className="flex w-full items-center gap-1.5 rounded-lg border border-stone-300 bg-white px-3 py-2.5 sm:ml-4 sm:min-w-[280px] sm:flex-1 sm:py-1.5 shadow-sm transition focus-within:border-[#e0622a] focus-within:ring-2 focus-within:ring-[#e0622a]/20 hover:border-[#e0622a]">
                  <svg viewBox="0 0 24 24" className="size-4 shrink-0 text-stone-400" fill="none" stroke="currentColor" strokeWidth={2.5} strokeLinecap="round" aria-hidden>
                    <circle cx="11" cy="11" r="7" />
                    <path d="m20 20-3.4-3.4" />
                  </svg>
                  <input
                    value={find}
                    onChange={e => setFind(e.target.value)}
                    placeholder="Find an item…"
                    className="w-full text-[13px] outline-none sm:w-40"
                  />
                </label>
              </div>

              {/* The add button sits above the list as well: with hundreds of
                  items on the floor, nobody should scroll to the bottom to
                  load a new one. */}
              <button
                type="button"
                onClick={() => {
                  setDraft(emptyDraft("Fridges"));
                  setTimeout(() => {
                    document.getElementById("pa-form")?.scrollIntoView({ behavior: "smooth", block: "start" });
                  }, 60);
                }}
                className="mt-3 w-full rounded-xl bg-[#e0622a] px-4 py-2.5 text-[13.5px] font-bold text-white shadow-sm transition hover:bg-[#c9541f] active:scale-[.99] sm:w-auto"
              >
                + Add an appliance
              </button>

              <div className="mt-3">
                {shown.length === 0 ? (
                  <p className="py-8 text-center text-[13.5px] text-stone-500">
                    Nothing here yet.
                  </p>
                ) : (
                  shown.map(item => (
                    <div
                      key={item._id}
                      className="flex flex-wrap items-center gap-x-3 gap-y-2 border-t border-stone-100 py-2.5 first:border-0"
                    >
                      <div className="size-14 shrink-0 overflow-hidden rounded-lg bg-[#eef1f5]">
                        {item.photoUrls[0] && (
                          <img
                            src={item.photoUrls[0]}
                            alt=""
                            loading="lazy"
                            className="size-full object-contain mix-blend-multiply"
                          />
                        )}
                      </div>
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-[14px] font-semibold">
                          {item.title}
                          {item.demo && (
                            <span className="ml-2 rounded bg-amber-100 px-1.5 py-0.5 text-[10px] font-bold text-amber-700">
                              SAMPLE
                            </span>
                          )}
                        </p>
                        <p className="text-[12.5px] text-stone-500">
                          {rands(item.price)} · {item.condition} · listed{" "}
                          {daysOld(item.createdAt)} days
                        </p>
                      </div>
                      <div className="ml-auto flex shrink-0 items-center gap-1.5">
                        <button
                          type="button"
                          onClick={() => {
                            startEdit(item);
                            setTimeout(() => {
                              document.getElementById("pa-form")?.scrollIntoView({ behavior: "smooth", block: "start" });
                            }, 60);
                          }}
                          className="rounded-lg bg-[#1257d0] px-2.5 py-1.5 text-[12px] font-bold text-white transition hover:bg-[#0e46a8] active:scale-95"
                        >
                          Edit
                        </button>
                        <button
                          type="button"
                          onClick={() =>
                            void setSold({
                              id: item._id as Id<"appliances">,
                              sold: !item.sold,
                            })
                          }
                          className="rounded-lg bg-[#e0622a] px-2.5 py-1.5 text-[12px] font-bold text-white transition hover:bg-[#c9541f] active:scale-95"
                        >
                          {item.sold ? "Put back" : "Sold"}
                        </button>
                        <button
                          type="button"
                          onClick={() => {
                            if (confirm(`Are you sure you want to delete ${item.title}? Deleting this is permanent.`)) {
                              void deleteAppliance({ id: item._id as Id<"appliances"> });
                            }
                          }}
                          className="rounded-lg bg-[#d13030] px-2.5 py-1.5 text-[12px] font-bold text-white transition hover:bg-[#b02222] active:scale-95"
                        >
                          Delete
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>

              <div className="mt-4 flex flex-wrap gap-2">
                <button
                  type="button"
                  onClick={() => setDraft(emptyDraft("Fridges"))}
                  className="rounded-xl bg-[#e0622a] px-4 py-2.5 text-[13.5px] font-bold text-white"
                >
                  + Add an appliance
                </button>
                {(items ?? []).some(i => i.demo) && (
                  <button
                    type="button"
                    onClick={() => {
                      if (confirm("Remove every sample item?")) void clearDemo({});
                    }}
                    className="rounded-xl border border-stone-300 px-4 py-2.5 text-[13.5px] font-bold text-stone-600"
                  >
                    Remove the sample stock
                  </button>
                )}
              </div>
            </div>

          </section>

          <aside className="min-w-0">
            {draft ? (
              <div id="pa-form" className="scroll-mt-28 rounded-2xl border border-stone-200 bg-white p-4">
                <div className="flex items-center justify-between gap-3">
                  <h3 className="text-[12px] font-bold uppercase tracking-wider text-stone-400">
                    {draft.id ? "Edit appliance" : "Add an appliance"}
                  </h3>
                  <button
                    type="button"
                    onClick={() => setDraft(null)}
                    className="rounded-lg border border-stone-300 px-3 py-1.5 text-[12.5px] font-bold text-stone-600 transition hover:border-stone-400 hover:bg-stone-50 active:scale-95"
                  >
                    ✕ Close
                  </button>
                </div>

                <div className="mt-3">
                  <span className={labelClass}>Photos</span>
                  <label
                    onDragOver={e => {
                      e.preventDefault();
                      setDropping(true);
                    }}
                    onDragLeave={() => setDropping(false)}
                    onDrop={e => {
                      e.preventDefault();
                      setDropping(false);
                      if (e.dataTransfer.files.length) void uploadPhotos(e.dataTransfer.files);
                    }}
                    className={`block cursor-pointer rounded-xl border-2 border-dashed p-5 text-center text-[13px] transition ${
                      dropping
                        ? "border-[#e0622a] bg-orange-50"
                        : "border-stone-300 bg-stone-50 text-stone-500"
                    }`}
                  >
                    <input
                      type="file"
                      accept="image/*"
                      multiple
                      className="hidden"
                      onChange={e => {
                        if (e.target.files?.length) void uploadPhotos(e.target.files);
                        e.target.value = "";
                      }}
                    />
                    📷 Take a photo, or drag and drop pictures here
                    <span className="mt-1 block text-[11.5px]">
                      The first photo is the one buyers see — drag a photo below to reorder
                    </span>
                  </label>
                  {draft.photoUrls.length > 0 && (
                    <div className="mt-2 flex flex-wrap gap-2">
                      {draft.photoUrls.map((url, n) => (
                        <div
                          key={url}
                          draggable
                          onDragStart={() => setDragIdx(n)}
                          onDragOver={e => e.preventDefault()}
                          onDrop={e => {
                            e.preventDefault();
                            if (dragIdx !== null && dragIdx !== n) movePhoto(dragIdx, n);
                            setDragIdx(null);
                          }}
                          onDragEnd={() => setDragIdx(null)}
                          className={`relative size-16 cursor-grab overflow-hidden rounded-lg border bg-[#eef1f5] active:cursor-grabbing ${
                            dragIdx === n ? "border-[#e0622a] opacity-60" : "border-stone-200"
                          }`}
                        >
                          <img src={url} alt="" className="size-full object-contain" />
                          <div className="absolute inset-x-0 bottom-0 flex justify-between bg-black/55 text-[11px] text-white">
                            <button type="button" onClick={() => movePhoto(n, n - 1)}>
                              ‹
                            </button>
                            <button
                              type="button"
                              onClick={() =>
                                setDraft(d =>
                                  d
                                    ? {
                                        ...d,
                                        photos: d.photos.filter((_, i) => i !== n),
                                        photoUrls: d.photoUrls.filter((_, i) => i !== n),
                                      }
                                    : d,
                                )
                              }
                            >
                              ✕
                            </button>
                            <button type="button" onClick={() => movePhoto(n, n + 1)}>
                              ›
                            </button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                <div className="mt-3">
                  <span className={labelClass}>What is it?</span>
                  <select
                    value={draft.category}
                    onChange={e =>
                      update({
                        category: e.target.value,
                        specs: draft.specs.some(s => s.value)
                          ? draft.specs
                          : (SPEC_SUGGESTIONS[e.target.value] ?? []).map(label => ({
                              label,
                              value: "",
                            })),
                      })
                    }
                    className={inputClass}
                  >
                    {CATEGORIES.map(c => (
                      <option key={c}>{c}</option>
                    ))}
                  </select>
                </div>

                <div className="mt-3">
                  <span className={labelClass}>Make and model</span>
                  <input
                    value={draft.title}
                    onChange={e => update({ title: e.target.value })}
                    placeholder="e.g. Defy 235L double door fridge"
                    className={inputClass}
                  />
                </div>

                <div className="mt-3">
                  <span className={labelClass}>Condition</span>
                  <select
                    value={draft.condition}
                    onChange={e => update({ condition: e.target.value })}
                    className={inputClass}
                  >
                    {CONDITIONS.map(c => (
                      <option key={c}>{c}</option>
                    ))}
                  </select>
                </div>

                <div className="mt-3 grid grid-cols-2 gap-2">
                  <div>
                    <span className={labelClass}>Price (R)</span>
                    <input
                      inputMode="numeric"
                      value={draft.price}
                      onChange={e => update({ price: e.target.value.replace(/\D/g, "") })}
                      className={inputClass}
                    />
                  </div>
                  <div>
                    <span className={labelClass}>Was (optional)</span>
                    <input
                      inputMode="numeric"
                      value={draft.wasPrice}
                      onChange={e => update({ wasPrice: e.target.value.replace(/\D/g, "") })}
                      className={inputClass}
                    />
                  </div>
                </div>

                <div className="mt-3">
                  <span className={labelClass}>Tested on (DD MMM YYYY)</span>
                  <input
                    value={draft.testedOn}
                    onChange={e => update({ testedOn: e.target.value })}
                    placeholder="21 Aug 2026"
                    className={inputClass}
                  />
                </div>

                <div className="mt-3">
                  <span className={labelClass}>Details buyers ask about</span>
                  {draft.specs.map((sp, n) => (
                    <div key={`${sp.label}-${n}`} className="mb-1.5 flex gap-1.5">
                      <input
                        value={sp.label}
                        onChange={e =>
                          update({
                            specs: draft.specs.map((x, i) =>
                              i === n ? { ...x, label: e.target.value } : x,
                            ),
                          })
                        }
                        placeholder="Capacity"
                        className={`${inputClass} w-2/5`}
                      />
                      <input
                        value={sp.value}
                        onChange={e =>
                          update({
                            specs: draft.specs.map((x, i) =>
                              i === n ? { ...x, value: e.target.value } : x,
                            ),
                          })
                        }
                        placeholder={SPEC_HINTS[sp.label] ?? "Type the answer"}
                        className={inputClass}
                      />
                      <button
                        type="button"
                        aria-label="Remove this line"
                        onClick={() =>
                          update({ specs: draft.specs.filter((_, i) => i !== n) })
                        }
                        className="px-1 text-stone-400"
                      >
                        ✕
                      </button>
                    </div>
                  ))}
                  <button
                    type="button"
                    onClick={() => update({ specs: [...draft.specs, { label: "", value: "" }] })}
                    className="text-[13px] font-semibold text-[#e0622a]"
                  >
                    + another detail
                  </button>
                </div>

                <label className="mt-3 flex cursor-pointer items-center gap-2 text-[14px]">
                  <input
                    type="checkbox"
                    checked={draft.freeDelivery}
                    onChange={e => update({ freeDelivery: e.target.checked })}
                    className="size-4 accent-[#e0622a]"
                  />
                  Free delivery on this one
                </label>

                <div className="mt-3">
                  <span className={labelClass}>Anything a buyer should know</span>
                  <textarea
                    rows={3}
                    value={draft.description}
                    onChange={e => update({ description: e.target.value })}
                    placeholder="Small dent on the left side. Freezer works well."
                    className={inputClass}
                  />
                </div>

                {error && (
                  <p className="mt-3 rounded-lg bg-red-50 p-2.5 text-[13px] text-red-700">
                    {error}
                  </p>
                )}

                <button
                  type="button"
                  disabled={busy}
                  onClick={() => void publish()}
                  className="mt-4 w-full rounded-xl bg-[#e0622a] py-3 text-[15px] font-bold text-white disabled:opacity-60"
                >
                  {busy ? "Working…" : draft.id ? "Save changes" : "Publish to the shop"}
                </button>
                <p className="mt-2 text-center text-[12px] text-stone-500">
                  Live on the shop page straight away.
                </p>
                <button
                  type="button"
                  onClick={() => setDraft(null)}
                  className="mt-2 w-full rounded-xl border border-stone-300 py-2.5 text-[13.5px] font-bold text-stone-600 transition hover:bg-stone-50 active:scale-[.99]"
                >
                  Close without saving
                </button>
              </div>
            ) : (
              <div className="rounded-2xl border border-dashed border-stone-300 bg-white p-6 text-center">
                <p className="text-[14px] font-semibold">Nothing being edited</p>
                <p className="mt-1 text-[13px] text-stone-500">
                  Tap <b>Add an appliance</b>, or <b>Edit</b> on anything in the
                  list.
                </p>
              </div>
            )}
          </aside>
        </main>
      )}
    </div>
  );
}

function ShopDetails({ settings }: { settings: ShopSettings | undefined }) {
  const saveSettings = useMutation(api.shop.saveSettings);
  const [form, setForm] = useState<ShopSettings | null>(null);
  const [saved, setSaved] = useState(false);
  const value = form ?? settings;

  if (!value) return <div className="p-10 text-center text-stone-500">Loading…</div>;
  const set = (patch: Partial<ShopSettings>) => {
    setSaved(false);
    setForm({ ...value, ...patch });
  };

  const fields: [keyof ShopSettings, string, string][] = [
    ["shopName", "Shop name", "Prime Appliances"],
    ["tagline", "One line under the name", "Used appliances, tested and guaranteed"],
    ["town", "Town", "Cape Town"],
    ["address", "Street address (optional)", "12 Main Road"],
    ["phoneDisplay", "Phone number as customers see it", "072 677 9489"],
    ["phoneDial", "Same number for the call button", "+27726779489"],
    ["whatsapp", "WhatsApp number (no + or spaces)", "27726779489"],
    ["hours", "Opening hours", "Mon–Fri 8am–5pm · Sat 8am–1pm"],
    ["deliveryNote", "Delivery note in the footer", "Free delivery in town on…"],
  ];

  return (
    <main className="mx-auto max-w-2xl px-4 py-5">
      <div className="rounded-2xl border border-stone-200 bg-white p-5">
        <h2 className="text-[16px] font-extrabold">Your shop details</h2>
        <p className="mt-1 text-[13.5px] text-stone-600">
          This is what customers see everywhere on the shop — the name at the
          top, the number on every button, the hours in the footer.
        </p>

        {fields.map(([key, label, placeholder]) => (
          <div key={key} className="mt-3">
            <span className={labelClass}>{label}</span>
            <input
              value={(value[key] as string) ?? ""}
              placeholder={placeholder}
              onChange={e => set({ [key]: e.target.value } as Partial<ShopSettings>)}
              className={inputClass}
            />
          </div>
        ))}

        <div className="mt-3 grid grid-cols-2 gap-2">
          <div>
            <span className={labelClass}>Delivery fee (R)</span>
            <input
              inputMode="numeric"
              value={value.deliveryFee ? String(value.deliveryFee) : ""}
              onChange={e => set({ deliveryFee: Number(e.target.value.replace(/\D/g, "")) })}
              className={inputClass}
            />
          </div>
          <div>
            <span className={labelClass}>Return days</span>
            <input
              inputMode="numeric"
              value={value.warrantyDays ? String(value.warrantyDays) : ""}
              onChange={e => set({ warrantyDays: Number(e.target.value.replace(/\D/g, "")) })}
              className={inputClass}
            />
          </div>
        </div>

        <button
          type="button"
          onClick={async () => {
            const { shopName, tagline, town, address, phoneDisplay, phoneDial, whatsapp, hours, deliveryFee, deliveryNote, warrantyDays } = value;
            await saveSettings({
              shopName,
              tagline,
              town,
              address,
              phoneDisplay,
              phoneDial,
              whatsapp,
              hours,
              deliveryFee,
              deliveryNote,
              warrantyDays,
            });
            setSaved(true);
          }}
          className="mt-5 w-full rounded-xl bg-[#e0622a] py-3 text-[15px] font-bold text-white"
        >
          Save shop details
        </button>
        {saved && (
          <p className="mt-2 text-center text-[13px] font-semibold text-[#128a5b]">
            Saved — the shop is updated.
          </p>
        )}
      </div>
    </main>
  );
}

async function shrink(file: File): Promise<Blob> {
  if (!file.type.startsWith("image/")) return file;
  try {
    const bitmap = await createImageBitmap(file);
    const long = Math.max(bitmap.width, bitmap.height);
    const ratio = long > 1600 ? 1600 / long : 1;
    if (ratio === 1 && file.size < 700_000) return file;
    const canvas = document.createElement("canvas");
    canvas.width = Math.round(bitmap.width * ratio);
    canvas.height = Math.round(bitmap.height * ratio);
    const ctx = canvas.getContext("2d");
    if (!ctx) return file;
    ctx.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
    bitmap.close();
    const blob = await new Promise<Blob | null>(done =>
      canvas.toBlob(done, "image/jpeg", 0.85),
    );
    return blob && blob.size < file.size ? blob : file;
  } catch {
    return file;
  }
}
