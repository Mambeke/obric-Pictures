import { v } from "convex/values";
import type { Doc } from "./_generated/dataModel";
import { authenticatedMutation, authenticatedQuery } from "./functions";
import { editorEmails, requireAdmin } from "./owner";
import { normalise } from "./tyres";

/** Rows per page in the stock manager. */
const ADMIN_PER_PAGE = 20;

/** Split "195/65R15" (or "195 65 15", "1956515") into its three numbers. */
function splitSize(sizeLabel: string) {
  const raw = sizeLabel.trim().toUpperCase();

  // Imperial / bakkie flotation sizes: 31X10.50R15
  const imp = raw.match(
    /(\d{2}(?:\.\d+)?)\s*X\s*(\d{1,2}(?:\.\d+)?)\s*R?\s*(\d{2})/,
  );
  if (imp)
    return {
      width: imp[1],
      profile: imp[2],
      rim: imp[3],
      sizeKey: normalise(sizeLabel),
      sizeSystem: "lt" as const,
    };

  // Standard metric: 195/65R15, 195 65 15, 195-65-R15
  const metric = raw.match(
    /(\d{3})\s*[^0-9A-Z]*\s*(\d{2})\s*[^0-9]*R?\s*(\d{2})/,
  );
  if (metric)
    return {
      width: metric[1],
      profile: metric[2],
      rim: metric[3],
      sizeKey: normalise(sizeLabel),
      sizeSystem: "metric" as const,
    };

  // Light-truck / older sizes with no profile: 750R16, 7.50R16, 185R14C
  const lt = raw.match(/(\d{3}|\d\.\d{2})\s*R\s*(\d{2})/);
  if (lt)
    return {
      width: lt[1].replace(".", "").padEnd(3, "0"),
      profile: "",
      rim: lt[2],
      sizeKey: normalise(sizeLabel),
      sizeSystem: "lt" as const,
    };

  return {
    width: "",
    profile: "",
    rim: "",
    sizeKey: normalise(sizeLabel),
    sizeSystem: "metric" as const,
  };
}

/** Never let a typo reach the shop front. */
function checkNumbers(price: number, stock: number) {
  if (!Number.isFinite(price) || price < 0)
    throw new Error("Price must be a number of R0 or more.");
  if (!Number.isInteger(stock) || stock < 0)
    throw new Error("Stock must be a whole number, 0 or more.");
}

export const amIAdmin = authenticatedQuery({
  args: {},
  handler: async ctx => {
    try {
      await requireAdmin(ctx, ctx.userId);
      return true;
    } catch {
      return false;
    }
  },
});

export const listAll = authenticatedQuery({
  args: {
    pane: v.optional(v.union(v.literal("live"), v.literal("sold"))),
    q: v.optional(v.string()),
    page: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    await requireAdmin(ctx, ctx.userId);
    const rows = await ctx.db.query("tyres").collect();

    const needle = (args.q ?? "").trim().toUpperCase();
    const wanted = rows
      .filter(t => (args.pane === "sold" ? !t.active : t.active))
      .filter(
        t =>
          !needle ||
          normalise(t.sizeLabel).includes(normalise(needle)) ||
          t.sizeLabel.toUpperCase().includes(needle) ||
          t.brand.toUpperCase().includes(needle),
      )
      .sort((a, b) => b.createdAt - a.createdAt);

    const total = wanted.length;
    const pages = Math.max(1, Math.ceil(total / ADMIN_PER_PAGE));
    const page = Math.min(Math.max(1, args.page ?? 1), pages);
    const slice = wanted.slice(
      (page - 1) * ADMIN_PER_PAGE,
      page * ADMIN_PER_PAGE,
    );

    // Reading the documents is cheap; resolving storage URLs is not. Only the
    // rows actually on screen get a thumbnail, so the cost of this query stops
    // growing with the size of the shop. Searching and counting still cover
    // all stock, which is the whole point of the search box.
    return {
      rows: await Promise.all(
        slice.map(async (t: Doc<"tyres">) => ({
          id: t._id,
          sizeLabel: t.sizeLabel,
          brand: t.brand,
          condition: t.condition,
          price: t.price,
          stock: t.stock,
          notes: t.notes ?? "",
          active: t.active,
          thumb: t.photos.length ? await ctx.storage.getUrl(t.photos[0]) : null,
          photoCount: t.photos.length + (t.photoUrls ?? []).length,
          demoUrls: t.photoUrls ?? [],
        })),
      ),
      total,
      page,
      pages,
      perPage: ADMIN_PER_PAGE,
      counts: {
        live: rows.filter(t => t.active).length,
        sold: rows.filter(t => !t.active).length,
      },
    };
  },
});

export const photosFor = authenticatedQuery({
  args: { id: v.id("tyres") },
  handler: async (ctx, { id }) => {
    await requireAdmin(ctx, ctx.userId);
    const t = await ctx.db.get(id);
    if (!t) return [];
    // Pairs, and NEVER filtered. The form used to receive a plain list of URLs
    // with unresolvable ones dropped, while the id list came from a different
    // query — so one photo whose URL failed to resolve shifted every index
    // after it, and the delete button removed the wrong photo. Since deletes
    // are now permanent, that mistake destroys a photo. Keep the pairing
    // intact and let the form key everything by storage id.
    return Promise.all(
      t.photos.map(async p => ({
        id: p,
        url: (await ctx.storage.getUrl(p)) ?? "",
      })),
    );
  },
});

/** The browser PUTs each photo straight to Convex storage using this URL. */
export const uploadUrl = authenticatedMutation({
  args: {},
  handler: async ctx => {
    await requireAdmin(ctx, ctx.userId);
    return await ctx.storage.generateUploadUrl();
  },
});

export const create = authenticatedMutation({
  args: {
    sizeLabel: v.string(),
    brand: v.string(),
    condition: v.union(v.literal("used"), v.literal("new")),
    price: v.number(),
    stock: v.number(),
    notes: v.optional(v.string()),
    photos: v.array(v.id("_storage")),
  },
  handler: async (ctx, args) => {
    await requireAdmin(ctx, ctx.userId);
    checkNumbers(args.price, args.stock);
    const size = splitSize(args.sizeLabel);
    if (!size.width)
      throw new Error(`Could not read a tyre size from "${args.sizeLabel}"`);
    return await ctx.db.insert("tyres", {
      ...args,
      ...size,
      sizeLabel: args.sizeLabel.trim().toUpperCase(),
      active: true,
      createdAt: Date.now(),
    });
  },
});

export const update = authenticatedMutation({
  args: {
    id: v.id("tyres"),
    sizeLabel: v.string(),
    brand: v.string(),
    condition: v.union(v.literal("used"), v.literal("new")),
    price: v.number(),
    stock: v.number(),
    notes: v.optional(v.string()),
    photos: v.array(v.id("_storage")),
    photoUrls: v.optional(v.array(v.string())),
    // The photo list the form was opened with. Lets the server refuse a save
    // built on a stale view instead of deleting photos it never saw.
    expectedPhotos: v.optional(v.array(v.id("_storage"))),
  },
  handler: async (ctx, { id, expectedPhotos, ...rest }) => {
    await requireAdmin(ctx, ctx.userId);
    checkNumbers(rest.price, rest.stock);
    const size = splitSize(rest.sizeLabel);
    if (!size.width)
      throw new Error(`Could not read a tyre size from "${rest.sizeLabel}"`);
    const before = await ctx.db.get(id);
    if (before) {
      // Deleting a photo is permanent, so refuse to act on a stale form. If
      // the tyre's photos changed since this form was opened — a second
      // staffer editing, or a half-loaded page — the save is rejected rather
      // than quietly destroying whatever the form did not know about.
      if (expectedPhotos) {
        const then = before.photos.map(String).join(",");
        const claimed = expectedPhotos.map(String).join(",");
        if (then !== claimed)
          throw new Error(
            "This tyre's photos changed while you were editing it. " +
              "Close the form, open the tyre again, and redo your change.",
          );
      }
      // Photos dropped from the list used to stay in storage forever, costing
      // space nobody could see. Delete the difference.
      const kept = new Set(rest.photos.map(String));
      for (const old of before.photos)
        if (!kept.has(String(old))) await ctx.storage.delete(old);
    }
    await ctx.db.patch(id, {
      ...rest,
      ...size,
      photoUrls: rest.photoUrls ?? [],
      sizeLabel: rest.sizeLabel.trim().toUpperCase(),
    });
  },
});

/** Sold out / back in stock — keeps the tyre and its photos for next time. */
export const setActive = authenticatedMutation({
  args: { id: v.id("tyres"), active: v.boolean() },
  handler: async (ctx, { id, active }) => {
    await requireAdmin(ctx, ctx.userId);
    await ctx.db.patch(id, { active });
  },
});

export const remove = authenticatedMutation({
  args: { id: v.id("tyres") },
  handler: async (ctx, { id }) => {
    await requireAdmin(ctx, ctx.userId);
    const t = await ctx.db.get(id);
    if (t) for (const p of t.photos) await ctx.storage.delete(p);
    await ctx.db.delete(id);
  },
});

/**
 * List every account that exists, flagging the ones that are not on the staff
 * allow-list. Closing public sign-up stopped new registrations; it did nothing
 * about accounts made while the door was open. This is how you see them.
 */
export const accountAudit = authenticatedQuery({
  args: {},
  handler: async ctx => {
    await requireAdmin(ctx, ctx.userId);
    const allowed = await editorEmails(ctx);
    const users = await ctx.db.query("users").collect();
    return users.map(u => ({
      id: u._id,
      email: u.email ?? "(no email)",
      staff: allowed.includes((u.email ?? "").toLowerCase()),
    }));
  },
});

/**
 * Remove an account that is not on the staff allow-list, along with its login
 * credentials. Refuses to touch staff accounts, so this cannot be used to lock
 * the owner out of his own shop.
 */
export const purgeStranger = authenticatedMutation({
  args: { id: v.id("users") },
  handler: async (ctx, { id }) => {
    await requireAdmin(ctx, ctx.userId);
    const user = await ctx.db.get(id);
    if (!user) return;
    const email = (user.email ?? "").toLowerCase();
    if ((await editorEmails(ctx)).includes(email))
      throw new Error(
        "That account is on the staff list — remove it there first.",
      );
    for (const acc of await ctx.db.query("authAccounts").collect())
      if (acc.userId === id) await ctx.db.delete(acc._id);
    for (const sess of await ctx.db.query("authSessions").collect())
      if (sess.userId === id) await ctx.db.delete(sess._id);
    await ctx.db.delete(id);
  },
});
