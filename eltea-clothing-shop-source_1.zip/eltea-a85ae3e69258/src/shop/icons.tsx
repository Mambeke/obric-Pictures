export const SearchIcon = ({ stroke = "#181017" }: { stroke?: string }) => (
  <svg viewBox="0 0 24 24" fill="none" stroke={stroke} strokeWidth="2.2" aria-hidden="true">
    <circle cx="11" cy="11" r="7" />
    <path d="M20 20l-4.2-4.2" />
  </svg>
);

export const WhatsAppIcon = () => (
  <svg viewBox="0 0 24 24" aria-hidden="true">
    <path d="M12 2a10 10 0 00-8.6 15.1L2 22l5-1.3A10 10 0 1012 2zm0 18a8 8 0 01-4.1-1.1l-.3-.2-3 .8.8-2.9-.2-.3A8 8 0 1112 20zm4.5-5.9c-.2-.1-1.5-.7-1.7-.8s-.4-.1-.5.1l-.7.9c-.1.2-.3.2-.5.1a6.5 6.5 0 01-3.2-2.8c-.1-.2 0-.4.1-.5l.6-.7c.1-.2.1-.3 0-.5l-.7-1.7c-.2-.4-.4-.4-.5-.4h-.5c-.2 0-.5.1-.7.4a2.9 2.9 0 00-.9 2.1c0 1.2.9 2.4 1 2.6a9.4 9.4 0 003.6 3.2c1.6.7 2.2.6 2.6.6s1.4-.3 1.8-.9.4-1.1.3-1.2z" />
  </svg>
);

export const CartIcon = () => (
  <svg viewBox="0 0 24 24" aria-hidden="true">
    <path d="M7 4h-2l-1 2H2v2h1.6l2.5 8.2A2 2 0 008 18h9a2 2 0 001.9-1.4L21.5 8H6.6L6 6h1zM9 20a1.6 1.6 0 100 3.2A1.6 1.6 0 009 20zm8 0a1.6 1.6 0 100 3.2 1.6 1.6 0 000-3.2z" />
  </svg>
);

export const FilterIcon = () => (
  <svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" strokeWidth="2.2" aria-hidden="true">
    <path d="M4 6h16M7 12h10M10 18h4" />
  </svg>
);
