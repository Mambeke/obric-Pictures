export const APP_NAME = "Eltea Boutique";
