import { v } from "convex/values";
import type { Doc, Id } from "./_generated/dataModel";
import { mutation, query } from "./_generated/server";
import { authenticatedMutation, authenticatedQuery } from "./functions";
import { isOwnerEmail } from "./shopConfig";

const variantValidator = v.object({
  storage: v.string(),
  price: v.number(),
  wasPrice: v.optional(v.number()),
  inStock: v.number(),
});

async function withPhotoUrls(
  ctx: { storage: { getUrl: (id: Id<"_storage">) => Promise<string | null> } },
  phone: Doc<"phones">,
) {
  const photoUrls: string[] = [];
  for (const id of phone.photos) {
    if (id.startsWith("http")) {
      // Sample stock is pictured with hosted photos, not uploaded files.
      photoUrls.push(id);
      continue;
    }
    try {
      const url = await ctx.storage.getUrl(id as Id<"_storage">);
      if (url) photoUrls.push(url);
    } catch {
      // ignore missing files
    }
  }
  return { ...phone, photoUrls };
}

/** Public storefront listing — anyone may read the catalogue. */
export const listPhones = query({
  args: {},
  handler: async ctx => {
    const phones = await ctx.db.query("phones").order("desc").collect();
    return await Promise.all(phones.map(p => withPhotoUrls(ctx, p)));
  },
});

/** Public single product. */
export const getPhone = query({
  args: { id: v.id("phones") },
  handler: async (ctx, args) => {
    const phone = await ctx.db.get(args.id);
    if (!phone) return null;
    return await withPhotoUrls(ctx, phone);
  },
});

async function assertOwner(ctx: {
  db: { get: (id: Id<"users">) => Promise<Doc<"users"> | null> };
  userId: Id<"users">;
}) {
  const user = await ctx.db.get(ctx.userId);
  if (!isOwnerEmail(user?.email)) {
    throw new Error("Not allowed — this account may not manage stock.");
  }
  return user;
}

/** Is the signed-in account allowed into the admin area? */
export const amIOwner = authenticatedQuery({
  args: {},
  handler: async ctx => {
    const user = await ctx.db.get(ctx.userId);
    return { isOwner: isOwnerEmail(user?.email), email: user?.email ?? null };
  },
});

export const generateUploadUrl = authenticatedMutation({
  args: {},
  handler: async ctx => {
    await assertOwner(ctx);
    return await ctx.storage.generateUploadUrl();
  },
});

export const savePhone = authenticatedMutation({
  args: {
    id: v.optional(v.id("phones")),
    brand: v.string(),
    model: v.string(),
    condition: v.string(),
    colour: v.string(),
    description: v.optional(v.string()),
    grade: v.optional(v.string()),
    battery: v.optional(v.number()),
    photos: v.array(v.string()),
    variants: v.array(variantValidator),
  },
  handler: async (ctx, args) => {
    await assertOwner(ctx);
    const { id, ...fields } = args;
    if (id) {
      // Once the owner edits a phone it is his own stock, not sample stock.
      await ctx.db.patch(id, { ...fields, demo: false });
      return id;
    }
    return await ctx.db.insert("phones", {
      ...fields,
      demo: false,
      createdAt: Date.now(),
    });
  },
});

/**
 * Mark a listing sold (every storage size to zero) or put it back on sale.
 * Sold listings stay in the shop's back office so they can be revived when
 * the same phone comes in again.
 */
export const setSold = authenticatedMutation({
  args: { id: v.id("phones"), sold: v.boolean() },
  handler: async (ctx, args) => {
    await assertOwner(ctx);
    const phone = await ctx.db.get(args.id);
    if (!phone) throw new Error("That phone is no longer there.");
    await ctx.db.patch(args.id, {
      demo: false,
      variants: phone.variants.map(variant => ({
        ...variant,
        inStock: args.sold ? 0 : Math.max(variant.inStock, 1),
      })),
    });
    return { success: true };
  },
});

export const deletePhone = authenticatedMutation({
  args: { id: v.id("phones") },
  handler: async (ctx, args) => {
    await assertOwner(ctx);
    await ctx.db.delete(args.id);
    return { success: true };
  },
});

/** Remove every phone that was loaded as sample stock. */
export const clearDemoStock = authenticatedMutation({
  args: {},
  handler: async ctx => {
    await assertOwner(ctx);
    const phones = await ctx.db.query("phones").collect();
    let removed = 0;
    for (const p of phones) {
      if (p.demo) {
        await ctx.db.delete(p._id);
        removed++;
      }
    }
    return { removed };
  },
});

/** One-off seeding of sample stock, used at build time. */
/** Fill in descriptions on existing listings without touching anything else. */
export const setDescriptions = mutation({
  args: {
    secret: v.string(),
    items: v.array(v.object({ id: v.id("phones"), description: v.string() })),
  },
  handler: async (ctx, args) => {
    if (args.secret !== "cellconnecta-seed-2026") {
      throw new Error("Bad seed secret");
    }
    let updated = 0;
    for (const item of args.items) {
      await ctx.db.patch(item.id, { description: item.description });
      updated++;
    }
    return { updated };
  },
});


/** Replace the photos on one listing (secret-guarded, admin-safe). */
export const setPhotos = mutation({
  args: {
    secret: v.string(),
    items: v.array(v.object({ id: v.id("phones"), photos: v.array(v.string()) })),
  },
  handler: async (ctx, args) => {
    if (args.secret !== "cellconnecta-seed-2026") {
      throw new Error("Bad seed secret");
    }
    let updated = 0;
    for (const item of args.items) {
      await ctx.db.patch(item.id, { photos: item.photos });
      updated++;
    }
    return { updated };
  },
});

export const seedDemo = mutation({
  args: {
    secret: v.string(),
    phones: v.array(
      v.object({
        brand: v.string(),
        model: v.string(),
        condition: v.string(),
        colour: v.string(),
        description: v.optional(v.string()),
        grade: v.optional(v.string()),
        battery: v.optional(v.number()),
        photos: v.optional(v.array(v.string())),
        variants: v.array(variantValidator),
      }),
    ),
    moveCertifiedToPreOwned: v.optional(v.boolean()),
  },
  handler: async (ctx, args) => {
    if (args.secret !== "cellconnecta-seed-2026") {
      throw new Error("Bad seed secret");
    }
    const existing = await ctx.db.query("phones").collect();
    let moved = 0;
    for (const p of existing) {
      if (p.demo) {
        await ctx.db.delete(p._id);
        continue;
      }
      if (
        args.moveCertifiedToPreOwned &&
        p.condition === "certified_refurbished"
      ) {
        await ctx.db.patch(p._id, { condition: "pre_owned" });
        moved++;
      }
    }
    for (const p of args.phones) {
      const { photos, ...rest } = p;
      await ctx.db.insert("phones", {
        ...rest,
        photos: photos ?? [],
        demo: true,
        createdAt: Date.now(),
      });
    }
    return { inserted: args.phones.length, moved };
  },
});
