# Prime Appliances Space
- [ ] convex schema (appliances + shopSettings) + shop.ts functions
- [ ] shop config/types/search/Chrome/Gallery/SearchBox
- [ ] StorefrontPage (categories, filters, search, sold shelf, sell-us section)
- [ ] ProductPage (gallery, specs, condition, tested-on, WhatsApp/call)
- [ ] AdminPage (add/edit/mark sold/delete, browser image shrink, shop settings)
- [ ] routes + index.css + owner emails
- [ ] seed demo stock (generated photos)
- [ ] sync:build, e2e test, screenshots
- [ ] deploy preview -> show Mambeke -> production on approval
