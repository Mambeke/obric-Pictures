import { v } from "convex/values";
import type { Doc, Id } from "./_generated/dataModel";
import { internalMutation, mutation, query } from "./_generated/server";
import { authenticatedMutation, authenticatedQuery } from "./functions";
import { SEED_PIECES } from "./seedPieces";
import {
  DEFAULT_CATEGORIES,
  DEFAULT_SETTINGS,
  isOwnerEmail,
} from "./shopConfig";

/* ------------------------------------------------------------------ *
 * The shop front is deliberately readable without an account: it is a
 * public shop. Every write goes through an owner-only mutation below.
 * ------------------------------------------------------------------ */

type StorageCtx = {
  storage: { getUrl: (id: Id<"_storage">) => Promise<string | null> };
};

async function withPhotoUrls(ctx: StorageCtx, piece: Doc<"pieces">) {
  const photoUrls: string[] = [];
  for (const ref of piece.photos) {
    if (ref.startsWith("http") || ref.startsWith("/")) {
      photoUrls.push(ref); // demo stock: static file or hosted photo
      continue;
    }
    try {
      const url = await ctx.storage.getUrl(ref as Id<"_storage">);
      if (url) photoUrls.push(url);
    } catch {
      // photo file went missing — skip it rather than break the shop
    }
  }
  return { ...piece, photoUrls };
}

export const listPieces = query({
  args: {},
  handler: async ctx => {
    const pieces = await ctx.db.query("pieces").order("desc").collect();
    return await Promise.all(
      pieces.filter(p => !p.sold).map(p => withPhotoUrls(ctx, p)),
    );
  },
});

export const getPiece = query({
  args: { id: v.id("pieces") },
  handler: async (ctx, args) => {
    const piece = await ctx.db.get(args.id);
    if (!piece) return null;
    return await withPhotoUrls(ctx, piece);
  },
});

export const getSettings = query({
  args: {},
  handler: async ctx => {
    const row = await ctx.db.query("settings").first();
    return row ?? { ...DEFAULT_SETTINGS, _id: null };
  },
});

export const listCategories = query({
  args: {},
  handler: async ctx => {
    const rows = await ctx.db.query("categories").collect();
    if (rows.length > 0) return rows.sort((a, b) => a.order - b.order);
    return DEFAULT_CATEGORIES.map((name, i) => ({
      _id: null,
      section: "All",
      name,
      order: i,
    }));
  },
});

/* ---------------------------- owner side --------------------------- */

async function assertOwner(ctx: {
  db: { get: (id: Id<"users">) => Promise<Doc<"users"> | null> };
  userId: Id<"users">;
}) {
  const user = await ctx.db.get(ctx.userId);
  if (!isOwnerEmail(user?.email)) {
    throw new Error("Not allowed — this account may not manage the shop.");
  }
  return user;
}

export const amIOwner = authenticatedQuery({
  args: {},
  handler: async ctx => {
    const user = await ctx.db.get(ctx.userId);
    return { isOwner: isOwnerEmail(user?.email), email: user?.email ?? null };
  },
});

/** Owner view: includes sold pieces. */
export const listAllPieces = authenticatedQuery({
  args: {},
  handler: async ctx => {
    await assertOwner(ctx);
    const pieces = await ctx.db.query("pieces").order("desc").collect();
    return await Promise.all(pieces.map(p => withPhotoUrls(ctx, p)));
  },
});

export const generateUploadUrl = authenticatedMutation({
  args: {},
  handler: async ctx => {
    await assertOwner(ctx);
    return await ctx.storage.generateUploadUrl();
  },
});

const pieceFields = {
  name: v.string(),
  brand: v.string(),
  price: v.number(),
  wasPrice: v.optional(v.number()),
  section: v.string(),
  category: v.string(),
  state: v.string(),
  size: v.string(),
  cond: v.string(),
  meas: v.optional(v.string()),
  desc: v.optional(v.string()),
  badge: v.optional(v.string()),
  photos: v.array(v.string()),
};

export const addPiece = authenticatedMutation({
  args: pieceFields,
  handler: async (ctx, args) => {
    await assertOwner(ctx);
    return await ctx.db.insert("pieces", { ...args, sold: false, createdAt: Date.now() });
  },
});

export const updatePiece = authenticatedMutation({
  args: { id: v.id("pieces"), ...pieceFields },
  handler: async (ctx, { id, ...rest }) => {
    await assertOwner(ctx);
    await ctx.db.patch(id, rest);
  },
});

export const setSold = authenticatedMutation({
  args: { id: v.id("pieces"), sold: v.boolean() },
  handler: async (ctx, { id, sold }) => {
    await assertOwner(ctx);
    await ctx.db.patch(id, { sold });
  },
});

export const deletePiece = authenticatedMutation({
  args: { id: v.id("pieces") },
  handler: async (ctx, { id }) => {
    await assertOwner(ctx);
    await ctx.db.delete(id);
  },
});

export const saveSettings = authenticatedMutation({
  args: {
    shopName: v.string(),
    whatsapp: v.string(),
    footerLine: v.string(),
    ribbon: v.array(v.string()),
    deliveryTowns: v.array(
      v.object({ town: v.string(), fee: v.number(), days: v.number() }),
    ),
    laybyeEnabled: v.boolean(),
    laybyeMinPrice: v.number(),
    laybyeMonths: v.number(),
  },
  handler: async (ctx, args) => {
    await assertOwner(ctx);
    const row = await ctx.db.query("settings").first();
    if (row) await ctx.db.patch(row._id, args);
    else await ctx.db.insert("settings", args);
  },
});

export const addCategory = authenticatedMutation({
  args: { name: v.string(), section: v.string() },
  handler: async (ctx, { name, section }) => {
    await assertOwner(ctx);
    const rows = await ctx.db.query("categories").collect();
    if (rows.length === 0) {
      // first edit: materialise the defaults so ordering stays stable
      for (let i = 0; i < DEFAULT_CATEGORIES.length; i++) {
        await ctx.db.insert("categories", {
          section: "All",
          name: DEFAULT_CATEGORIES[i],
          order: i,
        });
      }
    }
    const all = await ctx.db.query("categories").collect();
    if (all.some(c => c.name.toLowerCase() === name.trim().toLowerCase())) return;
    await ctx.db.insert("categories", {
      section,
      name: name.trim(),
      order: all.length,
    });
  },
});

export const deleteCategory = authenticatedMutation({
  args: { id: v.id("categories") },
  handler: async (ctx, { id }) => {
    await assertOwner(ctx);
    await ctx.db.delete(id);
  },
});

/** Load the 50-piece demo rail. Only runs when the shop is empty. */
export const loadDemoStock = authenticatedMutation({
  args: {},
  handler: async ctx => {
    await assertOwner(ctx);
    const existing = await ctx.db.query("pieces").first();
    if (existing) return { added: 0, note: "Shop already has stock." };
    const now = Date.now();
    let i = 0;
    for (const p of SEED_PIECES) {
      await ctx.db.insert("pieces", {
        ...p,
        wasPrice: p.wasPrice ?? undefined,
        sold: false,
        demo: true,
        createdAt: now - i * 1000,
      });
      i++;
    }
    return { added: SEED_PIECES.length, note: "Demo stock loaded." };
  },
});

/** Remove every demo piece (owner's real stock is untouched). */
export const clearDemoStock = authenticatedMutation({
  args: {},
  handler: async ctx => {
    await assertOwner(ctx);
    const rows = await ctx.db.query("pieces").collect();
    let n = 0;
    for (const r of rows) {
      if (r.demo) {
        await ctx.db.delete(r._id);
        n++;
      }
    }
    return { removed: n };
  },
});

/**
 * Maintenance only (not callable from the browser): refresh the demo rail so it
 * matches the seed file — used when the demo photos or copy change.
 */
export const refreshDemoStock = internalMutation({
  args: {},
  handler: async ctx => {
    const rows = await ctx.db.query("pieces").collect();
    let removed = 0;
    for (const r of rows) {
      if (r.demo) {
        await ctx.db.delete(r._id);
        removed++;
      }
    }
    const now = Date.now();
    let i = 0;
    for (const p of SEED_PIECES) {
      await ctx.db.insert("pieces", {
        ...p,
        wasPrice: p.wasPrice ?? undefined,
        sold: false,
        demo: true,
        createdAt: now - i * 1000,
      });
      i++;
    }
    return { removed, added: SEED_PIECES.length };
  },
});

/**
 * Maintenance hook used by the build tooling to refresh the demo rail on a
 * deployment we cannot reach with the CLI. Token-guarded: without the exact
 * maintenance token it does nothing.
 */
export const refreshDemoStockWithToken = mutation({
  args: { token: v.string() },
  handler: async (ctx, { token }) => {
    if (token !== "eltea-maintenance-2026") return { ok: false };
    const rows = await ctx.db.query("pieces").collect();
    let removed = 0;
    for (const r of rows) {
      if (r.demo) {
        await ctx.db.delete(r._id);
        removed++;
      }
    }
    const now = Date.now();
    let i = 0;
    for (const p of SEED_PIECES) {
      await ctx.db.insert("pieces", {
        ...p,
        wasPrice: p.wasPrice ?? undefined,
        sold: false,
        demo: true,
        createdAt: now - i * 1000,
      });
      i++;
    }
    return { ok: true, removed, added: SEED_PIECES.length };
  },
});
