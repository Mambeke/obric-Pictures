import { runTest } from "./auth";

runTest("Eltea Boutique shop + owner panel", async helper => {
  const { page } = helper;
  await page.setViewportSize({ width: 390, height: 844 });

  // 1. owner panel: load the demo rail if the shop is empty
  await helper.goto("/owner");
  await page.waitForTimeout(2500);
  const stockTab = page.locator("button", { hasText: /My stock/ }).first();
  await stockTab.click();
  await page.waitForTimeout(1500);
  const loadBtn = page.locator("button", { hasText: "Load the 50-piece demo rail" });
  if (await loadBtn.isVisible().catch(() => false)) {
    await loadBtn.click();
    await page.waitForTimeout(4000);
  }

  // 2. shop front
  await helper.goto("/");
  await page.waitForTimeout(2500);
  const tabs = await page.locator(".rail .tab").allTextContents();
  console.log("section tabs:", tabs);
  if (!tabs.some(t => t.includes("All stock ("))) {
    throw new Error(`Section rail missing bracketed counts: ${JSON.stringify(tabs)}`);
  }
  const cards = await page.locator(".card").count();
  console.log("cards on shop:", cards);
  // the shop now pages after eight rows, so a phone shows 2 x 8 = 16 cards
  if (cards < 8) throw new Error(`Expected a full page of cards, saw ${cards}`);
  const pinfo = await page.locator(".pinfo").first().textContent();
  console.log("pager:", pinfo);
  if (!pinfo?.includes("50 pieces")) throw new Error(`Pager missing the 50-piece total: ${pinfo}`);

  const wide = await page.evaluate(
    () => document.documentElement.scrollWidth - document.documentElement.clientWidth,
  );
  if (wide > 1) throw new Error(`Horizontal overflow on mobile: ${wide}px`);

  // 3. state tabs
  await page.locator(".tab2", { hasText: "PRE-OWNED" }).click();
  await page.waitForTimeout(700);
  const line = await page.locator(".stateline").textContent();
  console.log("state line:", line);
  if (!line?.includes("bero")) throw new Error("Pre-owned explainer missing");

  // 4. forgiving search
  await page.locator(".searchic").click();
  await page.locator("input.search").fill("shors");
  await page.waitForTimeout(900);
  const didyou = await page.locator(".didyou").first().textContent().catch(() => null);
  const shown = await page.locator(".card").count();
  console.log("typo search ->", shown, "cards, hint:", didyou);
  if (shown === 0 && !didyou?.includes("shoes")) {
    throw new Error("Typo search gave neither results nor a correction");
  }
  await page.locator("input.search").fill("");
  await page.waitForTimeout(600);

  // 5. product page + WhatsApp message
  await page.locator(".card").first().click();
  await page.waitForTimeout(1800);
  await page.locator(".deliv input[type=checkbox]").check();
  await page.waitForTimeout(600);
  const href = await page.locator("a.btn.wa").first().getAttribute("href");
  const msg = decodeURIComponent((href ?? "").split("text=")[1] ?? "");
  console.log("WHATSAPP MESSAGE:\n" + msg);
  for (const must of ["I want this piece", ". Size :", ". Price :", "Total with delivery"]) {
    if (!msg.includes(must)) throw new Error(`WhatsApp message missing "${must}"`);
  }
  const back = await page.locator("button", { hasText: "Back to the shop" }).first().isVisible();
  if (!back) throw new Error("Static back bar missing on the product page");

  // 6. cart
  await page.locator(".stickybtns .btn.gh").click();
  await page.waitForTimeout(900);
  const total = await page.locator(".drawer .tot").textContent();
  console.log("cart total:", total);
  if (!total?.includes("$")) throw new Error("Cart drawer did not open with a total");
}).catch(() => process.exit(1));
