import { Link } from "react-router";
import type { ShopSettings } from "./config";
import { waLink } from "./config";

export function WhatsAppIcon({ className = "size-4" }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" className={className} aria-hidden>
      <path d="M17.47 14.38c-.3-.15-1.75-.86-2.02-.96-.27-.1-.47-.15-.67.15-.2.3-.77.96-.94 1.16-.17.2-.35.22-.64.07-.3-.15-1.25-.46-2.38-1.47-.88-.78-1.47-1.75-1.64-2.05-.17-.3-.02-.46.13-.6.13-.13.3-.35.45-.52.15-.17.2-.3.3-.5.1-.2.05-.37-.02-.52-.08-.15-.67-1.6-.92-2.2-.24-.58-.49-.5-.67-.51h-.57c-.2 0-.52.07-.79.37-.27.3-1.04 1.01-1.04 2.47 0 1.46 1.06 2.87 1.21 3.07.15.2 2.09 3.2 5.07 4.48.71.3 1.26.49 1.69.63.71.22 1.36.19 1.87.12.57-.09 1.75-.72 2-1.41.25-.69.25-1.28.17-1.41-.07-.13-.27-.2-.57-.35z" />
      <path d="M12.04 2C6.6 2 2.18 6.42 2.18 11.86c0 1.74.46 3.44 1.32 4.94L2 22l5.34-1.4a9.8 9.8 0 0 0 4.7 1.2h.01c5.43 0 9.85-4.42 9.85-9.86A9.79 9.79 0 0 0 12.04 2zm0 17.96h-.01a8.2 8.2 0 0 1-4.16-1.14l-.3-.18-3.1.81.83-3.02-.2-.31a8.15 8.15 0 0 1-1.25-4.36c0-4.52 3.68-8.2 8.2-8.2 2.19 0 4.25.86 5.8 2.41a8.15 8.15 0 0 1 2.4 5.8c0 4.52-3.68 8.19-8.2 8.19z" />
    </svg>
  );
}

export function PhoneIcon({ className = "size-4" }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" className={className} aria-hidden>
      <path d="M6.62 10.79a15.05 15.05 0 0 0 6.59 6.59l2.2-2.2a1 1 0 0 1 1.02-.24c1.12.37 2.33.57 3.57.57a1 1 0 0 1 1 1V20a1 1 0 0 1-1 1A17 17 0 0 1 3 4a1 1 0 0 1 1-1h3.5a1 1 0 0 1 1 1c0 1.25.2 2.45.57 3.57a1 1 0 0 1-.25 1.02l-2.2 2.2z" />
    </svg>
  );
}

function initials(name: string) {
  return name
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map(w => w[0]?.toUpperCase() ?? "")
    .join("");
}

export function ShopHeader({ s }: { s: ShopSettings }) {
  return (
    <header className="sticky top-0 z-40 bg-[#111820] text-white shadow-sm">
      <div className="mx-auto flex h-13 max-w-[1560px] items-center gap-2 px-3 py-2 sm:h-14 sm:px-5">
        <Link to="/" className="flex min-w-0 items-center gap-2">
          <span className="grid size-8 shrink-0 place-items-center rounded-lg bg-[#e0622a] text-[13px] font-black">
            {initials(s.shopName) || "PA"}
          </span>
          <span className="truncate text-[15px] font-extrabold tracking-tight sm:text-lg">
            {s.shopName}
          </span>
        </Link>

        <div className="ml-auto flex items-center gap-2">
          <a
            href={waLink(s.whatsapp, `Hi ${s.shopName}, I'd like to ask about an appliance.`)}
            target="_blank"
            rel="noreferrer"
            className="flex items-center gap-1.5 rounded-full bg-[#25d366] px-3 py-1.5 text-[13px] font-bold text-white shadow-sm transition hover:bg-[#1eb85a] active:scale-95 sm:px-4 sm:text-sm"
          >
            <WhatsAppIcon />
            WhatsApp
          </a>
          <a
            href={`tel:${s.phoneDial}`}
            aria-label={`Call ${s.phoneDisplay}`}
            className="flex items-center gap-1.5 rounded-full border border-white/30 px-3 py-1.5 text-[13px] font-semibold transition active:scale-95 sm:px-4 sm:text-sm"
          >
            <PhoneIcon />
            <span className="hidden sm:inline">{s.phoneDisplay}</span>
          </a>
        </div>
      </div>
      <Ribbon s={s} />
    </header>
  );
}

/**
 * The ribbon under the header: one continuous moving line of promises, the way
 * a shop's LED sign runs. The strip is rendered twice and slid by exactly half
 * its width, so the loop has no seam. It holds still for anyone who has asked
 * their phone to reduce motion.
 */
function Ribbon({ s }: { s: ShopSettings }) {
  const promises = [
    "Every item switched on and tested",
    `${s.warrantyDays}-day works-or-return`,
    `Delivery in ${s.town} — collection welcome`,
    "Cash, card or EFT",
    "No listing fee — we photograph it for you",
  ];
  const strip = (
    <div className="pa-ribbon-strip" aria-hidden={false}>
      {promises.map(t => (
        <span key={t} className="pa-ribbon-item">
          <span className="pa-ribbon-tick">✓</span>
          {t}
        </span>
      ))}
    </div>
  );
  return (
    <div className="pa-ribbon bg-[#e0622a] text-white">
      <div className="pa-ribbon-track">
        {strip}
        {/* Second copy: it is what makes the loop seamless, not new content. */}
        <div className="pa-ribbon-strip" aria-hidden="true">
          {promises.map(t => (
            <span key={t} className="pa-ribbon-item">
              <span className="pa-ribbon-tick">✓</span>
              {t}
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}

export function ShopFooter({ s }: { s: ShopSettings }) {
  return (
    <footer className="mt-14">
      <div className="bg-[#e0622a] px-4 py-10 text-center text-white">
        <h3 className="text-xl font-extrabold sm:text-2xl">
          Looking for something you can't see here?
        </h3>
        <p className="mx-auto mt-2 max-w-md text-sm text-orange-50">
          Tell us what you need. Stock changes every week and we can keep an eye
          out for you.
        </p>
        <div className="mx-auto mt-5 flex max-w-lg items-stretch justify-center gap-2.5">
          <a
            href={waLink(s.whatsapp, `Hi ${s.shopName}, I'm looking for an appliance. Can you help?`)}
            target="_blank"
            rel="noreferrer"
            className="flex flex-1 items-center justify-center gap-2 whitespace-nowrap rounded-full bg-[#25d366] px-4 py-3 text-[13px] font-bold text-white shadow-lg transition hover:bg-[#1eb85a] active:scale-95 sm:px-6 sm:text-sm"
          >
            <WhatsAppIcon /> WhatsApp us
          </a>
          <a
            href={`tel:${s.phoneDial}`}
            className="flex flex-1 items-center justify-center gap-2 whitespace-nowrap rounded-full border-2 border-white/70 px-4 py-3 text-[13px] font-bold transition active:scale-95 sm:px-6 sm:text-sm"
          >
            <PhoneIcon /> {s.phoneDisplay}
          </a>
        </div>
      </div>
      <div className="bg-[#111820] px-4 py-5 text-center text-[12px] text-stone-400">
        <p className="font-semibold text-white">
          {s.shopName} · {s.town}
        </p>
        {s.address ? <p className="mt-1">{s.address}</p> : null}
        <p className="mt-1">{s.hours}</p>
        <p className="mt-1">
          {s.warrantyDays}-day works-or-return · {s.deliveryNote}
        </p>
        <Link
          to="/login"
          className="mt-4 inline-flex items-center gap-1.5 rounded-full border border-white/25 bg-white px-4 py-2 text-[12px] font-bold text-[#111820] transition hover:bg-[#e0622a] hover:text-white active:scale-95"
        >
          Shop owner login →
        </Link>
      </div>
    </footer>
  );
}
