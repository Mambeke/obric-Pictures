import { Link } from "react-router";
import {
  PHONE_DIAL,
  PHONE_DISPLAY,
  SHOP_NAME,
  TICKER_ITEMS,
  TRADING_HOURS,
  waLink,
} from "./config";

function WhatsAppIcon({ className = "size-4" }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" className={className} aria-hidden>
      <path d="M17.47 14.38c-.3-.15-1.75-.86-2.02-.96-.27-.1-.47-.15-.67.15-.2.3-.77.96-.94 1.16-.17.2-.35.22-.64.07-.3-.15-1.25-.46-2.38-1.47-.88-.78-1.47-1.75-1.64-2.05-.17-.3-.02-.46.13-.6.13-.13.3-.35.45-.52.15-.17.2-.3.3-.5.1-.2.05-.37-.02-.52-.08-.15-.67-1.6-.92-2.2-.24-.58-.49-.5-.67-.51h-.57c-.2 0-.52.07-.79.37-.27.3-1.04 1.01-1.04 2.47 0 1.46 1.06 2.87 1.21 3.07.15.2 2.09 3.2 5.07 4.48.71.3 1.26.49 1.69.63.71.22 1.36.19 1.87.12.57-.09 1.75-.72 2-1.41.25-.69.25-1.28.17-1.41-.07-.13-.27-.2-.57-.35z" />
      <path d="M12.04 2C6.6 2 2.18 6.42 2.18 11.86c0 1.74.46 3.44 1.32 4.94L2 22l5.34-1.4a9.8 9.8 0 0 0 4.7 1.2h.01c5.43 0 9.85-4.42 9.85-9.86A9.79 9.79 0 0 0 12.04 2zm0 17.96h-.01a8.2 8.2 0 0 1-4.16-1.14l-.3-.18-3.1.81.83-3.02-.2-.31a8.15 8.15 0 0 1-1.25-4.36c0-4.52 3.68-8.2 8.2-8.2 2.19 0 4.25.86 5.8 2.41a8.15 8.15 0 0 1 2.4 5.8c0 4.52-3.68 8.19-8.2 8.19z" />
    </svg>
  );
}

function PhoneIcon({ className = "size-4" }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" className={className} aria-hidden>
      <path d="M6.62 10.79a15.05 15.05 0 0 0 6.59 6.59l2.2-2.2a1 1 0 0 1 1.02-.24c1.12.37 2.33.57 3.57.57a1 1 0 0 1 1 1V20a1 1 0 0 1-1 1A17 17 0 0 1 3 4a1 1 0 0 1 1-1h3.5a1 1 0 0 1 1 1c0 1.25.2 2.45.57 3.57a1 1 0 0 1-.25 1.02l-2.2 2.2z" />
    </svg>
  );
}

export function ShopHeader() {
  return (
    <header className="sticky top-0 z-40 bg-gradient-to-r from-[#1257d0] via-[#1a6fe0] to-[#3b8ef5] text-white shadow-sm">
      <div className="mx-auto flex h-12 max-w-[1560px] items-center gap-2 px-3 sm:h-14 sm:px-5">
        <Link to="/" className="flex min-w-0 items-center gap-2">
          <span className="grid size-7 shrink-0 place-items-center rounded-lg bg-white/15 text-[13px] font-black sm:size-8">
            CC
          </span>
          <span className="truncate text-[15px] font-extrabold tracking-tight sm:text-lg">
            Cell&nbsp;Connecta
          </span>
        </Link>

        <div className="ml-auto flex items-center gap-2">
          <a
            href={waLink(`Hi ${SHOP_NAME}, I'd like to ask about a phone.`)}
            target="_blank"
            rel="noreferrer"
            className="flex items-center gap-1.5 rounded-full bg-[#25d366] px-3 py-1.5 text-[13px] font-bold text-white shadow-sm ring-1 ring-white/40 transition hover:bg-[#1eb85a] active:scale-95 sm:px-4 sm:text-sm"
          >
            <WhatsAppIcon />
            WhatsApp
          </a>
          <a
            href={`tel:${PHONE_DIAL}`}
            aria-label={`Call ${PHONE_DISPLAY}`}
            className="flex items-center gap-1.5 rounded-full border border-white/40 bg-white/10 px-3 py-1.5 text-[13px] font-semibold transition active:scale-95 sm:px-4 sm:text-sm"
          >
            <PhoneIcon />
            <span className="hidden sm:inline">{PHONE_DISPLAY}</span>
          </a>
        </div>
      </div>
      <Ticker />
    </header>
  );
}

function Ticker() {
  const items = [...TICKER_ITEMS, ...TICKER_ITEMS];
  return (
    <div className="overflow-hidden border-t border-white/15 bg-[#0b3f9e]">
      <div className="cc-ticker flex w-max gap-8 py-1.5 pl-4">
        {items.map((t, i) => (
          <span
            key={`${t}-${i}`}
            className="flex shrink-0 items-center gap-2 whitespace-nowrap text-[12px] font-medium text-sky-50/95 sm:text-[13px]"
          >
            <span className="text-amber-300">◆</span>
            {t}
          </span>
        ))}
      </div>
    </div>
  );
}

export function ShopFooter() {
  return (
    <footer className="mt-14">
      <div className="bg-gradient-to-br from-[#1257d0] to-[#3b8ef5] px-4 py-10 text-center text-white">
        <h3 className="text-xl font-extrabold sm:text-2xl">
          Can't find the phone you want?
        </h3>
        <p className="mx-auto mt-2 max-w-md text-sm text-sky-50">
          Tell us the model, the storage and the colour. We can usually source it
          within a few days.
        </p>
        <div className="mt-5 flex flex-col items-center justify-center gap-2.5 sm:flex-row">
          <a
            href={waLink(
              `Hi ${SHOP_NAME}, I'm looking for a phone. Can you help me find it?`,
            )}
            target="_blank"
            rel="noreferrer"
            className="flex w-full max-w-xs items-center justify-center gap-2 rounded-full bg-[#25d366] px-6 py-3 text-sm font-bold text-white shadow-lg transition hover:bg-[#1eb85a] active:scale-95 sm:w-auto"
          >
            <WhatsAppIcon /> WhatsApp us
          </a>
          <a
            href={`tel:${PHONE_DIAL}`}
            className="flex w-full max-w-xs items-center justify-center gap-2 rounded-full border-2 border-white/70 px-6 py-3 text-sm font-bold transition active:scale-95 sm:w-auto"
          >
            <PhoneIcon /> {PHONE_DISPLAY}
          </a>
        </div>
      </div>
      <div className="bg-[#0b3f9e] px-4 py-5 text-center text-[12px] text-sky-100/80">
        <p className="font-semibold text-white">Cell Connecta · Cape Town</p>
        <p className="mt-1">{TRADING_HOURS}</p>
        <p className="mt-1">
          6-month warranty on certified refurbished · 2 months on pre-owned ·
          3-day returns · No VAT
        </p>
        <Link
          to="/login"
          className="mt-3 inline-block text-[11px] text-sky-200/70 underline underline-offset-2"
        >
          Staff login
        </Link>
      </div>
    </footer>
  );
}

export { PhoneIcon, WhatsAppIcon };
