import { useQuery } from "convex/react";
import { useEffect, useMemo, useState } from "react";
import { useSearchParams } from "react-router";
import { api } from "../../convex/_generated/api";
import "../shop.css";
import { Footer, Hero, Ticker, TopBar } from "@/shop/ShopChrome";
import { PROFILES, RIMS, SHOP, WIDTHS, waGeneral } from "@/shop/shopConfig";
import { TyreCard } from "@/shop/TyreCard";
import { WaIcon } from "@/shop/WaIcon";

type Tab = "used" | "new" | "all";

export function ShopPage() {
  // The URL carries the search, so a customer can share exactly what they see.
  const [params, setParams] = useSearchParams();
  const tab = (params.get("tab") as Tab) || "used";
  const q = params.get("q") ?? "";
  const width = params.get("w") ?? "";
  const profile = params.get("p") ?? "";
  const rim = params.get("r") ?? "";
  const page = Number(params.get("page") ?? "1") || 1;

  const [draft, setDraft] = useState(q);
  useEffect(() => setDraft(q), [q]);

  const set = (next: Record<string, string>) => {
    const merged = new URLSearchParams(params);
    for (const [k, v] of Object.entries(next)) {
      if (v) merged.set(k, v);
      else merged.delete(k);
    }
    if (!("page" in next)) merged.delete("page");
    setParams(merged, { replace: true });
  };

  const data = useQuery(api.tyres.list, {
    tab,
    q,
    width,
    profile,
    rim,
    page,
  });
  const facets = useQuery(api.tyres.facets, {});

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, []);

  const pageButtons = useMemo(() => {
    if (!data) return [];
    const { page: cur, pages } = data;
    const out: number[] = [];
    const push = (n: number) => {
      if (n >= 1 && n <= pages && !out.includes(n)) out.push(n);
    };
    push(1);
    for (let n = cur - 1; n <= cur + 1; n++) push(n);
    push(pages);
    return out.sort((a, b) => a - b);
  }, [data]);

  return (
    <>
      <TopBar />
      <Ticker />
      <Hero />

      <div className="searchbar">
        <div className="wrap">
          <div className="sinput">
            <span className="ic">🔍</span>
            <input
              value={draft}
              onChange={e => setDraft(e.target.value)}
              onKeyDown={e => {
                if (e.key === "Enter") set({ q: draft });
              }}
              onBlur={() => set({ q: draft })}
              placeholder="Search any tyre size — 195/65R15, 195 65 15, 1956515..."
              aria-label="Search tyre size"
            />
          </div>
          <NumSelect
            label="1st"
            full="1st number"
            hint="width"
            value={width}
            options={merge(WIDTHS, facets?.widths)}
            onChange={v => set({ w: v })}
          />
          <NumSelect
            label="2nd"
            full="2nd number"
            hint="profile"
            value={profile}
            options={merge(PROFILES, facets?.profiles)}
            onChange={v => set({ p: v })}
          />
          <NumSelect
            label="Rim"
            full="Rim"
            hint="R size"
            value={rim}
            options={merge(RIMS, facets?.rims)}
            onChange={v => set({ r: v })}
          />
          <button
            type="button"
            className="gobtn"
            onClick={() => set({ q: draft })}
          >
            Search
          </button>
          {(width || profile || rim || q) && (
            <button
              type="button"
              className="clrbtn"
              onClick={() => set({ q: "", w: "", p: "", r: "" })}
            >
              Clear
            </button>
          )}
        </div>
      </div>

      <div className="wrap">
        <div className="tabs">
          {(
            [
              ["used", "Used Tyres"],
              ["new", "New Tyres"],
              ["all", "All"],
            ] as [Tab, string][]
          ).map(([key, label]) => (
            <button
              type="button"
              key={key}
              className={`tab ${tab === key ? "on" : ""}`}
              onClick={() => set({ tab: key })}
            >
              {label}
              {data && key !== "all" && (
                <>
                  {" "}
                  · <b>{data.counts[key]}</b>
                </>
              )}
            </button>
          ))}
          {data && (
            <span className="count">
              {data.total === 0
                ? "Nothing matches yet"
                : `Showing ${(data.page - 1) * data.perPage + 1}–${Math.min(
                    data.page * data.perPage,
                    data.total,
                  )} of ${data.total} tyres`}
            </span>
          )}
        </div>

        {!data ? (
          <div className="grid">
            {Array.from({ length: 8 }, (_, i) => (
              <div className="skel" key={`skel-${i}`} />
            ))}
          </div>
        ) : data.items.length === 0 && data.alt ? (
          // Empty tab, stock in the other one. Never send the customer away.
          <>
            <div className="swap">
              <b>
                We don't have that in {tab === "used" ? "used" : "new"} right
                now.
              </b>
              <span>
                But we have {data.alt.total}{" "}
                {tab === "used" ? "new" : "good used"}{" "}
                {data.alt.total === 1 ? "tyre" : "tyres"} in that size — right
                here:
              </span>
              <button
                type="button"
                className="swapbtn"
                onClick={() => set({ tab: data.alt?.condition ?? "all" })}
              >
                See all {data.alt.condition} tyres →
              </button>
            </div>
            <div className="grid">
              {data.alt.items.map(t => (
                <TyreCard key={t.id} t={t} />
              ))}
            </div>
          </>
        ) : data.items.length === 0 ? (
          <div className="empty">
            No tyre matching that yet — send us the size on WhatsApp and we'll
            check the back and source it for you.
          </div>
        ) : (
          <div className="grid">
            {data.items.map(t => (
              <TyreCard key={t.id} t={t} />
            ))}
          </div>
        )}

        {data && data.pages > 1 && (
          <div className="pager">
            <button
              type="button"
              disabled={data.page <= 1}
              onClick={() => set({ page: String(data.page - 1) })}
            >
              ← Prev
            </button>
            {pageButtons.map((n, i) => (
              <span key={n} style={{ display: "contents" }}>
                {i > 0 && pageButtons[i - 1] !== n - 1 && (
                  <span className="of">…</span>
                )}
                <button
                  type="button"
                  className={n === data.page ? "on" : ""}
                  onClick={() => set({ page: String(n) })}
                >
                  {n}
                </button>
              </span>
            ))}
            <button
              type="button"
              disabled={data.page >= data.pages}
              onClick={() => set({ page: String(data.page + 1) })}
            >
              Next →
            </button>
            <span className="of">
              Page {data.page} of {data.pages}
            </span>
          </div>
        )}

        <div className="ask">
          <h3>Can't find your size?</h3>
          <p>
            We carry more than what fits on this page, and stock changes every
            day. Send the size and we'll check.
          </p>
          <a href={waGeneral} target="_blank" rel="noreferrer">
            <WaIcon />
            WhatsApp us your size →
          </a>
        </div>
      </div>

      <Footer />
      <SeoBlurb />
    </>
  );
}

/** Merge the standard size list with anything actually in stock. */
function merge(base: number[], live?: (number | string)[]): number[] {
  const all = new Set<number>(base);
  for (const n of live ?? []) {
    const v = Number(n);
    if (Number.isFinite(v)) all.add(v);
  }
  return [...all].sort((a, b) => a - b);
}

/**
 * A size dropdown labelled the way a customer reads a sidewall — "1st number",
 * not "width". Nobody standing next to their car thinks in aspect ratios.
 */
function NumSelect({
  label,
  full,
  hint,
  value,
  options,
  onChange,
}: {
  label: string;
  full: string;
  hint: string;
  value: string;
  options: number[];
  onChange: (v: string) => void;
}) {
  return (
    <select
      className={value ? "picked" : ""}
      value={value}
      onChange={e => onChange(e.target.value)}
      aria-label={`${full} of the tyre size (${hint})`}
    >
      <option value="">{`${label} — any`}</option>
      {options.map(x => (
        <option key={x} value={x}>
          {x}
        </option>
      ))}
    </select>
  );
}

/** Plain text Google can read on first load. Invisible to customers. */
function SeoBlurb() {
  return (
    <div
      style={{
        position: "absolute",
        left: -9999,
        top: "auto",
        height: 1,
        overflow: "hidden",
      }}
    >
      <h2>Tyres in Goodwood, Cape Town</h2>
      <p>
        {SHOP.name} sells quality used tyres and new tyres at {SHOP.addressFull}
        . Open {SHOP.hoursLong}. Wheel alignment, wheel balancing, puncture
        repairs, hot patches and tyre fitting on site. WhatsApp{" "}
        {SHOP.phoneDisplay}.
      </p>
    </div>
  );
}
