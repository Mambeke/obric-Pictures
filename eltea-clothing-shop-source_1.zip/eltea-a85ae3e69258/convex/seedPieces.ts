// Demo stock for Eltea Boutique — loaded from the owner panel button.
// Photos live in public/img and are served as static files.
export type SeedPiece = {
  name: string; brand: string; price: number; wasPrice?: number;
  section: string; category: string; state: string; size: string;
  cond: string; meas: string; desc: string; photos: string[]; badge: string;
};

export const SEED_PIECES: SeedPiece[] = [
  {
    "name": "Floral summer midi dress",
    "brand": "Zara",
    "price": 14,
    "wasPrice": 18,
    "section": "Ladies",
    "category": "Dresses",
    "state": "Pre-owned",
    "size": "M",
    "cond": "Excellent \u2014 worn twice",
    "meas": "Chest 92cm \u00b7 Waist 74cm \u00b7 Length 118cm",
    "desc": "",
    "photos": [
      "/img/dress_floral.jpg"
    ],
    "badge": "NEW IN"
  },
  {
    "name": "Black bodycon evening dress",
    "brand": "Boohoo",
    "price": 12,
    "section": "Ladies",
    "category": "Dresses",
    "state": "Pre-owned",
    "size": "S",
    "cond": "Like new",
    "meas": "Chest 84cm \u00b7 Length 96cm",
    "desc": "",
    "photos": [
      "/img/dress_black.jpg",
      "/img/dress_black_2.jpg",
      "/img/dress_black_3.jpg"
    ],
    "badge": ""
  },
  {
    "name": "Cream silk blouse",
    "brand": "Mango",
    "price": 9,
    "section": "Ladies",
    "category": "Tops",
    "state": "Pre-owned",
    "size": "M",
    "cond": "Excellent",
    "meas": "Chest 94cm \u00b7 Length 62cm",
    "desc": "",
    "photos": [
      "/img/blouse_silk.jpg"
    ],
    "badge": ""
  },
  {
    "name": "Brown leather jacket",
    "brand": "River Island",
    "price": 35,
    "wasPrice": 45,
    "section": "Ladies",
    "category": "Jackets",
    "state": "Pre-owned",
    "size": "M",
    "cond": "Real leather \u00b7 very good",
    "meas": "Chest 98cm \u00b7 Sleeve 60cm",
    "desc": "",
    "photos": [
      "/img/jacket_leather.jpg"
    ],
    "badge": "SALE"
  },
  {
    "name": "High-waisted mom jeans",
    "brand": "Levi's",
    "price": 18,
    "section": "Ladies",
    "category": "Jeans & trousers",
    "state": "Pre-owned",
    "size": "32",
    "cond": "Excellent",
    "meas": "Waist 82cm \u00b7 Inseam 74cm",
    "desc": "",
    "photos": [
      "/img/jeans_mom.jpg"
    ],
    "badge": "BEST SELLER"
  },
  {
    "name": "Oversized knit cardigan",
    "brand": "Cotton On",
    "price": 11,
    "section": "Ladies",
    "category": "Tops",
    "state": "Pre-owned",
    "size": "L",
    "cond": "Very good",
    "meas": "Chest 112cm \u00b7 Length 76cm",
    "desc": "",
    "photos": [
      "/img/knit_cardi.jpg"
    ],
    "badge": ""
  },
  {
    "name": "Beige trench coat",
    "brand": "Zara",
    "price": 28,
    "section": "Ladies",
    "category": "Jackets",
    "state": "Pre-owned",
    "size": "M",
    "cond": "Excellent",
    "meas": "Chest 100cm \u00b7 Length 106cm",
    "desc": "",
    "photos": [
      "/img/coat_trench.jpg"
    ],
    "badge": "NEW IN"
  },
  {
    "name": "Navy knitted jumper",
    "brand": "Next",
    "price": 12,
    "section": "Men",
    "category": "Tops",
    "state": "Pre-owned",
    "size": "L",
    "cond": "Excellent",
    "meas": "Chest 108cm \u00b7 Length 70cm",
    "desc": "",
    "photos": [
      "/img/jersey_men.jpg"
    ],
    "badge": ""
  },
  {
    "name": "Checked flannel shirt",
    "brand": "Jack & Jones",
    "price": 9,
    "section": "Men",
    "category": "Shirts",
    "state": "Pre-owned",
    "size": "M",
    "cond": "Very good",
    "meas": "Chest 102cm \u00b7 Sleeve 63cm",
    "desc": "",
    "photos": [
      "/img/shirt_men.jpg"
    ],
    "badge": ""
  },
  {
    "name": "Dark straight-leg jeans",
    "brand": "Levi's 501",
    "price": 20,
    "wasPrice": 26,
    "section": "Men",
    "category": "Jeans & trousers",
    "state": "Pre-owned",
    "size": "34",
    "cond": "Excellent",
    "meas": "Waist 86cm \u00b7 Inseam 81cm",
    "desc": "",
    "photos": [
      "/img/jeans_men.jpg"
    ],
    "badge": "SALE"
  },
  {
    "name": "Khaki chino trousers",
    "brand": "Uniqlo",
    "price": 13,
    "section": "Men",
    "category": "Jeans & trousers",
    "state": "Pre-owned",
    "size": "32",
    "cond": "Like new",
    "meas": "Waist 82cm \u00b7 Inseam 79cm",
    "desc": "",
    "photos": [
      "/img/chinos.jpg"
    ],
    "badge": ""
  },
  {
    "name": "Black puffer jacket",
    "brand": "Nike",
    "price": 30,
    "section": "Men",
    "category": "Jackets",
    "state": "Pre-owned",
    "size": "XL",
    "cond": "Excellent",
    "meas": "Chest 118cm \u00b7 Length 74cm",
    "desc": "",
    "photos": [
      "/img/jacket_puffer.jpg"
    ],
    "badge": "NEW IN"
  },
  {
    "name": "Plain cotton tee \u2014 3 pack",
    "brand": "Brand new",
    "price": 15,
    "section": "Men",
    "category": "Tops",
    "state": "New",
    "size": "S\u2013XXL",
    "cond": "Brand new, in packaging",
    "meas": "White, black and grey",
    "desc": "",
    "photos": [
      "/img/tshirt_pack.jpg"
    ],
    "badge": "BRAND NEW"
  },
  {
    "name": "Girl's party dress (3\u20134 yrs)",
    "brand": "Primark",
    "price": 7,
    "section": "Kids",
    "category": "Dresses",
    "state": "Pre-owned",
    "size": "3\u20134",
    "cond": "Excellent",
    "meas": "Age 3\u20134 \u00b7 Length 58cm",
    "desc": "",
    "photos": [
      "/img/kids_dress.jpg"
    ],
    "badge": ""
  },
  {
    "name": "Boy's hoodie & jogger set (5\u20136)",
    "brand": "H&M",
    "price": 9,
    "section": "Kids",
    "category": "Tracksuits",
    "state": "Pre-owned",
    "size": "5\u20136",
    "cond": "Like new",
    "meas": "Age 5\u20136",
    "desc": "",
    "photos": [
      "/img/kids_set.jpg"
    ],
    "badge": "NEW IN"
  },
  {
    "name": "Kids white sneakers (size 11)",
    "brand": "Clarks",
    "price": 8,
    "section": "Kids",
    "category": "Shoes",
    "state": "Pre-owned",
    "size": "11",
    "cond": "Very good",
    "meas": "UK 11 child",
    "desc": "",
    "photos": [
      "/img/kids_shoes.jpg"
    ],
    "badge": ""
  },
  {
    "name": "White leather sneakers",
    "brand": "Nike Air Force",
    "price": 32,
    "wasPrice": 40,
    "section": "Men",
    "category": "Shoes",
    "state": "Pre-owned",
    "size": "8",
    "cond": "Excellent \u2014 barely worn",
    "meas": "UK 8 / EU 42",
    "desc": "",
    "photos": [
      "/img/sneakers_white.jpg"
    ],
    "badge": "SALE"
  },
  {
    "name": "Tan ankle boots",
    "brand": "Zara",
    "price": 18,
    "section": "Ladies",
    "category": "Shoes",
    "state": "Pre-owned",
    "size": "6",
    "cond": "Very good",
    "meas": "UK 6 / EU 39",
    "desc": "",
    "photos": [
      "/img/boots_ankle.jpg"
    ],
    "badge": ""
  },
  {
    "name": "Brown leather formal shoes",
    "brand": "Clarks",
    "price": 22,
    "section": "Men",
    "category": "Shoes",
    "state": "Pre-owned",
    "size": "9",
    "cond": "Excellent",
    "meas": "UK 9 / EU 43",
    "desc": "",
    "photos": [
      "/img/loafers.jpg"
    ],
    "badge": ""
  },
  {
    "name": "Brown leather tote bag",
    "brand": "Fossil",
    "price": 26,
    "section": "Ladies",
    "category": "Bags",
    "state": "Pre-owned",
    "size": "One size",
    "cond": "Excellent \u00b7 real leather",
    "meas": "38 x 30 x 12cm",
    "desc": "",
    "photos": [
      "/img/bag_tote.jpg"
    ],
    "badge": "BEST SELLER"
  },
  {
    "name": "Black chain crossbody bag",
    "brand": "Aldo",
    "price": 12,
    "section": "Ladies",
    "category": "Bags",
    "state": "Pre-owned",
    "size": "One size",
    "cond": "Like new",
    "meas": "22 x 14 x 6cm",
    "desc": "",
    "photos": [
      "/img/bag_cross.jpg"
    ],
    "badge": ""
  },
  {
    "name": "Leather belt + silver watch",
    "brand": "Mixed",
    "price": 16,
    "section": "Men",
    "category": "Bags",
    "state": "Pre-owned",
    "size": "One size",
    "cond": "Very good",
    "meas": "Belt 110cm",
    "desc": "",
    "photos": [
      "/img/belt_watch.jpg"
    ],
    "badge": ""
  },
  {
    "name": "Red wrap midi dress",
    "brand": "Mango",
    "price": 16,
    "section": "Ladies",
    "category": "Dresses",
    "state": "Pre-owned",
    "size": "M",
    "cond": "Excellent",
    "meas": "Chest 92cm \u00b7 Length 116cm",
    "desc": "",
    "photos": [
      "/img/l_dress_red.jpg"
    ],
    "badge": ""
  },
  {
    "name": "Navy office shift dress",
    "brand": "Woolworths",
    "price": 24,
    "section": "Ladies",
    "category": "Dresses",
    "state": "New",
    "size": "L",
    "cond": "Brand new with tags",
    "meas": "Chest 100cm \u00b7 Length 98cm",
    "desc": "",
    "photos": [
      "/img/l_dress_navy.jpg"
    ],
    "badge": "NEW IN"
  },
  {
    "name": "African print maxi dress",
    "brand": "Local tailor",
    "price": 20,
    "section": "Ladies",
    "category": "Dresses",
    "state": "Pre-owned",
    "size": "XL",
    "cond": "Like new",
    "meas": "Chest 108cm \u00b7 Length 140cm",
    "desc": "",
    "photos": [
      "/img/l_dress_print.jpg"
    ],
    "badge": "BEST SELLER"
  },
  {
    "name": "White cotton shirt",
    "brand": "Zara",
    "price": 8,
    "section": "Ladies",
    "category": "Tops",
    "state": "Pre-owned",
    "size": "S",
    "cond": "Very good",
    "meas": "Chest 88cm \u00b7 Length 60cm",
    "desc": "",
    "photos": [
      "/img/l_top_white.jpg"
    ],
    "badge": ""
  },
  {
    "name": "Striped long-sleeve top",
    "brand": "H&M",
    "price": 7,
    "section": "Ladies",
    "category": "Tops",
    "state": "Pre-owned",
    "size": "M",
    "cond": "Excellent",
    "meas": "Chest 94cm \u00b7 Length 62cm",
    "desc": "",
    "photos": [
      "/img/l_top_stripe.jpg"
    ],
    "badge": ""
  },
  {
    "name": "Black ribbed bodysuit",
    "brand": "Cotton On",
    "price": 11,
    "section": "Ladies",
    "category": "Tops",
    "state": "New",
    "size": "S",
    "cond": "Brand new with tags",
    "meas": "Stretch \u00b7 fits S\u2013M",
    "desc": "",
    "photos": [
      "/img/l_top_body.jpg"
    ],
    "badge": ""
  },
  {
    "name": "Blue skinny jeans",
    "brand": "Truworths",
    "price": 14,
    "section": "Ladies",
    "category": "Jeans & trousers",
    "state": "Pre-owned",
    "size": "30",
    "cond": "Very good",
    "meas": "Waist 76cm \u00b7 Inseam 76cm",
    "desc": "",
    "photos": [
      "/img/l_jeans_skinny.jpg"
    ],
    "badge": ""
  },
  {
    "name": "Black wide-leg trousers",
    "brand": "Mr Price",
    "price": 12,
    "section": "Ladies",
    "category": "Jeans & trousers",
    "state": "Pre-owned",
    "size": "34",
    "cond": "Excellent",
    "meas": "Waist 86cm \u00b7 Inseam 80cm",
    "desc": "",
    "photos": [
      "/img/l_trouser_wide.jpg"
    ],
    "badge": ""
  },
  {
    "name": "Denim mini skirt",
    "brand": "H&M",
    "price": 9,
    "section": "Ladies",
    "category": "Skirts",
    "state": "Pre-owned",
    "size": "M",
    "cond": "Very good",
    "meas": "Waist 74cm \u00b7 Length 42cm",
    "desc": "",
    "photos": [
      "/img/l_skirt_denim.jpg"
    ],
    "badge": ""
  },
  {
    "name": "Black pencil skirt",
    "brand": "Woolworths",
    "price": 15,
    "section": "Ladies",
    "category": "Skirts",
    "state": "New",
    "size": "L",
    "cond": "Brand new with tags",
    "meas": "Waist 82cm \u00b7 Length 62cm",
    "desc": "",
    "photos": [
      "/img/l_skirt_pencil.jpg"
    ],
    "badge": ""
  },
  {
    "name": "Denim jacket",
    "brand": "Levi's",
    "price": 22,
    "wasPrice": 28,
    "section": "Ladies",
    "category": "Jackets",
    "state": "Pre-owned",
    "size": "M",
    "cond": "Excellent",
    "meas": "Chest 98cm \u00b7 Sleeve 58cm",
    "desc": "",
    "photos": [
      "/img/l_jacket_denim.jpg"
    ],
    "badge": "SALE"
  },
  {
    "name": "White canvas sneakers",
    "brand": "Converse",
    "price": 16,
    "section": "Ladies",
    "category": "Shoes",
    "state": "Pre-owned",
    "size": "6",
    "cond": "Very good",
    "meas": "UK 6 / EU 39",
    "desc": "",
    "photos": [
      "/img/l_shoe_canvas.jpg"
    ],
    "badge": ""
  },
  {
    "name": "Gold strappy sandals",
    "brand": "Aldo",
    "price": 13,
    "section": "Ladies",
    "category": "Shoes",
    "state": "Pre-owned",
    "size": "7",
    "cond": "Like new",
    "meas": "UK 7 / EU 40",
    "desc": "",
    "photos": [
      "/img/l_shoe_sandal.jpg"
    ],
    "badge": ""
  },
  {
    "name": "Beige straw shoulder bag",
    "brand": "Mango",
    "price": 14,
    "section": "Ladies",
    "category": "Bags",
    "state": "Pre-owned",
    "size": "One size",
    "cond": "Excellent",
    "meas": "30 x 26 x 10cm",
    "desc": "",
    "photos": [
      "/img/l_bag_straw.jpg"
    ],
    "badge": ""
  },
  {
    "name": "Red faux-leather handbag",
    "brand": "Zara",
    "price": 19,
    "section": "Ladies",
    "category": "Bags",
    "state": "New",
    "size": "One size",
    "cond": "Brand new with tags",
    "meas": "34 x 24 x 12cm",
    "desc": "",
    "photos": [
      "/img/l_bag_red.jpg"
    ],
    "badge": "NEW IN"
  },
  {
    "name": "White formal shirt",
    "brand": "Woolworths",
    "price": 10,
    "section": "Men",
    "category": "Shirts",
    "state": "Pre-owned",
    "size": "L",
    "cond": "Excellent",
    "meas": "Chest 106cm \u00b7 Sleeve 64cm",
    "desc": "",
    "photos": [
      "/img/m_shirt_white.jpg"
    ],
    "badge": ""
  },
  {
    "name": "Blue slim-fit shirt",
    "brand": "Markham",
    "price": 17,
    "section": "Men",
    "category": "Shirts",
    "state": "New",
    "size": "M",
    "cond": "Brand new with tags",
    "meas": "Chest 100cm \u00b7 Sleeve 63cm",
    "desc": "",
    "photos": [
      "/img/m_shirt_blue.jpg"
    ],
    "badge": "NEW IN"
  },
  {
    "name": "Grey hoodie",
    "brand": "Nike",
    "price": 18,
    "section": "Men",
    "category": "Tops",
    "state": "Pre-owned",
    "size": "XL",
    "cond": "Very good",
    "meas": "Chest 116cm \u00b7 Length 72cm",
    "desc": "",
    "photos": [
      "/img/m_hoodie.jpg"
    ],
    "badge": "BEST SELLER"
  },
  {
    "name": "Black polo shirt",
    "brand": "Lacoste",
    "price": 13,
    "section": "Men",
    "category": "Tops",
    "state": "Pre-owned",
    "size": "L",
    "cond": "Excellent",
    "meas": "Chest 108cm \u00b7 Length 70cm",
    "desc": "",
    "photos": [
      "/img/m_polo.jpg"
    ],
    "badge": ""
  },
  {
    "name": "Cargo trousers",
    "brand": "Jeep",
    "price": 16,
    "section": "Men",
    "category": "Jeans & trousers",
    "state": "Pre-owned",
    "size": "36",
    "cond": "Very good",
    "meas": "Waist 92cm \u00b7 Inseam 80cm",
    "desc": "",
    "photos": [
      "/img/m_cargo.jpg"
    ],
    "badge": ""
  },
  {
    "name": "Navy blazer",
    "brand": "Zara Man",
    "price": 27,
    "section": "Men",
    "category": "Jackets",
    "state": "Pre-owned",
    "size": "L",
    "cond": "Excellent",
    "meas": "Chest 108cm \u00b7 Sleeve 64cm",
    "desc": "",
    "photos": [
      "/img/m_blazer.jpg"
    ],
    "badge": ""
  },
  {
    "name": "Black tracksuit set",
    "brand": "Adidas",
    "price": 32,
    "section": "Men",
    "category": "Tracksuits",
    "state": "New",
    "size": "XL",
    "cond": "Brand new with tags",
    "meas": "Chest 118cm \u00b7 Inseam 80cm",
    "desc": "",
    "photos": [
      "/img/m_tracksuit_black.jpg"
    ],
    "badge": "NEW IN"
  },
  {
    "name": "Black running trainers",
    "brand": "Puma",
    "price": 24,
    "section": "Men",
    "category": "Shoes",
    "state": "Pre-owned",
    "size": "10",
    "cond": "Very good",
    "meas": "UK 10 / EU 44",
    "desc": "",
    "photos": [
      "/img/m_shoe_run.jpg"
    ],
    "badge": ""
  },
  {
    "name": "Black laptop backpack",
    "brand": "Kipling",
    "price": 21,
    "section": "Men",
    "category": "Bags",
    "state": "Pre-owned",
    "size": "One size",
    "cond": "Excellent",
    "meas": "Fits 15\" laptop",
    "desc": "",
    "photos": [
      "/img/m_bag_pack.jpg"
    ],
    "badge": ""
  },
  {
    "name": "Girl's denim jacket (7\u20138)",
    "brand": "Zara Kids",
    "price": 10,
    "section": "Kids",
    "category": "Tops",
    "state": "Pre-owned",
    "size": "7\u20138",
    "cond": "Excellent",
    "meas": "Age 7\u20138",
    "desc": "",
    "photos": [
      "/img/k_jacket_girl.jpg"
    ],
    "badge": ""
  },
  {
    "name": "Boy's blue jeans (9\u201310)",
    "brand": "H&M",
    "price": 8,
    "section": "Kids",
    "category": "Jeans & trousers",
    "state": "Pre-owned",
    "size": "9\u201310",
    "cond": "Very good",
    "meas": "Age 9\u201310",
    "desc": "",
    "photos": [
      "/img/k_jeans_boy.jpg"
    ],
    "badge": ""
  },
  {
    "name": "Girl's church dress (5\u20136)",
    "brand": "Ackermans",
    "price": 12,
    "section": "Kids",
    "category": "Dresses",
    "state": "New",
    "size": "5\u20136",
    "cond": "Brand new with tags",
    "meas": "Age 5\u20136",
    "desc": "",
    "photos": [
      "/img/k_dress_church.jpg"
    ],
    "badge": "NEW IN"
  },
  {
    "name": "Boy's school shoes (size 1)",
    "brand": "Toughees",
    "price": 9,
    "section": "Kids",
    "category": "Shoes",
    "state": "Pre-owned",
    "size": "1",
    "cond": "Very good",
    "meas": "UK 1 child",
    "desc": "",
    "photos": [
      "/img/k_shoe_school.jpg"
    ],
    "badge": ""
  }
];
