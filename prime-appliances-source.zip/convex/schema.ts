import { authTables } from "@convex-dev/auth/server";
import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";

const schema = defineSchema({
  ...authTables,

  appliances: defineTable({
    // "Fridges" | "Stoves & ovens" | ... (see src/shop/config.ts CATEGORIES)
    category: v.string(),
    // make + model, e.g. "Defy 235L double door fridge"
    title: v.string(),
    // "Excellent" | "Good" | "Fair" | "Spares or repair"
    condition: v.string(),
    price: v.number(),
    // optional "was" price, for a marked-down item
    wasPrice: v.optional(v.number()),
    description: v.optional(v.string()),
    // free-form spec rows the owner types himself
    specs: v.array(v.object({ label: v.string(), value: v.string() })),
    // the date it was switched on and checked, e.g. "24 Aug 2026"
    testedOn: v.optional(v.string()),
    freeDelivery: v.boolean(),
    photos: v.array(v.string()),
    sold: v.boolean(),
    soldAt: v.optional(v.number()),
    demo: v.optional(v.boolean()),
    createdAt: v.number(),
  })
    .index("by_sold", ["sold"])
    .index("by_category", ["category"]),

  // One row. Everything the owner can change about his own shop without
  // anybody touching the code — this is what makes the engine resellable.
  shopSettings: defineTable({
    shopName: v.string(),
    tagline: v.string(),
    town: v.string(),
    address: v.optional(v.string()),
    phoneDisplay: v.string(),
    phoneDial: v.string(),
    whatsapp: v.string(),
    hours: v.string(),
    deliveryFee: v.number(),
    deliveryNote: v.string(),
    warrantyDays: v.number(),
    updatedAt: v.number(),
  }),
});

export default schema;
