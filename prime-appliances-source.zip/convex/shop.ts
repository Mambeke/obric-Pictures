import { v } from "convex/values";
import type { Doc, Id } from "./_generated/dataModel";
import { mutation, query } from "./_generated/server";
import { authenticatedMutation, authenticatedQuery } from "./functions";
import { DEFAULT_SETTINGS, isOwnerEmail } from "./shopConfig";

const specValidator = v.object({ label: v.string(), value: v.string() });

async function withPhotoUrls(
  ctx: { storage: { getUrl: (id: Id<"_storage">) => Promise<string | null> } },
  item: Doc<"appliances">,
) {
  const photoUrls: string[] = [];
  for (const id of item.photos) {
    try {
      const url = await ctx.storage.getUrl(id as Id<"_storage">);
      if (url) photoUrls.push(url);
    } catch {
      // a photo that was deleted from storage must not break the shop
    }
  }
  return { ...item, photoUrls };
}

/** Public storefront listing — anyone may read the shop. */
export const listAppliances = query({
  args: {},
  handler: async ctx => {
    const items = await ctx.db.query("appliances").order("desc").collect();
    return await Promise.all(items.map(i => withPhotoUrls(ctx, i)));
  },
});

/** Public single item. */
export const getAppliance = query({
  args: { id: v.id("appliances") },
  handler: async (ctx, args) => {
    const item = await ctx.db.get(args.id);
    if (!item) return null;
    return await withPhotoUrls(ctx, item);
  },
});

/** Public shop details — name, number, hours. Falls back to the defaults. */
export const getSettings = query({
  args: {},
  handler: async ctx => {
    const row = await ctx.db.query("shopSettings").first();
    if (!row) return { ...DEFAULT_SETTINGS, _id: null };
    return row;
  },
});

async function assertOwner(ctx: {
  db: { get: (id: Id<"users">) => Promise<Doc<"users"> | null> };
  userId: Id<"users">;
}) {
  const user = await ctx.db.get(ctx.userId);
  if (!isOwnerEmail(user?.email)) {
    throw new Error("Not allowed — this account may not manage stock.");
  }
  return user;
}

/** Is the signed-in account allowed into the owner area? */
export const amIOwner = authenticatedQuery({
  args: {},
  handler: async ctx => {
    const user = await ctx.db.get(ctx.userId);
    return { isOwner: isOwnerEmail(user?.email), email: user?.email ?? null };
  },
});

export const generateUploadUrl = authenticatedMutation({
  args: {},
  handler: async ctx => {
    await assertOwner(ctx);
    return await ctx.storage.generateUploadUrl();
  },
});

export const saveAppliance = authenticatedMutation({
  args: {
    id: v.optional(v.id("appliances")),
    category: v.string(),
    title: v.string(),
    condition: v.string(),
    price: v.number(),
    wasPrice: v.optional(v.number()),
    description: v.optional(v.string()),
    specs: v.array(specValidator),
    testedOn: v.optional(v.string()),
    freeDelivery: v.boolean(),
    photos: v.array(v.string()),
  },
  handler: async (ctx, args) => {
    await assertOwner(ctx);
    const { id, ...fields } = args;
    if (id) {
      // Once the owner edits an item it is his own stock, not sample stock.
      await ctx.db.patch(id, { ...fields, demo: false });
      return id;
    }
    return await ctx.db.insert("appliances", {
      ...fields,
      sold: false,
      demo: false,
      createdAt: Date.now(),
    });
  },
});

/** One tap: it is gone, or it is back on the floor. */
export const setSold = authenticatedMutation({
  args: { id: v.id("appliances"), sold: v.boolean() },
  handler: async (ctx, args) => {
    await assertOwner(ctx);
    const item = await ctx.db.get(args.id);
    if (!item) throw new Error("That appliance is no longer there.");
    await ctx.db.patch(args.id, {
      sold: args.sold,
      soldAt: args.sold ? Date.now() : undefined,
    });
    return { success: true };
  },
});

export const deleteAppliance = authenticatedMutation({
  args: { id: v.id("appliances") },
  handler: async (ctx, args) => {
    await assertOwner(ctx);
    await ctx.db.delete(args.id);
    return { success: true };
  },
});

/** Remove everything that came in as sample stock. */
export const clearDemoStock = authenticatedMutation({
  args: {},
  handler: async ctx => {
    await assertOwner(ctx);
    const items = await ctx.db.query("appliances").collect();
    let removed = 0;
    for (const item of items) {
      if (item.demo) {
        await ctx.db.delete(item._id);
        removed++;
      }
    }
    return { removed };
  },
});

export const saveSettings = authenticatedMutation({
  args: {
    shopName: v.string(),
    tagline: v.string(),
    town: v.string(),
    address: v.optional(v.string()),
    phoneDisplay: v.string(),
    phoneDial: v.string(),
    whatsapp: v.string(),
    hours: v.string(),
    deliveryFee: v.number(),
    deliveryNote: v.string(),
    warrantyDays: v.number(),
  },
  handler: async (ctx, args) => {
    await assertOwner(ctx);
    const row = await ctx.db.query("shopSettings").first();
    if (row) {
      await ctx.db.patch(row._id, { ...args, updatedAt: Date.now() });
      return row._id;
    }
    return await ctx.db.insert("shopSettings", {
      ...args,
      updatedAt: Date.now(),
    });
  },
});

/** One-off seeding of sample stock, used at build time. */
export const seedDemo = mutation({
  args: {
    secret: v.string(),
    items: v.array(
      v.object({
        category: v.string(),
        title: v.string(),
        condition: v.string(),
        price: v.number(),
        description: v.optional(v.string()),
        specs: v.array(specValidator),
        testedOn: v.optional(v.string()),
        freeDelivery: v.boolean(),
        sold: v.boolean(),
        photos: v.optional(v.array(v.string())),
        ageDays: v.optional(v.number()),
      }),
    ),
    append: v.optional(v.boolean()),
  },
  handler: async (ctx, args) => {
    if (args.secret !== "prime-seed-2026") throw new Error("Bad seed secret");
    if (!args.append) {
      const existing = await ctx.db.query("appliances").collect();
      for (const item of existing) {
        if (item.demo) await ctx.db.delete(item._id);
      }
    }
    for (const item of args.items) {
      const { photos, ageDays, ...rest } = item;
      await ctx.db.insert("appliances", {
        ...rest,
        photos: photos ?? [],
        demo: true,
        createdAt: Date.now() - (ageDays ?? 0) * 86400000,
      });
    }
    return { inserted: args.items.length };
  },
});

/** Maintenance helper: patch shop settings with the seed secret (no login). */
export const patchSettingsBySecret = mutation({
  args: { secret: v.string(), patch: v.any() },
  handler: async (ctx, args) => {
    if (args.secret !== "prime-seed-2026") throw new Error("bad secret");
    const row = await ctx.db.query("shopSettings").first();
    if (!row) return null;
    await ctx.db.patch(row._id, { ...args.patch, updatedAt: Date.now() });
    return row._id;
  },
});
