import { runTest } from "./auth";

/** The owner's daily job: put an appliance on the floor, then sell it. */
runTest("Owner panel", async helper => {
  const { page } = helper;
  await helper.goto("/admin");
  await page.waitForSelector("text=Add an appliance", { timeout: 20000 });

  const title = `Test washer ${Date.now()}`;
  await page.click("button:has-text('+ Add an appliance')");
  await page.waitForSelector("input[placeholder*='Defy 235L']");
  await page.fill("input[placeholder*='Defy 235L']", title);
  await page.fill("input[inputmode='numeric']", "1999");
  await page.click("button:has-text('Publish to the shop')");
  await page.waitForTimeout(2500);

  if (!(await page.locator(`text=${title}`).first().isVisible())) {
    throw new Error("New appliance did not appear on the owner's list");
  }

  // It must be on the public shop immediately.
  await helper.goto("/");
  await page.waitForTimeout(2000);
  await page.fill("input[aria-label='Search appliances']", title);
  await page.waitForTimeout(800);
  if (!(await page.locator(`text=${title}`).first().isVisible())) {
    throw new Error("New appliance is not on the shop page");
  }

  // Mark it sold, and it leaves the live grid.
  await helper.goto("/admin");
  await page.waitForTimeout(2000);
  await page.fill("input[placeholder='Find an item…']", title);
  await page.waitForTimeout(600);
  await page.click("button:has-text('Mark sold')");
  await page.waitForTimeout(1800);
  await page.click("button:has-text('Sold (')");
  await page.waitForTimeout(600);
  if (!(await page.locator(`text=${title}`).first().isVisible())) {
    throw new Error("Sold item did not move to the sold shelf");
  }

  // Tidy up after the test.
  await page.click(`button[aria-label='Delete ${title}']`);
  page.on("dialog", d => void d.accept());
  await page.waitForTimeout(1200);

  console.log("owner panel ok");
}).catch(() => process.exit(1));
