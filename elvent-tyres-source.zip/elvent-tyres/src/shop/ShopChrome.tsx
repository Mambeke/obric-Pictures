import { Link } from "react-router";
import { SERVICES, SHOP, TAGLINES } from "./shopConfig";
import { WaIcon } from "./WaIcon";

export function TopBar() {
  return (
    <div className="top">
      <div className="wrap">
        <Link to="/" className="logo">
          <span className="ring">E</span>
          <b>
            ELVENT <i>TYRES</i>
          </b>
        </Link>
        <div className="meta">
          <span>
            📍 <b>{SHOP.addressShort}</b>, {SHOP.addressCity}
          </span>
          <span>
            🕐 {SHOP.hoursShort.split(" ")[0]}{" "}
            <b>{SHOP.hoursShort.split(" ")[1]}</b>
          </span>
        </div>
        <a
          className="callbtn"
          href={`https://wa.me/${SHOP.whatsapp}`}
          target="_blank"
          rel="noreferrer"
        >
          <WaIcon />
          {SHOP.phoneDisplay}
        </a>
      </div>
    </div>
  );
}

export function Ticker() {
  const items = [...SERVICES, ...SERVICES];
  return (
    <div className="ticker">
      <ul>
        {items.map((s, i) => (
          <li key={`${s[0]}-${i}`}>
            {s[0]} <b>{s[1]}</b>
          </li>
        ))}
      </ul>
    </div>
  );
}

export function Hero() {
  return (
    <div className="hero">
      <div className="wrap">
        <div className="txt">
          <div className="eyebrow">Welcome to Elvent Tyres</div>
          <h1>
            Used &amp; new tyres — <em>see it before you drive out.</em>
          </h1>
          <div className="rotor">
            {TAGLINES.map(t => (
              <span key={t}>{t}</span>
            ))}
          </div>
        </div>
        <div className="roller">
          <img src="/demo/roller.webp" alt="" />
        </div>
      </div>
    </div>
  );
}

export function Footer() {
  return (
    <footer>
      <div className="wrap">
        <div>
          <b>{SHOP.name}</b>
          <a href={SHOP.mapsUrl} target="_blank" rel="noreferrer">
            44 Voortrekker Rd, Goodwood
            <br />
            Cape Town, 7460
          </a>
        </div>
        <div>
          <b>Opening hours</b>
          {SHOP.hoursLong.split(", ")[0]}
          <br />
          {SHOP.hoursLong.split(", ")[1]}
        </div>
        <div>
          <b>Order or ask</b>
          <a
            href={`https://wa.me/${SHOP.whatsapp}`}
            target="_blank"
            rel="noreferrer"
          >
            WhatsApp {SHOP.phoneDisplay}
          </a>
          <br />
          <a href={`tel:${SHOP.phoneRaw}`}>Call {SHOP.phoneDisplay}</a>
        </div>
        <div>
          <b>Fitment services</b>
          {SERVICES.map(s => (
            <span key={s[0]}>
              {s[0]} {s[1]}
              <br />
            </span>
          ))}
          <Link className="staff" to="/admin">
            Staff login
          </Link>
        </div>
      </div>
    </footer>
  );
}
