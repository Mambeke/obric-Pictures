import { useQuery } from "convex/react";
import { useEffect, useMemo, useRef, useState } from "react";
import { useNavigate } from "react-router";
import { api } from "../../convex/_generated/api";
import { CartDrawer, Ribbon, ShopFooter, ShopHeader } from "@/shop/Chrome";
import { FilterIcon } from "@/shop/icons";
import {
  CAT_ORDER,
  matchTerm,
  money,
  type Piece,
  PRICE_BANDS,
  SEARCH_HINTS,
  SECTIONS,
  type Settings,
  sortSizes,
  SORTS,
  STATES,
  suggest,
  prettyCond,
} from "@/shop/lib";
import "@/shop/shop.css";

const STATE_LINE: Record<string, React.ReactNode> = {
  All: (
    <>
      <b>Everything on the rail</b> — <span className="gnew">new pieces</span> and{" "}
      <span className="gpre">pre-owned pieces</span> together, newest first.
    </>
  ),
  New: (
    <span className="gnew">
      <b>New</b> — brand new stock, tags still on, straight out of the packaging.
    </span>
  ),
  "Pre-owned": (
    <span className="gpre">
      <b>Pre-owned (bero)</b> — hand-picked, washed, pressed and quality checked before it goes on
      the rail.
    </span>
  ),
};

/** A horizontally scrollable tab rail with edge fades, desktop arrows and a progress bar. */
function Rail({ children, arrows = true }: { children: React.ReactNode; arrows?: boolean }) {
  const ref = useRef<HTMLDivElement>(null);
  const [st, setSt] = useState({ more: false, frac: 1, pos: 0, atStart: true, atEnd: false });

  const measure = () => {
    const r = ref.current;
    if (!r) return;
    const max = r.scrollWidth - r.clientWidth;
    setSt({
      more: max > 4,
      frac: max > 4 ? r.clientWidth / r.scrollWidth : 1,
      pos: max > 4 ? r.scrollLeft / max : 0,
      atStart: r.scrollLeft <= 2,
      atEnd: r.scrollLeft >= max - 2,
    });
  };
  // biome-ignore lint/correctness/useExhaustiveDependencies: re-measure when tabs change
  useEffect(() => {
    measure();
    window.addEventListener("resize", measure);
    return () => window.removeEventListener("resize", measure);
  }, [children]);

  const nudge = (dx: number) => ref.current?.scrollBy({ left: dx, behavior: "smooth" });

  return (
    <>
      <div className="railbox">
        {arrows && (
          <button
            type="button"
            className="arrow l"
            style={{ display: st.more && !st.atStart ? "grid" : "none" }}
            onClick={() => nudge(-220)}
          >
            ‹
          </button>
        )}
        <div className="rail" ref={ref} onScroll={measure}>
          {children}
        </div>
        {arrows && (
          <button
            type="button"
            className="arrow r"
            style={{ display: st.more && !st.atEnd ? "grid" : "none" }}
            onClick={() => nudge(220)}
          >
            ›
          </button>
        )}
        <div className="fade l" style={{ opacity: st.more && !st.atStart ? 1 : 0 }} />
        <div className="fade r" style={{ opacity: st.more && !st.atEnd ? 1 : 0 }} />
      </div>
      {arrows && (
        <div className="scrollbar">
          <i
            style={{
              width: `${Math.max(st.frac * 100, 12)}%`,
              marginLeft: `${st.pos * (100 - Math.max(st.frac * 100, 12))}%`,
            }}
          />
        </div>
      )}
    </>
  );
}

export function ShopPage() {
  const nav = useNavigate();
  const pieces = useQuery(api.shop.listPieces) as Piece[] | undefined;
  const settings = useQuery(api.shop.getSettings) as Settings | undefined;
  const cats = useQuery(api.shop.listCategories) as
    | { name: string; section: string }[]
    | undefined;

  const [who, setWho] = useState("All");
  const [state, setState] = useState<string | null>(null);
  const [cat, setCat] = useState("All");
  const [term, setTerm] = useState("");
  const [size, setSize] = useState("All");
  const [band, setBand] = useState("All");
  const [sort, setSort] = useState(SORTS[0]);
  const [showFilters, setShowFilters] = useState(false);
  const [hint, setHint] = useState('Search "dress"');

  // typing placeholder
  useEffect(() => {
    let w = 0;
    let c = 0;
    let del = false;
    let live = true;
    const tick = () => {
      if (!live) return;
      const word = SEARCH_HINTS[w % SEARCH_HINTS.length];
      c += del ? -1 : 1;
      setHint(`Search "${word.slice(0, c)}"`);
      let t = del ? 45 : 85;
      if (!del && c === word.length) {
        del = true;
        t = 1300;
      }
      if (del && c === 0) {
        del = false;
        w++;
        t = 260;
      }
      setTimeout(tick, t);
    };
    const id = setTimeout(tick, 700);
    return () => {
      live = false;
      clearTimeout(id);
    };
  }, []);

  const all = pieces ?? [];
  const byWho = (p: Piece, w: string) => w === "All" || p.section === w;
  const bySt = (p: Piece, s: string | null) => !s || p.state === s;
  const byCat = (p: Piece, c: string) => c === "All" || p.category === c;
  const count = (w: string, s: string | null, c: string) =>
    all.filter(p => byWho(p, w) && bySt(p, s) && byCat(p, c)).length;

  const catList = useMemo(() => {
    const have = new Set(all.filter(p => byWho(p, who) && bySt(p, state)).map(p => p.category));
    const extra = (cats ?? [])
      .filter(c => c.section === "All" || c.section === who || who === "All")
      .map(c => c.name);
    const ordered = [...CAT_ORDER, ...extra.filter(c => !CAT_ORDER.includes(c))];
    return ["All", ...ordered.filter(c => have.has(c))];
  }, [all, who, state, cats]);

  useEffect(() => {
    if (!catList.includes(cat)) setCat("All");
  }, [catList, cat]);

  const sizes = useMemo(
    () =>
      sortSizes([
        ...new Set(
          all.filter(p => byWho(p, who) && bySt(p, state) && byCat(p, cat)).map(p => p.size),
        ),
      ]),
    [all, who, state, cat],
  );

  const list = useMemo(() => {
    const t = term.trim().toLowerCase();
    const pr = PRICE_BANDS.find(x => x[0] === band) ?? PRICE_BANDS[0];
    const out = all.filter(
      p =>
        byWho(p, who) &&
        bySt(p, state) &&
        byCat(p, cat) &&
        (size === "All" || p.size === size) &&
        p.price >= pr[1] &&
        p.price <= pr[2] &&
        matchTerm(p, t),
    );
    if (sort === "Price low to high") out.sort((a, b) => a.price - b.price);
    else if (sort === "Price high to low") out.sort((a, b) => b.price - a.price);
    else out.sort((a, b) => b.createdAt - a.createdAt);
    return out;
  }, [all, who, state, cat, size, band, sort, term]);

  // ---- pages of eight rows ---------------------------------------------
  // Eight rows of cards, then a new page: nobody should scroll for a minute
  // before they forget what they came for.
  const gridRef = useRef<HTMLDivElement>(null);
  const [cols, setCols] = useState(2);
  const [page, setPage] = useState(0);

  // biome-ignore lint/correctness/useExhaustiveDependencies: re-measure when the grid fills
  useEffect(() => {
    const el = gridRef.current;
    if (!el) return;
    const read = () => {
      const n = getComputedStyle(el).gridTemplateColumns.split(" ").filter(Boolean).length;
      if (n > 0) setCols(n);
    };
    read();
    const t1 = setTimeout(read, 60);
    const t2 = setTimeout(read, 400);
    const ro = new ResizeObserver(read);
    ro.observe(el);
    window.addEventListener("resize", read);
    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
      ro.disconnect();
      window.removeEventListener("resize", read);
    };
  }, [list.length]);

  const perPage = cols * 8;
  const pages = Math.max(1, Math.ceil(list.length / perPage));
  const pg = Math.min(page, pages - 1);
  const shown = list.slice(pg * perPage, pg * perPage + perPage);

  // any change of filter or search starts again at page one
  // biome-ignore lint/correctness/useExhaustiveDependencies: reset on filter change
  useEffect(() => {
    setPage(0);
  }, [who, state, cat, size, band, sort, term]);

  const goPage = (n: number) => {
    setPage(n);
    const top = gridRef.current?.getBoundingClientRect().top ?? 0;
    window.scrollTo({ top: window.scrollY + top - 120, behavior: "smooth" });
  };

  const fix = term.trim() && list.length === 0 ? suggest(term.trim().toLowerCase(), all) : null;
  const filtered = size !== "All" || band !== "All" || sort !== SORTS[0];

  if (!settings) return null;

  return (
    <>
      <div className="top">
        <ShopHeader
          settings={settings}
          search={{ term, setTerm, placeholder: hint, run: () => setTerm(t => t) }}
        />
        <Ribbon items={settings.ribbon} />
      </div>

      <main>
        <div className="tabsec">
          <div className="wrap">
            <Rail>
              {SECTIONS.map(w => (
                <button
                  key={w}
                  type="button"
                  className={`tab${w === who ? " on" : ""}`}
                  onClick={() => setWho(w)}
                >
                  {w === "All" ? "All stock" : w} <i>({count(w, null, "All")})</i>
                </button>
              ))}
            </Rail>

            <div className="railbox">
              <div className="rail staterail" style={{ padding: "4px 0 8px" }}>
                <button
                  type="button"
                  className={`tab2 all${state === null ? " on" : ""}`}
                  onClick={() => setState(null)}
                >
                  ALL <i>({count(who, null, "All")})</i>
                </button>
                {STATES.map(s => {
                  const n = count(who, s, "All");
                  return (
                    <button
                      key={s}
                      type="button"
                      disabled={n === 0}
                      className={`tab2 ${s === "New" ? "new" : "pre"}${s === state ? " on" : ""}`}
                      style={n === 0 ? { opacity: 0.38, cursor: "default" } : undefined}
                      onClick={() => setState(state === s ? null : s)}
                    >
                      {s.toUpperCase()} <i>({n})</i>
                    </button>
                  );
                })}
              </div>
            </div>
            <div className="stateline on">{STATE_LINE[state ?? "All"]}</div>

            <Rail>
              {catList.map(c => (
                <button
                  key={c}
                  type="button"
                  className={`tab3${c === cat ? " on" : ""}`}
                  onClick={() => setCat(c)}
                >
                  {c === "All" ? "Everything" : c} <i>({count(who, state, c)})</i>
                </button>
              ))}
            </Rail>

            <div className="filterline">
              <button type="button" className="fbtn" onClick={() => setShowFilters(f => !f)}>
                <FilterIcon />
                <span>{showFilters ? "Hide filters" : "Show filters"}</span>
              </button>
              <span className="count">
                {list.length} {list.length === 1 ? "piece" : "pieces"}
              </span>
              {filtered && (
                <button
                  type="button"
                  className="clearf"
                  onClick={() => {
                    setSize("All");
                    setBand("All");
                    setSort(SORTS[0]);
                  }}
                >
                  Clear
                </button>
              )}
            </div>
          <div className={`fpanel${showFilters ? " on" : ""}`}>
            <div className="frow">
              <label>Size</label>
              <div className="chips">
                {["All", ...sizes].map(s => (
                  <button
                    key={s}
                    type="button"
                    className={`chip${s === size ? " on" : ""}`}
                    onClick={() => setSize(s)}
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>
            <div className="frow">
              <label>Price</label>
              <div className="chips">
                {PRICE_BANDS.map(b => (
                  <button
                    key={b[0]}
                    type="button"
                    className={`chip${b[0] === band ? " on" : ""}`}
                    onClick={() => setBand(b[0])}
                  >
                    {b[0]}
                  </button>
                ))}
              </div>
            </div>
            <div className="frow">
              <label>Sort</label>
              <div className="chips">
                {SORTS.map(s => (
                  <button
                    key={s}
                    type="button"
                    className={`chip${s === sort ? " on" : ""}`}
                    onClick={() => setSort(s)}
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>
          </div>
          </div>
        </div>

        <div className="wrap">
          {fix && (
            <div className="didyou">
              Showing nothing for "{term.trim()}" — did you mean{" "}
              <button type="button" onClick={() => setTerm(fix)}>
                {fix}
              </button>
              ?
            </div>
          )}

          <div
            ref={gridRef}
            className={`grid${state === "New" ? " tnew" : ""}${state === "Pre-owned" ? " tpre" : ""}`}
          >
            {shown.map(p => (
              <button
                key={p._id}
                type="button"
                className="card"
                onClick={() => nav(`/piece/${p._id}`)}
              >
                <div className="ph">
                  {p.badge && p.badge !== "NEW IN" && (
                    <span className={`bdg ${p.badge === "SALE" ? "sale" : ""}`}>{p.badge}</span>
                  )}
                  {p.badge === "NEW IN" && state !== "New" && <span className="bdg new">{p.badge}</span>}
                  <span className="one">Last one</span>
                  <img src={p.photoUrls[0]} alt={p.name} loading="lazy" />
                </div>
                <div className="cb">
                  <div className="br">{p.brand}</div>
                  <div className="nm">{p.name}</div>
                  <div className="cond">{prettyCond(p.cond)}</div>
                  <div className="pr">
                    <b>{money(p.price)}</b>
                    {p.wasPrice ? <s>{money(p.wasPrice)}</s> : null}
                    <span className="sz">{p.size}</span>
                  </div>
                </div>
              </button>
            ))}
          </div>

          {pages > 1 && (
            <div className="pager">
              <button
                type="button"
                className="pnav"
                disabled={pg === 0}
                onClick={() => goPage(pg - 1)}
              >
                ‹ Back
              </button>
              <div className="pnums">
                {Array.from({ length: pages }, (_, n) => (
                  <button
                    key={n}
                    type="button"
                    className={`pnum${n === pg ? " on" : ""}`}
                    onClick={() => goPage(n)}
                  >
                    {n + 1}
                  </button>
                ))}
              </div>
              <button
                type="button"
                className="pnav"
                disabled={pg === pages - 1}
                onClick={() => goPage(pg + 1)}
              >
                Next ›
              </button>
              <span className="pinfo">
                Page {pg + 1} of {pages} · {list.length} pieces
              </span>
            </div>
          )}

          {list.length === 0 && !fix && (
            <div className="didyou">
              Nothing on the rail right now. Message the shop and ask — new pieces come in every
              week.
            </div>
          )}
        </div>

        <div className="strip">
          <div className="wrap">
            <div className="four">
              <div>
                <b>Measured, not guessed</b>
                <span>Chest, waist and length on every item, so nothing arrives too small.</span>
              </div>
              <div>
                <b>We hold it 24 hours</b>
                <span>Tap "Hold for me" and it is off the shop while you send the money.</span>
              </div>
              <div>
                <b>Lay-bye on new stock</b>
                <span>Half now, the rest inside two months, on new items over $20.</span>
              </div>
            </div>
          </div>
        </div>
      </main>

      <ShopFooter settings={settings} />
      <CartDrawer settings={settings} />
    </>
  );
}
