import { useNavigate } from "react-router";
import { type Card, FALLBACK_PHOTO, SHOP, waLink } from "./shopConfig";
import { WaIcon } from "./WaIcon";

export function TyreCard({ t }: { t: Card }) {
  const navigate = useNavigate();
  const photo = t.photos[0] ?? FALLBACK_PHOTO;

  return (
    <div
      className="card"
      onClick={() => navigate(`/t/${t.id}`)}
      onKeyDown={e => {
        if (e.key === "Enter") navigate(`/t/${t.id}`);
      }}
      role="link"
      tabIndex={0}
    >
      <div className="ph">
        <img src={photo} alt={`${t.sizeLabel} ${t.brand}`} loading="lazy" />
        <span className="sz">{t.sizeLabel}</span>
        <span className={`cond ${t.condition === "new" ? "n" : "u"}`}>
          {t.condition}
        </span>
        {t.photoCount > 1 && (
          <span className="pc">📷 {t.photoCount} photos</span>
        )}
      </div>
      <div className="body">
        <div className="brand">{t.brand}</div>
        <div className="sub">
          {t.condition === "new" ? "New" : "Used"} ·{" "}
          {t.stock > 1 ? `${t.stock} in stock` : "single"}
        </div>
        <div className="price">
          R {t.price}
          <u>each</u>
        </div>
        <div className="acts">
          <a
            className="btn wa"
            href={waLink(t)}
            target="_blank"
            rel="noreferrer"
            onClick={e => e.stopPropagation()}
          >
            <WaIcon size={12} />
            WhatsApp
          </a>
          <a
            className="btn cl"
            href={`tel:${SHOP.phoneRaw}`}
            onClick={e => e.stopPropagation()}
          >
            Call
          </a>
        </div>
      </div>
    </div>
  );
}
