import { useAuthActions } from "@convex-dev/auth/react";
import { useState } from "react";
import { Link } from "react-router";
import "../shop.css";
import { PasswordField } from "@/components/PasswordField";
import { SHOP } from "@/shop/shopConfig";

/**
 * Staff login for the shop.
 *
 * This deliberately does NOT use the generic template login screen — that one
 * is built on a different design system and its labels collided on a phone.
 * This is plain shop CSS, one column, big tap targets.
 */
export function LoginPage() {
  const { signIn } = useAuthActions();
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  return (
    <div className="adm">
      <div className="admbar">
        <div className="wrap">
          <Link to="/" className="logo">
            <span className="ring">E</span>
            <b>
              ELVENT <i>TYRES</i>
            </b>
          </Link>
          <Link to="/" className="lnk" style={{ marginLeft: "auto" }}>
            View shop
          </Link>
        </div>
      </div>

      <div className="loginwrap">
        <div className="panel">
          <h2>Staff login</h2>
          <p className="hint" style={{ marginTop: -8, marginBottom: 16 }}>
            For {SHOP.name} staff only. Customers don't need an account.
          </p>

          <form
            onSubmit={async e => {
              e.preventDefault();
              setError("");
              setLoading(true);
              const form = new FormData(e.currentTarget);
              const email = String(form.get("email") ?? "");
              // test accounts use a separate provider
              const provider = email.endsWith("@test.local")
                ? "test"
                : "password";
              form.set("flow", "signIn");
              try {
                await signIn(provider, form);
              } catch {
                setError("That email and password don't match. Try again.");
              } finally {
                setLoading(false);
              }
            }}
          >
            <div className="field" style={{ marginBottom: 14 }}>
              <label htmlFor="email">Email</label>
              <input
                id="email"
                name="email"
                type="email"
                autoComplete="email"
                placeholder="you@example.com"
                required
              />
            </div>

            <PasswordField
              id="password"
              name="password"
              label="Password"
              placeholder="Your password"
              autoComplete="current-password"
            />

            {error && <div className="formerr">{error}</div>}

            <button type="submit" className="pbtn wide" disabled={loading}>
              {loading ? "Signing in…" : "Sign in"}
            </button>
          </form>

          <p className="hint" style={{ marginTop: 14, textAlign: "center" }}>
            <Link
              to="/recover"
              style={{ color: "var(--green)", fontWeight: 700 }}
            >
              Forgot your password?
            </Link>
          </p>

          <p className="hint" style={{ marginTop: 8, textAlign: "center" }}>
            First time?{" "}
            <Link
              to="/signup"
              style={{ color: "var(--green)", fontWeight: 700 }}
            >
              Create your account
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}
