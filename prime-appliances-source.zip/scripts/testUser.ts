export const TEST_USER = {
  email: "agent-ia1acv4cfzd584sx@test.local",
  password: "xxfQivPs-yvmSLpgUci_i2hhPPZQkfFZ",
  name: "Test Agent",
} as const;
