/**
 * The full catalogue of models, storage sizes and colours the shop can talk
 * about — not just what happens to be in stock. Refurbished stock is sourced
 * to order, so a customer must be able to pick any model here.
 * Everything is editable in one place.
 */

export const IPHONE_MODELS = [
  "iPhone 17 Pro Max",
  "iPhone 17 Pro",
  "iPhone 17 Air",
  "iPhone 17",
  "iPhone 16 Pro Max",
  "iPhone 16 Pro",
  "iPhone 16 Plus",
  "iPhone 16",
  "iPhone 16e",
  "iPhone 15 Pro Max",
  "iPhone 15 Pro",
  "iPhone 15 Plus",
  "iPhone 15",
  "iPhone 14 Pro Max",
  "iPhone 14 Pro",
  "iPhone 14 Plus",
  "iPhone 14",
  "iPhone 13 Pro Max",
  "iPhone 13 Pro",
  "iPhone 13",
  "iPhone 13 mini",
  "iPhone 12 Pro Max",
  "iPhone 12 Pro",
  "iPhone 12",
  "iPhone 12 mini",
  "iPhone 11 Pro Max",
  "iPhone 11 Pro",
  "iPhone 11",
  "iPhone SE (3rd gen)",
  "iPhone SE (2nd gen)",
  "iPhone XS Max",
  "iPhone XS",
  "iPhone XR",
  "iPhone X",
];

export const SAMSUNG_MODELS = [
  "Galaxy S25 Ultra",
  "Galaxy S25+",
  "Galaxy S25",
  "Galaxy S24 Ultra",
  "Galaxy S24+",
  "Galaxy S24",
  "Galaxy S24 FE",
  "Galaxy S23 Ultra",
  "Galaxy S23+",
  "Galaxy S23",
  "Galaxy S23 FE",
  "Galaxy S22 Ultra",
  "Galaxy S22+",
  "Galaxy S22",
  "Galaxy S21 Ultra",
  "Galaxy S21+",
  "Galaxy S21",
  "Galaxy S21 FE",
  "Galaxy S20 Ultra",
  "Galaxy S20+",
  "Galaxy S20",
  "Galaxy S20 FE",
  "Galaxy Note 20 Ultra",
  "Galaxy Note 20",
  "Galaxy Note 10+",
  "Galaxy Note 10",
  "Galaxy Note 9",
  "Galaxy Note 8",
  "Galaxy S10+",
  "Galaxy S10",
  "Galaxy S10e",
  "Galaxy S9+",
  "Galaxy S9",
  "Galaxy S8+",
  "Galaxy S8",
  "Galaxy Z Fold 6",
  "Galaxy Z Fold 5",
  "Galaxy Z Fold 4",
  "Galaxy Z Fold 3",
  "Galaxy Z Flip 6",
  "Galaxy Z Flip 5",
  "Galaxy Z Flip 4",
  "Galaxy Z Flip 3",
  "Galaxy A56",
  "Galaxy A55",
  "Galaxy A54",
  "Galaxy A53",
  "Galaxy A52s",
  "Galaxy A50",
  "Galaxy A57",
  "Galaxy A80",
  "Galaxy A73",
  "Galaxy A71",
  "Galaxy A36",
  "Galaxy A35",
  "Galaxy A34",
  "Galaxy A25",
  "Galaxy A16",
  "Galaxy A15",
  "Galaxy A14",
  "Galaxy A06",
  "Galaxy A05",
  "Galaxy Tab S10",
  "Galaxy Tab S9",
  "Galaxy Tab A9",
];

export const STORAGE_SIZES = [
  "32GB",
  "64GB",
  "128GB",
  "256GB",
  "512GB",
  "1TB",
  "2TB",
];

/** Colour name → the dot / text colour used for it on the site. */
export const COLOUR_HEX: Record<string, string> = {
  Black: "#1c1c1e",
  "Space Grey": "#4a4a4f",
  Graphite: "#54534f",
  Midnight: "#1f2733",
  White: "#f4f4f6",
  Starlight: "#f2ece1",
  Silver: "#d9dde1",
  Gold: "#d4a94f",
  "Rose Gold": "#e0a396",
  Bronze: "#b07a4e",
  Blue: "#2b5fa8",
  "Sierra Blue": "#8fb4d9",
  "Pacific Blue": "#2c4f68",
  "Titanium Blue": "#5b7d99",
  Ultramarine: "#4257c4",
  Navy: "#1f2f52",
  Teal: "#2f8f8a",
  Green: "#2f7d55",
  "Alpine Green": "#48644f",
  "Midnight Green": "#39514a",
  Mint: "#a9d6bd",
  Yellow: "#e2c14a",
  Orange: "#d97a2b",
  "Cosmic Orange": "#c85c22",
  Coral: "#e07a5f",
  Red: "#c0392b",
  Purple: "#8a7ab8",
  "Deep Purple": "#5c4a72",
  Lavender: "#c2b8e0",
  Violet: "#7a5ea8",
  Pink: "#e39aab",
  Cream: "#eee6d8",
  "Desert Titanium": "#bda28a",
  "Natural Titanium": "#a89e94",
  "White Titanium": "#e8e6e2",
  "Black Titanium": "#33322f",
  Grey: "#8e8e93",
};

export const IPHONE_COLOURS = [
  "Black",
  "White",
  "Silver",
  "Space Grey",
  "Graphite",
  "Midnight",
  "Starlight",
  "Gold",
  "Rose Gold",
  "Blue",
  "Sierra Blue",
  "Pacific Blue",
  "Ultramarine",
  "Teal",
  "Green",
  "Alpine Green",
  "Midnight Green",
  "Yellow",
  "Coral",
  "Cosmic Orange",
  "Red",
  "Purple",
  "Deep Purple",
  "Pink",
  "Natural Titanium",
  "Blue Titanium",
  "White Titanium",
  "Black Titanium",
  "Desert Titanium",
];

export const SAMSUNG_COLOURS = [
  "Black",
  "Phantom Black",
  "Grey",
  "Graphite",
  "White",
  "Cream",
  "Silver",
  "Titanium Grey",
  "Titanium Black",
  "Titanium Violet",
  "Titanium Yellow",
  "Blue",
  "Navy",
  "Green",
  "Mint",
  "Lavender",
  "Violet",
  "Pink",
  "Yellow",
  "Orange",
  "Red",
  "Gold",
];

/** Best-guess swatch for a colour we do not have an exact entry for. */
export function colourHex(name: string): string {
  if (!name) return "#b9c0c7";
  const exact = COLOUR_HEX[name];
  if (exact) return exact;
  const lower = name.toLowerCase();
  const hit = Object.keys(COLOUR_HEX).find(k =>
    lower.includes(k.toLowerCase()),
  );
  if (hit) return COLOUR_HEX[hit];
  const word = Object.keys(COLOUR_HEX).find(k =>
    k.toLowerCase().split(" ").some(w => lower.includes(w)),
  );
  return word ? COLOUR_HEX[word] : "#b9c0c7";
}

/**
 * Same colour, darkened enough to stay readable as text on white.
 * White, cream and silver would otherwise disappear.
 */
export function colourText(name: string): string {
  const hex = colourHex(name);
  const num = parseInt(hex.slice(1), 16);
  let r = (num >> 16) & 255;
  let g = (num >> 8) & 255;
  let b = num & 255;
  const luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
  if (luminance > 0.55) {
    const factor = 0.42 / Math.max(luminance, 0.01);
    r = Math.round(r * factor);
    g = Math.round(g * factor);
    b = Math.round(b * factor);
  }
  return `rgb(${r}, ${g}, ${b})`;
}

export function modelsFor(brand: string): string[] {
  if (brand === "Apple") return IPHONE_MODELS;
  if (brand === "Samsung") return SAMSUNG_MODELS;
  return [];
}

export function coloursFor(brand: string): string[] {
  if (brand === "Apple") return IPHONE_COLOURS;
  if (brand === "Samsung") return SAMSUNG_COLOURS;
  return [...new Set([...IPHONE_COLOURS, ...SAMSUNG_COLOURS])];
}
