import { runTest } from "./auth";

/** The footer link must end up in the owner panel, not back on the shop. */
runTest("Owner login lands in the back office", async helper => {
  const { page } = helper;
  await helper.goto("/");
  await page.click("text=Shop owner login");
  await page.waitForTimeout(2500);
  console.log("after link:", new URL(page.url()).pathname);
  const path = new URL(page.url()).pathname;
  if (path !== "/admin") throw new Error(`landed on ${path}, not /admin`);
  // A signed-in non-owner correctly gets the "not the owner" notice; an owner
  // gets the panel. Either proves the link no longer bounces to the shop.
  await page.waitForSelector("text=/Add an appliance|owner/i", { timeout: 25000 });
  console.log("OK: the link lands on /admin and stays there");
}).catch(() => process.exit(1));
