export const APP_NAME = "Elvent Tyres";
