import { useQuery } from "convex/react";
import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router";
import { api } from "../../convex/_generated/api";
import { CartDrawer, ShopFooter, ShopHeader, useBodyClass } from "@/shop/Chrome";
import { CartIcon, WhatsAppIcon } from "@/shop/icons";
import { Gallery } from "@/shop/Gallery";
import { useCart } from "@/shop/CartContext";
import {
  deliveryDate,
  holdMessage,
  money,
  orderMessage,
  prettyCond,
  type Piece,
  type Settings,
  waLink,
} from "@/shop/lib";
import "@/shop/shop.css";

export function PiecePage() {
  const { id } = useParams();
  const nav = useNavigate();
  const cart = useCart();
  useBodyClass("onitem");
  // land at the top of the page so the whole photo is in view, never half of it
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [id]);
  const piece = useQuery(api.shop.getPiece, id ? { id: id as never } : "skip") as
    | Piece
    | null
    | undefined;
  const settings = useQuery(api.shop.getSettings) as Settings | undefined;
  const [deliver, setDeliver] = useState(false);
  const [townIdx, setTownIdx] = useState(0);

  if (!settings) return null;
  if (piece === undefined) return null;
  if (piece === null) {
    return (
      <div className="wrap" style={{ padding: 40 }}>
        <p>That piece is no longer on the rail.</p>
        <button type="button" className="back" onClick={() => nav("/")}>
          ← Back to the shop
        </button>
      </div>
    );
  }

  const town = settings.deliveryTowns[townIdx] ?? settings.deliveryTowns[0];
  const delivery = deliver ? town : null;
  const total = piece.price + (delivery?.fee ?? 0);
  const layBye =
    settings.laybyeEnabled && piece.state === "New" && piece.price >= settings.laybyeMinPrice;

  return (
    <>
      <div className="top">
        <ShopHeader settings={settings} />
        <div className="backbarfix">
          <div className="wrap">
            <div className="in">
              <button type="button" className="back" onClick={() => nav("/")}>
                ← Back to the shop
              </button>
              <div className="nm desktoponly">
                {piece.brand} · {piece.name}
              </div>
            </div>
          </div>
        </div>
      </div>

      <section>
        <div className="wrap">
          <div className="pgrid">
            <div className="pimgcol">
              <Gallery photos={piece.photoUrls} alt={piece.name} />
            </div>
            <div>
              <div className="pline">
                <div className="brand">{piece.brand}</div>
                <div className="pricebox">{money(piece.price)}</div>
              </div>
              <h1>{piece.name}</h1>
              <div className="pmeta">
                {prettyCond(piece.cond)} · size <b>{piece.size}</b>
              </div>

              <div className="extras">
                {piece.meas && (
                  <div className="ex">
                    <span>Measurements:</span>
                    <b>{piece.meas}</b>
                  </div>
                )}
                <div className="ex">
                  <span>Section:</span>
                  <b>
                    {piece.section} · {piece.category} · {piece.state}
                  </b>
                </div>
                <div className="ex">
                  <span>Stock:</span>
                  <b>One piece only, not repeated</b>
                </div>
                <div className="ex">
                  <span>Care:</span>
                  <b>
                    {piece.state === "New"
                      ? "Brand new, tags still on"
                      : "Washed, pressed and quality checked"}
                  </b>
                </div>
              </div>

              {layBye && (
                <div className="lay">
                  <b>Lay-bye</b> — pay ${Math.ceil(piece.price / 2)} now and the rest inside{" "}
                  {settings.laybyeMonths} months. New stock only.
                </div>
              )}

              <div className="deliv">
                <label>
                  <input type="checkbox" checked={deliver} onChange={e => setDeliver(e.target.checked)} />
                  <span>
                    <b>Add delivery</b>
                    <br />
                    <span style={{ color: "#8a6a4d" }}>
                      Harare ${settings.deliveryTowns[0]?.fee ?? 2} · other towns $5. Leave it
                      unticked to collect or arrange on WhatsApp.
                    </span>
                  </span>
                </label>
                {deliver && (
                  <>
                    <select value={townIdx} onChange={e => setTownIdx(Number(e.target.value))}>
                      {settings.deliveryTowns.map((t, i) => (
                        <option key={t.town} value={i}>
                          {t.town} — ${t.fee}
                        </option>
                      ))}
                    </select>
                    <div className="delwhen">
                      <b>Delivered by {deliveryDate(town.days)}</b> — {money(piece.price)} + $
                      {town.fee} delivery = <b>{money(total)}</b>
                    </div>
                  </>
                )}
              </div>

              {piece.desc && (
                <div className="pdesc">
                  <b>From the seller</b>
                  <br />
                  {piece.desc}
                </div>
              )}
            </div>
          </div>
        </div>
      </section>

      <ShopFooter settings={settings} />

      <div className="stickybtns">
        <div className="wrap">
          <div className="btnrow">
            <a
              className="btn wa"
              target="_blank"
              rel="noreferrer"
              href={waLink(settings.whatsapp, orderMessage(settings.shopName, piece, delivery))}
            >
              <WhatsAppIcon />
              <span>Order on WhatsApp</span>
            </a>
            <a
              className="btn hold"
              target="_blank"
              rel="noreferrer"
              href={waLink(settings.whatsapp, holdMessage(settings.shopName, piece))}
            >
              Hold for me
            </a>
            <button
              type="button"
              className="btn gh"
              onClick={() => {
                cart.add(piece);
                cart.setOpen(true);
              }}
            >
              <CartIcon />
              <span>Add to cart</span>
              {cart.items.length > 0 && <i>{cart.items.length}</i>}
            </button>
          </div>
        </div>
      </div>
      <CartDrawer settings={settings} />
    </>
  );
}
