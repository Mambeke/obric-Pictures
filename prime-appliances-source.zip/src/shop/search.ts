/**
 * Forgiving search. Customers type "fridg", "DEFY", "50inch", "washingmachine"
 * — all of them must find the appliance. Case and punctuation are ignored,
 * letters glued to digits are split, plurals are stripped, a word within a
 * letter or two of a real word still matches, and everyday words for the same
 * thing are treated as one.
 */

const ALIASES: Record<string, string[]> = {
  fridge: ["fridge", "refrigerator"],
  refrigerator: ["fridge", "refrigerator"],
  freezer: ["freezer", "chest"],
  stove: ["stove", "oven", "hob"],
  oven: ["stove", "oven"],
  hob: ["stove", "hob"],
  cooker: ["stove", "oven"],
  washer: ["washing", "machine", "loader"],
  washing: ["washing", "machine", "loader"],
  machine: ["washing", "machine"],
  dryer: ["dryer", "tumble"],
  tumble: ["dryer", "tumble"],
  tv: ["tv", "television"],
  television: ["tv", "television"],
  telly: ["tv", "television"],
  micro: ["microwave"],
  microwave: ["microwave"],
  dishwasher: ["dishwasher", "dish"],
  inch: ["inch"],
  litre: ["litre", "l"],
  liter: ["litre", "l"],
  kg: ["kg"],
  cheap: ["fair"],
  used: ["used", "second", "hand"],
};
/** Split glued letter/digit runs and drop punctuation. */
export function tokenise(text: string): string[] {
  return text
    .toLowerCase()
    .replace(/([a-z])(\d)/g, "$1 $2")
    .replace(/(\d)([a-z])/g, "$1 $2")
    .split(/[^a-z0-9]+/)
    .filter(Boolean);
}

function singular(word: string): string {
  if (word.length > 3 && word.endsWith("s") && !word.endsWith("ss")) {
    return word.slice(0, -1);
  }
  return word;
}

/** Levenshtein distance, capped for speed. */
function distance(a: string, b: string, cap: number): number {
  if (Math.abs(a.length - b.length) > cap) return cap + 1;
  let prev = Array.from({ length: b.length + 1 }, (_, i) => i);
  for (let i = 1; i <= a.length; i++) {
    const row = [i];
    let best = i;
    for (let j = 1; j <= b.length; j++) {
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      const value = Math.min(row[j - 1] + 1, prev[j] + 1, prev[j - 1] + cost);
      row.push(value);
      if (value < best) best = value;
    }
    if (best > cap) return cap + 1;
    prev = row;
  }
  return prev[b.length];
}

function tolerance(word: string): number {
  if (word.length <= 3) return 0;
  if (word.length <= 6) return 1;
  return 2;
}

const isNumber = (w: string) => /^\d+$/.test(w);

function wordMatches(needle: string, haystackWords: string[]): boolean {
  const want = singular(needle);

  // A number is a model number, not a fuzzy word. "iPhone 16" must never
  // answer with an iPhone 17, and must never match a price like 16999.
  if (isNumber(want)) return haystackWords.some(hw => hw === want);

  const cap = tolerance(want);
  return haystackWords.some(hw => {
    const have = singular(hw);
    if (have.startsWith(want) || want.startsWith(have)) return true;
    if (have.includes(want) && want.length >= 3) return true;
    return cap > 0 && distance(want, have, cap) <= cap;
  });
}

/** Every field a customer might type, as one bag of words. */
export function haystack(parts: (string | undefined)[]): string[] {
  const words = tokenise(parts.filter(Boolean).join(" "));
  const glued = words.join("");
  return [...new Set([...words, glued])];
}

/** True when the query matches this bag of words. */
export function matches(query: string, bag: string[]): boolean {
  const raw = tokenise(query);
  if (raw.length === 0) return true;

  const glued = raw.join("");
  if (!raw.some(isNumber) && bag.some(w => w.includes(glued)) && glued.length >= 4) {
    return true;
  }

  return raw.every(word => {
    const options = ALIASES[singular(word)] ?? [word];
    return options.some(option => wordMatches(option, bag));
  });
}
