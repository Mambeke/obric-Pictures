"""Load sample stock (with photos) into a Prime Appliances deployment.

    uv run python scripts/seedDemo.py <convex-site-url>
"""

import io
import json
import sys
import pathlib
import httpx
from PIL import Image

SECRET = "prime-seed-2026"
IMG_DIR = pathlib.Path("/work/temp/prime/img")


def upload(site: str, name: str) -> str:
    im = Image.open(IMG_DIR / f"{name}.webp").convert("RGB")
    im.thumbnail((1200, 1200))
    buf = io.BytesIO()
    im.save(buf, "JPEG", quality=86)
    r = httpx.post(
        f"{site}/seedPhoto",
        content=buf.getvalue(),
        headers={"Content-Type": "image/jpeg", "x-seed-secret": SECRET},
        timeout=60,
    )
    r.raise_for_status()
    return r.json()["id"]


def item(photo, category, title, condition, price, tested, free, specs, note, sold=False):
    return dict(
        category=category,
        title=title,
        condition=condition,
        price=price,
        testedOn=tested,
        freeDelivery=free,
        specs=[{"label": a, "value": b} for a, b in specs],
        description=note,
        sold=sold,
        photos=[photo],
    )


def main() -> None:
    site = sys.argv[1].rstrip("/")
    photos = {n: upload(site, n) for n in
              ["fridge", "stove", "washer", "tv", "microwave", "freezer", "dishwasher", "dryer"]}
    print("photos uploaded")

    items = [
        item(photos["fridge"], "Fridges", "Defy 235L double door fridge", "Excellent", 3200,
             "24 Aug 2026", True,
             [("Capacity", "235 litres"), ("Doors", "2 (fridge + freezer)"), ("Colour", "Silver"), ("Age", "About 3 years")],
             "Runs cold and quiet. Shelves all there. Small scuff on the right side, not visible against a wall."),
        item(photos["stove"], "Stoves & ovens", "Kelvinator 4-plate electric stove", "Good", 2450,
             "26 Aug 2026", True,
             [("Plates", "4 solid"), ("Oven", "Yes, with grill"), ("Width", "600mm"), ("Power", "Electric")],
             "All four plates heat. Oven thermostat tested. One knob replaced."),
        item(photos["washer"], "Washing machines", "Samsung 7kg front loader", "Good", 2900,
             "25 Aug 2026", False,
             [("Load", "7 kg"), ("Type", "Front loader"), ("Spin", "1200 rpm"), ("Age", "About 4 years")],
             "Full wash cycle run before listing. Door seal clean, no smell."),
        item(photos["tv"], "TVs", 'Hisense 50" smart TV', "Excellent", 3400,
             "27 Aug 2026", True,
             [("Screen size", "50 inch"), ("Smart", "Yes — WiFi, apps"), ("Remote", "Included"), ("Ports", "3 x HDMI")],
             "Screen clean, no dead pixels. Original remote included."),
        item(photos["microwave"], "Microwaves", "LG 30L stainless microwave", "Good", 750,
             "26 Aug 2026", False,
             [("Capacity", "30 litres"), ("Power", "1000W"), ("Turntable", "Yes"), ("Finish", "Stainless steel")],
             "Heats strongly. Light mark on the door handle."),
        item(photos["freezer"], "Freezers", "Defy 210L chest freezer", "Fair", 2100,
             "20 Aug 2026", False,
             [("Capacity", "210 litres"), ("Type", "Chest"), ("Baskets", "1 included"), ("Age", "About 7 years")],
             "Freezes well. Dent on the front panel — priced for it."),
        item(photos["dishwasher"], "Dishwashers", "Bosch 12-place dishwasher", "Good", 3900,
             "23 Aug 2026", True,
             [("Place settings", "12"), ("Programmes", "5"), ("Finish", "Stainless steel"), ("Age", "About 5 years")],
             "Full cycle tested with the shop's own dishes. Racks in good order."),
        item(photos["dryer"], "Tumble dryers", "Defy 8kg tumble dryer", "Fair", 1450,
             "19 Aug 2026", False,
             [("Load", "8 kg"), ("Type", "Vented"), ("Heat settings", "2"), ("Age", "About 6 years")],
             "Dries well. Takes a little longer than new — priced low for that."),
        item(photos["fridge"], "Fridges", "Hisense 90L bar fridge", "Good", 1150,
             "18 Aug 2026", False,
             [("Capacity", "90 litres"), ("Doors", "1"), ("Ice box", "Yes"), ("Age", "About 4 years")],
             "Ideal for a room or a small flat. Gets properly cold."),
        item(photos["washer"], "Washing machines", "LG 13kg top loader", "Excellent", 4300,
             "27 Aug 2026", True,
             [("Load", "13 kg"), ("Type", "Top loader"), ("Programmes", "8"), ("Age", "About 2 years")],
             "Almost new — the owner emigrated. Full wash tested."),
        item(photos["tv"], "TVs", 'Samsung 32" LED TV', "Fair", 1250,
             "15 Aug 2026", False,
             [("Screen size", "32 inch"), ("Smart", "No"), ("Remote", "Not included"), ("Ports", "2 x HDMI")],
             "Picture is good. No remote — the buttons on the set work."),
        item(photos["stove"], "Stoves & ovens", "Defy gas hob + electric oven", "Good", 3600,
             "21 Aug 2026", True,
             [("Plates", "4 gas burners"), ("Oven", "Electric"), ("Width", "600mm"), ("Age", "About 5 years")],
             "Every burner lights first time. Oven door seal good."),
        item(photos["microwave"], "Microwaves", "Defy 20L microwave", "Good", 550,
             "10 Aug 2026", False,
             [("Capacity", "20 litres"), ("Power", "700W")], "", sold=True),
        item(photos["fridge"], "Fridges", "Samsung 320L fridge freezer", "Excellent", 5200,
             "08 Aug 2026", True,
             [("Capacity", "320 litres"), ("Doors", "2")], "", sold=True),
        item(photos["dryer"], "Tumble dryers", "Bosch 7kg tumble dryer", "Good", 1900,
             "05 Aug 2026", False,
             [("Load", "7 kg"), ("Type", "Vented")], "", sold=True),
    ]

    r = httpx.post(f"{site}/seed", json={"secret": SECRET, "items": items}, timeout=120)
    print(r.status_code, r.text)


if __name__ == "__main__":
    main()
