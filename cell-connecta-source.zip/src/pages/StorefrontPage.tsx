import { useQuery } from "convex/react";
import { useEffect, useMemo, useRef, useState } from "react";
import { Link, useSearchParams } from "react-router";
import { api } from "../../convex/_generated/api";
import { colourHex, colourText, coloursFor, modelsFor, STORAGE_SIZES } from "@/shop/catalogue";
import { ShopFooter, ShopHeader } from "@/shop/Chrome";
import { CONDITION_LABEL, rands, SHOP_NAME, waLink } from "@/shop/config";
import { SearchBox } from "@/shop/SearchBox";
import { haystack, matches } from "@/shop/search";
import { cheapestInStock, type Phone, savePercent } from "@/shop/types";

const CATEGORIES = [
  { key: "Apple", label: "iPhone" },
  { key: "Samsung", label: "Samsung" },
  { key: "Accessory", label: "Accessories" },
  { key: "Other", label: "Other makes" },
] as const;

export function StorefrontPage() {
  const phones = useQuery(api.shop.listPhones) as Phone[] | undefined;
  const [params, setParams] = useSearchParams();

  const q = params.get("q") ?? "";
  const brand = params.get("brand") ?? "Apple";
  const condition = params.get("cond") ?? "certified_refurbished";
  const model = params.get("model") ?? "";
  const storage = params.get("storage") ?? "";
  const colour = params.get("colour") ?? "";

  /** One place to change the address bar, so nothing goes stale mid-click. */
  const setMany = (patch: Record<string, string>) => {
    const next = new URLSearchParams(params);
    for (const [key, value] of Object.entries(patch)) {
      if (value) next.set(key, value);
      else next.delete(key);
    }
    setParams(next, { replace: true });
  };
  const set = (key: string, value: string) => setMany({ [key]: value });
  const clearFilters = () => setMany({ model: "", storage: "", colour: "" });
  const pickCategory = (key: string) =>
    setMany({ q: "", brand: key, model: "", storage: "", colour: "" });

  const isAccessory = brand === "Accessory";
  const searching = q.trim().length > 0;

  // The search box sees the entire shop, whichever tab is open.
  const searched = useMemo(() => {
    if (!phones) return [];
    if (!searching) return phones;
    return phones.filter(p =>
      matches(
        q,
        haystack([
          p.brand,
          p.brand === "Apple" ? "iPhone" : undefined,
          p.model,
          p.colour,
          p.grade,
          CONDITION_LABEL[p.condition],
          p.variants.map(v => v.storage).join(" "),
        ]),
      ),
    );
  }, [phones, q, searching]);

  const inTab = useMemo(() => {
    if (searching) return searched;
    return searched.filter(p => {
      if (isAccessory) return p.brand === "Accessory";
      if (p.brand !== brand) return false;
      return p.condition === condition;
    });
  }, [searched, brand, condition, isAccessory, searching]);

  // Filter choices come from the full catalogue, not only from what is on the
  // shelf — refurbished stock is sourced to order.
  const stockedModels = useMemo(
    () => [...new Set(inTab.map(p => p.model))],
    [inTab],
  );
  const models = useMemo(() => {
    const catalogue = modelsFor(brand);
    const extra = stockedModels.filter(m => !catalogue.includes(m)).sort();
    return catalogue.length > 0 ? [...catalogue, ...extra] : extra;
  }, [brand, stockedModels]);

  const storages = useMemo(() => {
    const stocked = new Set(
      inTab.flatMap(p => p.variants.map(v => v.storage)).filter(Boolean),
    );
    const extra = [...stocked].filter(s => !STORAGE_SIZES.includes(s));
    return [...STORAGE_SIZES, ...extra];
  }, [inTab]);

  const colours = useMemo(() => {
    const catalogue = coloursFor(brand);
    const stocked = [...new Set(inTab.map(p => p.colour))].filter(Boolean);
    const extra = stocked.filter(c => !catalogue.includes(c)).sort();
    return [...catalogue, ...extra];
  }, [brand, inTab]);

  const results = useMemo(
    () =>
      inTab.filter(p => {
        if (model && p.model !== model) return false;
        if (colour && p.colour !== colour) return false;
        if (storage && !p.variants.some(v => v.storage === storage))
          return false;
        return true;
      }),
    [inTab, model, storage, colour],
  );

  const counts = useMemo(() => {
    const c: Record<string, number> = {};
    for (const cat of CATEGORIES) {
      c[cat.key] = (phones ?? []).filter(p => p.brand === cat.key).length;
    }
    return c;
  }, [phones]);

  /** How many cards sit in one row right now — the grid classes below in one place. */
  const columnsNow = () => {
    const w = typeof window === "undefined" ? 1440 : window.innerWidth;
    if (w >= 2100) return 6;
    if (w >= 1750) return 5;
    if (w >= 1280) return 4;
    if (w >= 1024) return 3;
    if (w >= 640) return 3;
    return 2;
  };
  const [columns, setColumns] = useState(columnsNow);
  useEffect(() => {
    const onResize = () => setColumns(columnsNow());
    onResize();
    window.addEventListener("resize", onResize);
    return () => window.removeEventListener("resize", onResize);
  }, []);

  /** Four rows of phones on a page, then the next page. */
  const perPage = columns * 4;
  const [page, setPage] = useState(1);
  const pageCount = Math.max(1, Math.ceil(results.length / perPage));
  useEffect(() => {
    setPage(1);
  }, [q, brand, condition, model, storage, colour]);
  useEffect(() => {
    if (page > pageCount) setPage(pageCount);
  }, [page, pageCount]);
  const pageResults = results.slice((page - 1) * perPage, page * perPage);

  const anyFilter = Boolean(model || storage || colour);
  const filterCount = [model, storage, colour].filter(Boolean).length;
  const [filtersOpen, setFiltersOpen] = useState(false);
  const accent = condition === "pre_owned" ? "#b45309" : "#1257d0";

  return (
    <div className="min-h-screen bg-[#f4f7fd]">
      <ShopHeader />

      <div className="relative overflow-hidden bg-gradient-to-b from-sky-50 via-[#f4f7fd] to-[#f4f7fd]">
        <div
          aria-hidden
          className="pointer-events-none absolute -right-24 -top-32 size-[26rem] rounded-full bg-gradient-to-br from-[#3b8ef5]/25 to-teal-300/10 blur-3xl"
        />
        <div
          aria-hidden
          className="pointer-events-none absolute -left-32 top-32 size-[22rem] rounded-full bg-gradient-to-tr from-amber-200/30 to-lime-200/10 blur-3xl"
        />

        <div className="relative mx-auto max-w-[1560px] px-3 pb-2 pt-5 sm:px-5 sm:pt-8">
          <h1 className="text-center text-[22px] font-black tracking-tight text-slate-900 sm:text-3xl">
            iPhones and Samsungs you can trust
          </h1>
          <p className="mx-auto mt-1.5 max-w-lg text-center text-[13px] text-slate-800/70 sm:text-[15px]">
            Certified refurbished in the box, and honest pre-owned. Cape Town.
            Free delivery in Cape Town.
          </p>

          <div className="mx-auto mt-4 max-w-2xl">
            <SearchBox value={q} onChange={v => set("q", v)} />
          </div>

          <div className="cc-rail -mx-3 mt-4 flex gap-2 overflow-x-auto px-3 pb-1 sm:mx-auto sm:max-w-3xl sm:justify-center sm:overflow-visible sm:px-0">
            {CATEGORIES.map(cat => {
              const active = !searching && brand === cat.key;
              return (
                <button
                  key={cat.key}
                  type="button"
                  onClick={() => pickCategory(cat.key)}
                  className={`shrink-0 rounded-full px-4 py-2.5 text-[13.5px] font-bold shadow-sm transition active:scale-[0.97] sm:px-6 sm:text-[15px] ${
                    active
                      ? "bg-[#1257d0] text-white shadow-sky-900/20"
                      : "bg-white text-slate-900 ring-1 ring-black/5 hover:ring-[#1257d0]/40"
                  }`}
                >
                  {cat.label}
                  <span
                    className={`ml-1.5 text-[10.5px] font-semibold ${
                      active ? "text-sky-100/80" : "text-neutral-400"
                    }`}
                  >
                    in stock {counts[cat.key] ?? 0}
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      <main className="mx-auto max-w-[1560px] px-3 pb-4 sm:px-5">
        {searching && (
          <div className="mt-4 flex flex-wrap items-center justify-between gap-2 rounded-2xl bg-white p-3 shadow-sm ring-1 ring-black/5">
            <p className="text-[13.5px] text-neutral-600">
              Showing everything in the shop matching{" "}
              <span className="font-bold text-neutral-900">“{q}”</span>
            </p>
            <button
              type="button"
              onClick={() => setMany({ q: "" })}
              className="rounded-full bg-neutral-900 px-4 py-1.5 text-[12.5px] font-bold text-white"
            >
              Clear search
            </button>
          </div>
        )}

        {!searching && !isAccessory && (
          <section className="mt-4">
            <div className="cc-rail flex justify-center gap-2 overflow-x-auto pb-0.5">
              {[
                {
                  key: "certified_refurbished",
                  label: "Certified refurbished",
                  colour: "#1257d0",
                },
                { key: "pre_owned", label: "Pre-owned", colour: "#b45309" },
              ].map(tab => {
                const active = condition === tab.key;
                return (
                  <button
                    key={tab.key}
                    type="button"
                    onClick={() =>
                      setMany({
                        cond: tab.key,
                        model: "",
                        storage: "",
                        colour: "",
                      })
                    }
                    style={
                      active
                        ? { backgroundColor: tab.colour, borderColor: tab.colour }
                        : { color: tab.colour, borderColor: `${tab.colour}66` }
                    }
                    className={`shrink-0 whitespace-nowrap rounded-full border-2 px-4 py-2 text-[13px] font-extrabold transition active:scale-[0.97] sm:text-[14px] ${
                      active ? "text-white shadow-md" : "bg-white"
                    }`}
                  >
                    {/* No number in here: it counted the listings on the
                        shelf, not the phones in stock, and that read wrong. */}
                    {tab.label}
                  </button>
                );
              })}
            </div>
            <p
              className="mt-2.5 px-1 text-center text-[12.5px] italic sm:text-sm"
              style={{ color: accent }}
            >
              {condition === "certified_refurbished"
                ? "In the box, sealed and fully tested. Every model is available to order — if it is not listed, we will source it. 6-month warranty."
                : "Real phones we have in hand, out of the box, honestly graded. What you see here is what we have right now. 2-month warranty."}
            </p>
          </section>
        )}

        {/* Filters sit on the side on a big screen, above the phones on a phone. */}
        <div className="mt-4 gap-5 lg:grid lg:grid-cols-[280px_minmax(0,1fr)] lg:items-start xl:gap-6 xl:grid-cols-[310px_minmax(0,1fr)]">
          <aside className="relative rounded-3xl bg-white p-3 shadow-sm ring-1 ring-black/5 sm:p-4 lg:sticky lg:top-28">
            {/* On a phone the filters stay folded so the stock is right there. */}
            <button
              type="button"
              onClick={() => setFiltersOpen(o => !o)}
              className={`flex w-full items-center justify-between gap-2 lg:hidden ${filtersOpen ? "pr-8" : ""}`}
            >
              <span className="text-[14px] font-black text-neutral-900">
                Filter{" "}
                <span className="font-semibold text-neutral-500">
                  model, storage, colour
                </span>
                {filterCount > 0 && (
                  <span className="ml-1.5 rounded-full bg-[#1257d0] px-2 py-0.5 text-[11px] font-black text-white">
                    {filterCount}
                  </span>
                )}
              </span>
              <span className="shrink-0 rounded-full bg-[#1257d0] px-3 py-1.5 text-[12px] font-bold text-white shadow-sm">
                {filtersOpen ? "Hide specs ▲" : "Show specs ▼"}
              </span>
            </button>

            {/* A plain way out of the card without picking anything. */}
            {filtersOpen && (
              <button
                type="button"
                onClick={() => setFiltersOpen(false)}
                aria-label="Close the specs card"
                className="absolute right-2 top-2 grid size-7 place-items-center rounded-full bg-neutral-100 text-[13px] font-black text-neutral-500 transition hover:bg-neutral-200 lg:hidden"
              >
                ✕
              </button>
            )}

            <div
              className={`${filtersOpen ? "mt-3 grid" : "hidden"} gap-4 sm:grid-cols-3 lg:mt-0 lg:grid lg:grid-cols-1`}
            >
              <div className="block">
                <span className="mb-1 block text-[11px] font-bold uppercase tracking-wide text-neutral-500">
                  Model
                </span>
                <ModelPicker
                  value={model}
                  models={models}
                  stocked={stockedModels}
                  onPick={v => set("model", v)}
                />
              </div>

              <div>
                <span className="mb-1 block text-[11px] font-bold uppercase tracking-wide text-neutral-500">
                  Storage
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {storages.map(s => (
                    <button
                      key={s}
                      type="button"
                      onClick={() => set("storage", storage === s ? "" : s)}
                      className={`rounded-full px-3 py-1.5 text-[12.5px] font-bold transition active:scale-95 ${
                        storage === s
                          ? "bg-[#1257d0] text-white"
                          : "bg-neutral-100 text-neutral-700 hover:bg-neutral-200"
                      }`}
                    >
                      {storage === s && "✓ "}
                      {s}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <span className="mb-1 block text-[11px] font-bold uppercase tracking-wide text-neutral-500">
                  Colour
                  {colour && (
                    <span
                      className="ml-1.5 normal-case"
                      style={{ color: colourText(colour) }}
                    >
                      {colour}
                    </span>
                  )}
                </span>
                <div className="flex max-h-36 flex-wrap gap-2 overflow-y-auto pr-1 lg:max-h-44">
                  {colours.map(c => (
                    <button
                      key={c}
                      type="button"
                      title={c}
                      aria-label={c}
                      onClick={() => set("colour", colour === c ? "" : c)}
                      className={`grid size-7 place-items-center rounded-full ring-2 transition active:scale-90 ${
                        colour === c
                          ? "ring-[#1257d0] ring-offset-2"
                          : "ring-black/10"
                      }`}
                      style={{ backgroundColor: colourHex(c) }}
                    >
                      {colour === c && (
                        <span className="text-[12px] font-black text-white drop-shadow">
                          ✓
                        </span>
                      )}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="mt-3 flex items-center justify-between border-t border-neutral-100 pt-2.5">
              <span className="text-[13px] font-black text-emerald-600">
                {results.length}{" "}
                {isAccessory
                  ? results.length === 1
                    ? "accessory"
                    : "accessories"
                  : results.length === 1
                    ? "major phone"
                    : "major phones"}
              </span>
              {anyFilter && (
                <button
                  type="button"
                  onClick={clearFilters}
                  className="text-[13px] font-bold text-[#1257d0] underline underline-offset-2"
                >
                  Clear filters
                </button>
              )}
            </div>
          </aside>

          <div>
            {phones === undefined ? (
              <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:mt-0 lg:grid-cols-3 xl:grid-cols-4 min-[1750px]:grid-cols-5 min-[2100px]:grid-cols-6">
                {[0, 1, 2, 3].map(i => (
                  <div
                    key={i}
                    className="h-64 animate-pulse rounded-3xl bg-white/70"
                  />
                ))}
              </div>
            ) : results.length === 0 ? (
              <EmptyState
                query={[model, storage, colour].filter(Boolean).join(" ") || q || "that phone"}
              />
            ) : (
              <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:mt-0 lg:grid-cols-3 xl:grid-cols-4 min-[1750px]:grid-cols-5 min-[2100px]:grid-cols-6">
                {pageResults.map(p => (
                  <PhoneCard key={p._id} phone={p} search={params.toString()} />
                ))}
              </div>
            )}

            {pageCount > 1 && (
              <Pager page={page} pageCount={pageCount} accent={accent} onGo={setPage} />
            )}
          </div>
        </div>
      </main>

      <ShopFooter />
    </div>
  );
}

/** Numbered pages under the grid — three rows of phones on each one. */
function Pager({
  page,
  pageCount,
  accent,
  onGo,
}: {
  page: number;
  pageCount: number;
  accent: string;
  onGo: (n: number) => void;
}) {
  const go = (n: number) => {
    onGo(n);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };
  const pages = Array.from({ length: pageCount }, (_, i) => i + 1);
  return (
    <div className="mt-6 flex flex-wrap items-center justify-center gap-2">
      <button
        type="button"
        onClick={() => go(Math.max(1, page - 1))}
        disabled={page === 1}
        className="rounded-full border border-slate-200 bg-white px-4 py-2 text-sm font-bold text-slate-700 disabled:opacity-40"
      >
        ← Back
      </button>
      {pages.map(n => (
        <button
          key={n}
          type="button"
          onClick={() => go(n)}
          className="h-10 min-w-10 rounded-full px-3 text-sm font-black transition"
          style={
            n === page
              ? { background: accent, color: "white" }
              : { background: "white", color: "#334155", border: "1px solid #e2e8f0" }
          }
        >
          {n}
        </button>
      ))}
      <button
        type="button"
        onClick={() => go(Math.min(pageCount, page + 1))}
        disabled={page === pageCount}
        className="rounded-full border border-slate-200 bg-white px-4 py-2 text-sm font-bold text-slate-700 disabled:opacity-40"
      >
        Next →
      </button>
    </div>
  );
}

/** "128GB", or "128GB +2 more" when the phone comes in several sizes. */
function storageLabel(phone: Phone): string {
  const sizes = [...new Set(phone.variants.map(v => v.storage).filter(Boolean))];
  if (sizes.length === 0) return "";
  if (sizes.length === 1) return sizes[0];
  return `${sizes[0]} +${sizes.length - 1} more`;
}

function PhoneCard({ phone, search }: { phone: Phone; search: string }) {
  const v = cheapestInStock(phone);
  const save = savePercent(v);
  const soldOut = phone.variants.every(variant => variant.inStock === 0);

  return (
    <Link
      to={`/phone/${phone._id}?from=${encodeURIComponent(search)}`}
      className="group flex flex-col overflow-hidden rounded-3xl bg-white shadow-sm ring-1 ring-black/5 transition hover:-translate-y-0.5 hover:shadow-lg"
    >
      <div className="relative aspect-[4/5] overflow-hidden bg-neutral-50">
        {phone.photoUrls[0] ? (
          <img
            src={phone.photoUrls[0]}
            alt={phone.model}
            loading="lazy"
            decoding="async"
            className="h-full w-full object-cover transition duration-300 group-hover:scale-[1.04]"
          />
        ) : (
          <div className="flex h-full w-full flex-col items-center justify-center gap-1.5 text-neutral-300">
            <svg viewBox="0 0 24 24" className="size-9" fill="currentColor" aria-hidden>
              <path d="M9 3 7.17 5H4a2 2 0 0 0-2 2v11a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2h-3.17L15 3H9zm3 5a5 5 0 1 1 0 10 5 5 0 0 1 0-10z" />
            </svg>
            <span className="text-[10.5px] font-semibold">Photo coming</span>
          </div>
        )}
        <span
          className="absolute left-2 top-2 rounded-full px-2 py-0.5 text-[10px] font-black uppercase tracking-wide text-white shadow-sm"
          style={{
            backgroundColor:
              phone.condition === "pre_owned" ? "#b45309" : "#1257d0",
          }}
        >
          {phone.condition === "pre_owned"
            ? (phone.grade ?? "Pre-owned")
            : "In box"}
        </span>
        {save && !soldOut && (
          <span className="absolute right-2 top-2 rounded-full bg-amber-400 px-2 py-0.5 text-[10px] font-black text-amber-950 shadow-sm">
            Save {save}%
          </span>
        )}
        {soldOut && (
          <span className="absolute right-2 top-2 rounded-full bg-neutral-900/80 px-2 py-0.5 text-[10px] font-black uppercase text-white">
            Sold
          </span>
        )}
      </div>

      <div className="flex flex-1 flex-col p-2.5 sm:p-3">
        <h3 className="text-[13.5px] font-bold leading-tight text-neutral-900 sm:text-[15px]">
          {phone.model}
        </h3>
        {/* Memory first, then the colour; the battery drops to its own line
            rather than crowding on top of the storage. */}
        <p className="mt-1 flex flex-wrap items-center gap-x-1.5 gap-y-0.5 text-[11.5px] font-semibold">
          {storageLabel(phone) && (
            <span className="font-black text-neutral-700">
              {storageLabel(phone)}
            </span>
          )}
          <span className="flex min-w-0 items-center gap-1.5">
            <span
              className="inline-block size-2.5 shrink-0 rounded-full ring-1 ring-black/10"
              style={{ backgroundColor: colourHex(phone.colour) }}
            />
            <span className="truncate" style={{ color: colourText(phone.colour) }}>
              {phone.colour}
            </span>
          </span>
          {phone.battery ? (
            <span className="w-full font-normal text-neutral-400">
              battery {phone.battery}%
            </span>
          ) : null}
        </p>
        <div className="mt-auto pt-2">
          {v ? (
            <div className="flex flex-wrap items-baseline gap-x-2">
              <p className="text-[16px] font-black text-neutral-900 sm:text-[18px]">
                {rands(v.price)}
              </p>
              {v.wasPrice && v.wasPrice > v.price && (
                <p className="text-[11.5px] text-neutral-400 line-through">
                  {rands(v.wasPrice)}
                </p>
              )}
            </div>
          ) : (
            <p className="text-[13px] font-semibold text-neutral-400">
              Ask us for a price
            </p>
          )}
        </div>
      </div>
    </Link>
  );
}

function EmptyState({ query }: { query: string }) {
  return (
    <div className="mt-4 rounded-3xl bg-gradient-to-br from-white to-sky-50 p-7 text-center shadow-sm ring-1 ring-black/5 lg:mt-0">
      <div className="mx-auto grid size-12 place-items-center rounded-2xl bg-[#1257d0] text-xl text-white">
        ?
      </div>
      <h3 className="mt-3 text-lg font-black text-slate-900">
        We don't have that one listed
      </h3>
      <p className="mx-auto mt-1.5 max-w-sm text-sm text-slate-800/70">
        That does not mean we can't get it. Send us a message and we will usually
        source it within a few days.
      </p>
      <a
        href={waLink(`Hi ${SHOP_NAME}, do you have a ${query}?`)}
        target="_blank"
        rel="noreferrer"
        className="mt-4 inline-flex items-center gap-2 rounded-full bg-[#25d366] px-6 py-3 text-sm font-bold text-white shadow-lg transition hover:bg-[#1eb85a] active:scale-95"
      >
        Ask us to source it
      </a>
    </div>
  );
}


/** A small dropdown that opens over the card, not over the whole phone. */
function ModelPicker({
  value,
  models,
  stocked,
  onPick,
}: {
  value: string;
  models: string[];
  stocked: string[];
  onPick: (v: string) => void;
}) {
  const [open, setOpen] = useState(false);
  const box = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (!open) return;
    const away = (e: MouseEvent | TouchEvent) => {
      if (!box.current?.contains(e.target as Node)) setOpen(false);
    };
    const key = (e: KeyboardEvent) => {
      if (e.key === "Escape") setOpen(false);
    };
    document.addEventListener("mousedown", away);
    document.addEventListener("touchstart", away);
    document.addEventListener("keydown", key);
    return () => {
      document.removeEventListener("mousedown", away);
      document.removeEventListener("touchstart", away);
      document.removeEventListener("keydown", key);
    };
  }, [open]);

  const choose = (v: string) => {
    onPick(v);
    setOpen(false);
  };

  return (
    <div ref={box} className="relative">
      <button
        type="button"
        onClick={() => setOpen(o => !o)}
        className={`flex w-full items-center justify-between gap-2 rounded-xl border bg-neutral-50 px-3 py-2.5 text-left text-sm font-semibold transition ${
          open ? "border-[#1257d0] bg-white" : "border-neutral-200"
        }`}
      >
        <span className={value ? "text-neutral-900" : "text-neutral-500"}>
          {value || "All models"}
        </span>
        <span className="text-[11px] text-[#1257d0]">{open ? "▲" : "▼"}</span>
      </button>

      {open && (
        <div className="absolute left-0 right-0 top-[calc(100%+4px)] z-30 max-h-60 overflow-y-auto rounded-xl border border-neutral-200 bg-white p-1 shadow-xl">
          <button
            type="button"
            onClick={() => choose("")}
            className={`block w-full rounded-lg px-3 py-2 text-left text-[13px] font-bold ${
              value ? "text-neutral-700 hover:bg-neutral-100" : "bg-[#1257d0] text-white"
            }`}
          >
            All models
          </button>
          {models.map(m => (
            <button
              key={m}
              type="button"
              onClick={() => choose(m)}
              className={`flex w-full items-center justify-between gap-2 rounded-lg px-3 py-2 text-left text-[13px] font-semibold ${
                value === m
                  ? "bg-[#1257d0] text-white"
                  : "text-neutral-800 hover:bg-neutral-100"
              }`}
            >
              <span>{m}</span>
              {stocked.includes(m) && (
                <span
                  className={`text-[11px] font-black ${value === m ? "text-white" : "text-emerald-600"}`}
                >
                  in stock
                </span>
              )}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
