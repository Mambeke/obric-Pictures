import { authTables } from "@convex-dev/auth/server";
import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";

const schema = defineSchema({
  ...authTables,

  // One garment / bag / pair of shoes on the rail.
  pieces: defineTable({
    name: v.string(),
    brand: v.string(),
    price: v.number(),
    wasPrice: v.optional(v.number()),
    section: v.string(), // "Ladies" | "Men" | "Kids"
    category: v.string(), // "Dresses" | "Tops" | ... (owner can add more)
    state: v.string(), // "New" | "Pre-owned"
    size: v.string(),
    cond: v.string(), // condition wording, e.g. "Excellent — worn twice"
    meas: v.optional(v.string()),
    desc: v.optional(v.string()),
    badge: v.optional(v.string()), // "NEW IN" | "SALE" | "BEST SELLER" | ""
    photos: v.array(v.string()), // storage id, /img/... static path, or http URL
    sold: v.optional(v.boolean()),
    demo: v.optional(v.boolean()),
    createdAt: v.number(),
  })
    .index("by_section", ["section"])
    .index("by_sold", ["sold"]),

  // Owner-defined category tabs (Hair, Nails, Wigs ...) per section.
  categories: defineTable({
    section: v.string(),
    name: v.string(),
    order: v.number(),
  }).index("by_section", ["section"]),

  // Single row of shop-wide settings the owner can edit.
  settings: defineTable({
    shopName: v.string(),
    whatsapp: v.string(), // digits only, e.g. 27685302223
    footerLine: v.string(),
    ribbon: v.array(v.string()),
    deliveryTowns: v.array(v.object({ town: v.string(), fee: v.number(), days: v.number() })),
    laybyeEnabled: v.boolean(),
    laybyeMinPrice: v.number(),
    laybyeMonths: v.number(),
  }),
});

export default schema;
