import { useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";

/**
 * Product photo viewer.
 * - main photo fills the full width of its column
 * - arrows + thumbnails when there is more than one photo
 * - tap/click the photo to open the zoom viewer: pinch with two fingers on a
 *   phone, 100/120/160/180% buttons (and the wheel) on a laptop, drag to pan
 */
export function Gallery({ photos, alt }: { photos: string[]; alt: string }) {
  const list = photos.length ? photos : [""];
  const [i, setI] = useState(0);
  const [zoom, setZoom] = useState(false);
  const idx = Math.min(i, list.length - 1);

  const go = (d: number) => setI(p => (p + d + list.length) % list.length);

  return (
    <>
      <div className="pimg">
        <button type="button" className="pimgtap" onClick={() => setZoom(true)}>
          <img src={list[idx]} alt={alt} />
          <span className="zoomhint">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2.2} strokeLinecap="round" aria-hidden>
              <circle cx="11" cy="11" r="7" />
              <path d="m20 20-3.2-3.2M11 8.4v5.2M8.4 11h5.2" />
            </svg>
            Tap to zoom
          </span>
        </button>
        {list.length > 1 && (
          <>
            <button type="button" className="parrow l" onClick={() => go(-1)} aria-label="Previous photo">
              ‹
            </button>
            <button type="button" className="parrow r" onClick={() => go(1)} aria-label="Next photo">
              ›
            </button>
            <span className="pcount">
              {idx + 1} / {list.length}
            </span>
          </>
        )}
      </div>

      {list.length > 1 && (
        <div className="thumbs">
          {list.map((u, n) => (
            <button
              key={u || n}
              type="button"
              className={`thumb${n === idx ? " on" : ""}`}
              onClick={() => setI(n)}
            >
              <img src={u} alt={`${alt} photo ${n + 1}`} />
            </button>
          ))}
        </div>
      )}

      {zoom &&
        createPortal(
          <Lightbox
            photos={list}
            alt={alt}
            start={idx}
            onClose={() => setZoom(false)}
            onIndex={setI}
          />,
          document.body,
        )}
    </>
  );
}

function Lightbox({
  photos,
  alt,
  start,
  onClose,
  onIndex,
}: {
  photos: string[];
  alt: string;
  start: number;
  onClose: () => void;
  onIndex: (n: number) => void;
}) {
  const [i, setI] = useState(start);
  // one piece of state so scale and position always move together — that is
  // what keeps a pinch steady instead of jumping around the screen
  const [view, setView] = useState({ s: 1, x: 0, y: 0 });
  const stage = useRef<HTMLDivElement>(null);
  const img = useRef<HTMLImageElement>(null);
  const drag = useRef<{ x: number; y: number; px: number; py: number } | null>(null);
  const pinch = useRef<{ d: number; s: number; x: number; y: number; px: number; py: number } | null>(null);

  /** keep the photo inside the frame: it can never fly off into a corner */
  const clamp = (s: number, x: number, y: number) => {
    const el = img.current;
    const st = stage.current;
    if (!el || !st) return { s, x, y };
    const w = el.clientWidth;
    const h = el.clientHeight;
    const mx = Math.max(0, (w * s - st.clientWidth) / 2);
    const my = Math.max(0, (h * s - st.clientHeight) / 2);
    return {
      s,
      x: Math.min(mx, Math.max(-mx, x)),
      y: Math.min(my, Math.max(-my, y)),
    };
  };

  /** zoom towards a point on screen so the photo grows where the fingers are */
  const zoomAt = (next: number, cx: number, cy: number) => {
    setView(v => {
      const s = Math.min(4, Math.max(1, next));
      if (s === 1) return { s: 1, x: 0, y: 0 };
      const st = stage.current;
      if (!st) return clamp(s, v.x, v.y);
      const r = st.getBoundingClientRect();
      const ox = cx - r.left - r.width / 2;
      const oy = cy - r.top - r.height / 2;
      const k = s / v.s;
      return clamp(s, ox - (ox - v.x) * k, oy - (oy - v.y) * k);
    });
  };

  const setLevel = (s: number) => {
    const st = stage.current;
    if (!st) return setView({ s, x: 0, y: 0 });
    const r = st.getBoundingClientRect();
    zoomAt(s, r.left + r.width / 2, r.top + r.height / 2);
  };

  const go = (d: number) => {
    setI(p => {
      const n = (p + d + photos.length) % photos.length;
      onIndex(n);
      return n;
    });
    setView({ s: 1, x: 0, y: 0 });
  };

  useEffect(() => {
    const key = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
      if (e.key === "ArrowRight") go(1);
      if (e.key === "ArrowLeft") go(-1);
    };
    document.addEventListener("keydown", key);
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", key);
      document.body.style.overflow = "";
    };
  });

  // the wheel must zoom on its own — nobody holds Ctrl or Shift to zoom a dress
  useEffect(() => {
    const st = stage.current;
    if (!st) return;
    const wheel = (e: WheelEvent) => {
      e.preventDefault();
      const step = Math.exp(-e.deltaY / 400);
      zoomAt(view.s * step, e.clientX, e.clientY);
    };
    st.addEventListener("wheel", wheel, { passive: false });
    return () => st.removeEventListener("wheel", wheel);
  }, [view.s]);

  const dist = (t: React.TouchList) =>
    Math.hypot(t[0].clientX - t[1].clientX, t[0].clientY - t[1].clientY);
  const mid = (t: React.TouchList) => ({
    x: (t[0].clientX + t[1].clientX) / 2,
    y: (t[0].clientY + t[1].clientY) / 2,
  });

  return (
    <div className="lbox" role="dialog" aria-label="Photo viewer">
      <div className="lbar">
        <span className="lc">
          {i + 1} / {photos.length}
        </span>
        <div className="lzoom desktoponly">
          {[1, 1.2, 1.6, 1.8].map(s => (
            <button
              key={s}
              type="button"
              className={Math.abs(view.s - s) < 0.02 ? "on" : ""}
              onClick={() => setLevel(s)}
            >
              {Math.round(s * 100)}%
            </button>
          ))}
        </div>
        <span className="lhint mobileonly">Pinch with two fingers to zoom</span>
        <button type="button" className="lclose" onClick={onClose}>
          ← Back
        </button>
      </div>

      <div
        className="lstage"
        ref={stage}
        onDoubleClick={e => zoomAt(view.s > 1 ? 1 : 2, e.clientX, e.clientY)}
        onPointerDown={e => {
          if (view.s <= 1 || e.pointerType === "touch") return;
          drag.current = { x: e.clientX, y: e.clientY, px: view.x, py: view.y };
          (e.currentTarget as HTMLElement).setPointerCapture?.(e.pointerId);
        }}
        onPointerMove={e => {
          const d = drag.current;
          if (!d) return;
          setView(v => clamp(v.s, d.px + (e.clientX - d.x), d.py + (e.clientY - d.y)));
        }}
        onPointerUp={() => {
          drag.current = null;
        }}
        onTouchStart={e => {
          if (e.touches.length === 2) {
            const m = mid(e.touches);
            pinch.current = { d: dist(e.touches), s: view.s, x: m.x, y: m.y, px: view.x, py: view.y };
          } else if (e.touches.length === 1 && view.s > 1) {
            drag.current = {
              x: e.touches[0].clientX,
              y: e.touches[0].clientY,
              px: view.x,
              py: view.y,
            };
          }
        }}
        onTouchMove={e => {
          const p = pinch.current;
          if (e.touches.length === 2 && p) {
            e.preventDefault();
            const m = mid(e.touches);
            const s = Math.min(4, Math.max(1, p.s * (dist(e.touches) / p.d)));
            const st = stage.current;
            if (!st) return;
            const r = st.getBoundingClientRect();
            const ox = p.x - r.left - r.width / 2;
            const oy = p.y - r.top - r.height / 2;
            const k = s / p.s;
            // follow the fingers as they move, and grow from where they started
            setView(
              clamp(
                s,
                ox - (ox - p.px) * k + (m.x - p.x),
                oy - (oy - p.py) * k + (m.y - p.y),
              ),
            );
            return;
          }
          const d = drag.current;
          if (e.touches.length === 1 && d) {
            e.preventDefault();
            setView(v =>
              clamp(v.s, d.px + (e.touches[0].clientX - d.x), d.py + (e.touches[0].clientY - d.y)),
            );
          }
        }}
        onTouchEnd={e => {
          if (e.touches.length < 2) pinch.current = null;
          if (e.touches.length === 0) drag.current = null;
        }}
      >
        <img
          ref={img}
          src={photos[i]}
          alt={alt}
          draggable={false}
          style={{
            transform: `translate3d(${view.x}px, ${view.y}px, 0) scale(${view.s})`,
            cursor: view.s > 1 ? "grab" : "zoom-in",
          }}
          onClick={e => {
            if (view.s === 1) zoomAt(2, e.clientX, e.clientY);
          }}
        />
        {photos.length > 1 && (
          <>
            <button type="button" className="larrow l" onClick={() => go(-1)} aria-label="Previous">
              ‹
            </button>
            <button type="button" className="larrow r" onClick={() => go(1)} aria-label="Next">
              ›
            </button>
          </>
        )}
      </div>

      {photos.length > 1 && (
        <div className="lthumbs">
          {photos.map((u, n) => (
            <button
              key={u || n}
              type="button"
              className={`thumb${n === i ? " on" : ""}`}
              onClick={() => {
                setI(n);
                onIndex(n);
                setView({ s: 1, x: 0, y: 0 });
              }}
            >
              <img src={u} alt={`${alt} photo ${n + 1}`} />
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
