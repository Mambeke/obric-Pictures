export const SHOP_NAME = "Cell Connecta";

// One place for the number. Change it here and every button follows.
export const PHONE_DISPLAY = "068 530 2223";
export const PHONE_DIAL = "+27685302223";
export const WHATSAPP_NUMBER = "27685302223";

export const TRADING_HOURS = "Always open — online shop";

export const TICKER_ITEMS = [
  "No VAT — the price you see is the price you pay",
  "Free delivery in Cape Town",
  "6-month warranty on certified refurbished",
  "2-month warranty on pre-owned",
  "3-day returns",
  "Trade in your old phone",
];

export const PROMISES = [
  { title: "No VAT", body: "The price you see is the price you pay." },
  { title: "Free delivery", body: "Anywhere in Cape Town, on us." },
  {
    title: "6-month warranty",
    body: "On every certified refurbished phone. 2 months on pre-owned.",
  },
  { title: "3-day returns", body: "Not right for you? Send it back." },
  {
    title: "We can source it",
    body: "Can't see the phone you want? Ask — we'll find it.",
  },
];

export function waLink(message: string) {
  return `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
}

export function rands(amount: number) {
  return `R${amount.toLocaleString("en-ZA")}`;
}

export const CONDITION_LABEL: Record<string, string> = {
  certified_refurbished: "Certified refurbished",
  pre_owned: "Pre-owned",
  accessory: "Accessory",
};
