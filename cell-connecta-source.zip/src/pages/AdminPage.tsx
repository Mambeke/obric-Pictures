import { useAuthActions } from "@convex-dev/auth/react";
import { useMutation, useQuery } from "convex/react";
import { useState } from "react";
import { Link } from "react-router";
import { api } from "../../convex/_generated/api";
import type { Id } from "../../convex/_generated/dataModel";
import {
  colourHex,
  colourText,
  coloursFor,
  modelsFor,
  STORAGE_SIZES,
} from "@/shop/catalogue";
import { CONDITION_LABEL, rands } from "@/shop/config";
import { haystack, matches } from "@/shop/search";
import type { Phone, Variant } from "@/shop/types";

type Draft = {
  id?: string;
  brand: string;
  model: string;
  condition: string;
  colour: string;
  description: string;
  grade: string;
  battery: string;
  photos: string[];
  photoUrls: string[];
  variants: Variant[];
};

const emptyDraft = (brand: string): Draft => ({
  brand,
  model: "",
  condition: brand === "Accessory" ? "accessory" : "certified_refurbished",
  colour: "",
  description: "",
  grade: "",
  battery: "",
  photos: [],
  photoUrls: [],
  variants: [{ storage: "128GB", price: 0, wasPrice: undefined, inStock: 1 }],
});

const GROUPS = [
  { key: "Apple", label: "iPhones" },
  { key: "Samsung", label: "Samsungs" },
  { key: "Accessory", label: "Accessories" },
  { key: "Other", label: "Other makes" },
] as const;

const isSold = (p: Phone) => p.variants.every(v => v.inStock === 0);

export function AdminPage() {
  const me = useQuery(api.shop.amIOwner);
  const phones = useQuery(api.shop.listPhones) as Phone[] | undefined;
  const savePhone = useMutation(api.shop.savePhone);
  const deletePhone = useMutation(api.shop.deletePhone);
  const setSold = useMutation(api.shop.setSold);
  const clearDemo = useMutation(api.shop.clearDemoStock);
  const generateUploadUrl = useMutation(api.shop.generateUploadUrl);
  const { signOut } = useAuthActions();

  const [draft, setDraft] = useState<Draft | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [group, setGroup] = useState<string>("Apple");
  const [shelf, setShelf] = useState<"available" | "sold">("available");
  const [kind, setKind] = useState<"all" | "certified_refurbished" | "pre_owned">("all");
  const [find, setFind] = useState("");
  const [dropping, setDropping] = useState(false);

  if (me === undefined) {
    return <div className="p-10 text-center text-neutral-500">Loading…</div>;
  }

  if (!me.isOwner) {
    return (
      <div className="mx-auto max-w-md p-10 text-center">
        <h1 className="text-xl font-black">This account can't manage stock</h1>
        <p className="mt-2 text-sm text-neutral-600">
          You are signed in as {me.email ?? "an unknown account"}. Only the shop
          owner's account can open the stock manager.
        </p>
        <button
          type="button"
          onClick={() => void signOut()}
          className="mt-5 rounded-full bg-neutral-900 px-5 py-2.5 text-sm font-bold text-white"
        >
          Sign out
        </button>
      </div>
    );
  }

  const update = (patch: Partial<Draft>) =>
    setDraft(d => (d ? { ...d, ...patch } : d));

  const uploadPhotos = async (files: FileList) => {
    if (!draft) return;
    setBusy(true);
    setError("");
    try {
      const ids: string[] = [];
      const urls: string[] = [];
      for (const file of Array.from(files)) {
        // A photo straight off a phone camera is 4-8 MB. Shrinking it here
        // keeps the shop quick to load on a customer's data bundle.
        const small = await shrink(file);
        const url = await generateUploadUrl({});
        const res = await fetch(url, {
          method: "POST",
          headers: { "Content-Type": small.type },
          body: small,
        });
        const json = (await res.json()) as { storageId: string };
        ids.push(json.storageId);
        urls.push(URL.createObjectURL(small));
      }
      setDraft(d =>
        d
          ? {
              ...d,
              photos: [...d.photos, ...ids],
              photoUrls: [...d.photoUrls, ...urls],
            }
          : d,
      );
    } catch (e) {
      setError(e instanceof Error ? e.message : "Upload failed");
    } finally {
      setBusy(false);
    }
  };

  const movePhoto = (from: number, to: number) =>
    setDraft(d => {
      if (!d || to < 0 || to >= d.photos.length || from === to) return d;
      const photos = [...d.photos];
      const urls = [...d.photoUrls];
      const [pid] = photos.splice(from, 1);
      const [url] = urls.splice(from, 1);
      photos.splice(to, 0, pid);
      urls.splice(to, 0, url);
      return { ...d, photos, photoUrls: urls };
    });

  const removePhoto = (i: number) =>
    setDraft(d =>
      d
        ? {
            ...d,
            photos: d.photos.filter((_, j) => j !== i),
            photoUrls: d.photoUrls.filter((_, j) => j !== i),
          }
        : d,
    );

  const save = async () => {
    if (!draft) return;
    if (!draft.model.trim()) {
      setError("Give the phone a model name, e.g. iPhone 13 Pro");
      return;
    }
    setBusy(true);
    setError("");
    try {
      await savePhone({
        id: draft.id ? (draft.id as Id<"phones">) : undefined,
        brand: draft.brand,
        model: draft.model.trim(),
        condition: draft.condition,
        colour: draft.colour.trim(),
        description: draft.description.trim() || undefined,
        grade: draft.grade || undefined,
        battery: draft.battery ? Number(draft.battery) : undefined,
        photos: draft.photos,
        variants: draft.variants.map(v => ({
          storage: v.storage.trim(),
          price: Number(v.price) || 0,
          wasPrice: v.wasPrice ? Number(v.wasPrice) : undefined,
          inStock: Number(v.inStock) || 0,
        })),
      });
      setGroup(draft.brand);
      setDraft(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Could not save");
    } finally {
      setBusy(false);
    }
  };

  const editDraft = (p: Phone): Draft => ({
    id: p._id,
    brand: p.brand,
    model: p.model,
    condition: p.condition,
    colour: p.colour,
    description: p.description ?? "",
    grade: p.grade ?? "",
    battery: p.battery ? String(p.battery) : "",
    photos: p.photos,
    photoUrls: p.photoUrls,
    variants: p.variants,
  });

  const inGroup = (phones ?? []).filter(p => p.brand === group);
  const onShelf = inGroup.filter(p =>
    shelf === "sold" ? isSold(p) : !isSold(p),
  );
  const byKind =
    kind === "all" ? onShelf : onShelf.filter(p => p.condition === kind);
  const shown = find.trim()
    ? byKind.filter(p =>
        matches(
          find,
          haystack([
            p.brand,
            p.brand === "Apple" ? "iPhone" : undefined,
            p.model,
            p.colour,
            p.grade,
            CONDITION_LABEL[p.condition],
            p.variants.map(v => v.storage).join(" "),
          ]),
        ),
      )
    : byKind;
  const soldCount = inGroup.filter(isSold).length;
  const kindCount = (k: string) =>
    onShelf.filter(p => p.condition === k).length;
  const modelList = modelsFor(draft?.brand ?? "Apple");
  const colourList = coloursFor(draft?.brand ?? "Apple");

  return (
    <div className="min-h-screen bg-neutral-50">
      <header className="sticky top-0 z-30 flex items-center gap-3 bg-[#1257d0] px-4 py-3 text-white">
        <Link to="/" className="font-black">
          Cell Connecta · stock
        </Link>
        <Link
          to="/"
          className="ml-auto rounded-full bg-white/15 px-3 py-1.5 text-[13px] font-semibold"
        >
          View shop
        </Link>
        <button
          type="button"
          onClick={() => void signOut()}
          className="rounded-full bg-white/15 px-3 py-1.5 text-[13px] font-semibold"
        >
          Sign out
        </button>
      </header>

      <main className="mx-auto max-w-4xl p-4">
        {error && (
          <p className="mb-3 rounded-xl bg-red-50 p-3 text-sm font-semibold text-red-700">
            {error}
          </p>
        )}

        {draft ? (
          <div className="rounded-3xl bg-white p-4 shadow-sm ring-1 ring-black/5">
            <h2 className="text-lg font-black">
              {draft.id ? "Edit phone" : "Add a phone"}
            </h2>

            <div className="mt-4 grid gap-3 sm:grid-cols-2">
              <Field label="Make">
                <select
                  value={draft.brand}
                  onChange={e => update({ brand: e.target.value })}
                  className={inputClass}
                >
                  <option value="Apple">Apple</option>
                  <option value="Samsung">Samsung</option>
                  <option value="Other">Other make</option>
                  <option value="Accessory">Accessory</option>
                </select>
              </Field>

              <Field label="Condition">
                <select
                  value={draft.condition}
                  onChange={e => update({ condition: e.target.value })}
                  className={inputClass}
                >
                  <option value="certified_refurbished">
                    Certified refurbished (in box)
                  </option>
                  <option value="pre_owned">Pre-owned</option>
                  <option value="accessory">Accessory</option>
                </select>
              </Field>

              <Field label="Model">
                <Suggest
                  value={draft.model}
                  options={modelList}
                  placeholder="iPhone 13 Pro"
                  onPick={v => update({ model: v })}
                />
              </Field>

              <Field label="Colour">
                <Suggest
                  value={draft.colour}
                  options={colourList}
                  placeholder="Sierra Blue"
                  swatch
                  onPick={v => update({ colour: v })}
                />
                {draft.colour && (
                  <span className="mt-1 flex items-center gap-1.5 text-[12px] font-semibold">
                    <span
                      className="inline-block size-3 rounded-full ring-1 ring-black/10"
                      style={{ backgroundColor: colourHex(draft.colour) }}
                    />
                    <span style={{ color: colourText(draft.colour) }}>
                      shows as {draft.colour}
                    </span>
                  </span>
                )}
              </Field>

              {draft.condition === "pre_owned" && (
                <>
                  <Field label="Cosmetic grade">
                    <select
                      value={draft.grade}
                      onChange={e => update({ grade: e.target.value })}
                      className={inputClass}
                    >
                      <option value="">Not set</option>
                      <option value="Excellent">Excellent</option>
                      <option value="Good">Good</option>
                      <option value="Fair">Fair</option>
                    </select>
                  </Field>
                  <Field label="Battery health %">
                    <input
                      value={draft.battery}
                      inputMode="numeric"
                      placeholder="89"
                      onChange={e => update({ battery: e.target.value })}
                      className={inputClass}
                    />
                  </Field>
                </>
              )}
            </div>

            <Field label="Description">
              <textarea
                value={draft.description}
                rows={3}
                placeholder="Clean unit, no scratches, comes with cable and case."
                onChange={e => update({ description: e.target.value })}
                className={`${inputClass} resize-y`}
              />
            </Field>

            <div className="mt-4">
              <p className="mb-2 text-[11px] font-bold uppercase tracking-wide text-neutral-500">
                Photos — the first one is the cover
              </p>
              <p className="mb-2 text-[12px] text-neutral-500">
                Drag a photo to move it, or use ‹ › — “Make cover” puts it
                first. Pick several files at once when you add.
              </p>
              <div className="flex flex-wrap gap-2">
                {draft.photos.map((pid, i) => (
                  <div
                    key={pid}
                    draggable
                    onDragStart={e => e.dataTransfer.setData("text/plain", String(i))}
                    onDragOver={e => e.preventDefault()}
                    onDrop={e => {
                      e.preventDefault();
                      movePhoto(Number(e.dataTransfer.getData("text/plain")), i);
                    }}
                    className="relative size-24 cursor-grab overflow-hidden rounded-xl bg-neutral-100 ring-1 ring-black/5 active:cursor-grabbing"
                  >
                    {draft.photoUrls[i] ? (
                      <img
                        src={draft.photoUrls[i]}
                        alt={`Photo ${i + 1}`}
                        className="h-full w-full object-cover"
                      />
                    ) : (
                      <span className="grid h-full place-items-center text-[10px] font-bold text-neutral-400">
                        Photo {i + 1}
                      </span>
                    )}
                    {i === 0 ? (
                      <span className="absolute bottom-1 left-1 rounded bg-[#1257d0] px-1.5 py-0.5 text-[9px] font-black uppercase text-white">
                        Cover
                      </span>
                    ) : (
                      <button
                        type="button"
                        onClick={() => movePhoto(i, 0)}
                        className="absolute bottom-1 left-1 rounded bg-black/60 px-1.5 py-0.5 text-[9px] font-black uppercase text-white"
                      >
                        Make cover
                      </button>
                    )}
                    <div className="absolute bottom-1 right-1 flex gap-1">
                      <button
                        type="button"
                        aria-label="Move photo left"
                        onClick={() => movePhoto(i, i - 1)}
                        className="grid size-5 place-items-center rounded bg-white/90 text-[11px] font-black text-neutral-700 shadow"
                      >
                        ‹
                      </button>
                      <button
                        type="button"
                        aria-label="Move photo right"
                        onClick={() => movePhoto(i, i + 1)}
                        className="grid size-5 place-items-center rounded bg-white/90 text-[11px] font-black text-neutral-700 shadow"
                      >
                        ›
                      </button>
                    </div>
                    <button
                      type="button"
                      aria-label={`Remove photo ${i + 1}`}
                      onClick={() => removePhoto(i)}
                      className="absolute right-1 top-1 grid size-6 place-items-center rounded-full bg-white/90 text-[13px] font-black text-red-600 shadow"
                    >
                      ×
                    </button>
                  </div>
                ))}
              </div>

              <label
                onDragOver={e => {
                  e.preventDefault();
                  setDropping(true);
                }}
                onDragLeave={() => setDropping(false)}
                onDrop={e => {
                  e.preventDefault();
                  setDropping(false);
                  if (e.dataTransfer.files?.length)
                    void uploadPhotos(e.dataTransfer.files);
                }}
                className={`mt-2 flex w-full cursor-pointer items-center justify-center gap-2 rounded-2xl border-2 border-dashed px-5 py-4 text-center text-[13.5px] font-bold transition ${
                  dropping
                    ? "border-[#1257d0] bg-sky-100 text-[#0b3f9e]"
                    : "border-[#1257d0]/40 bg-sky-50/60 text-[#1257d0] hover:bg-sky-50"
                }`}
              >
                <svg viewBox="0 0 24 24" className="size-5 shrink-0" fill="none" stroke="currentColor" strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round" aria-hidden>
                  <path d="M12 16V4m0 0L7.5 8.5M12 4l4.5 4.5" />
                  <path d="M4 16v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2" />
                </svg>
                {busy
                  ? "Uploading…"
                  : dropping
                    ? "Drop the photos here"
                    : "Add photos — drag and drop them here, or tap to pick several"}
                <input
                  type="file"
                  accept="image/*"
                  multiple
                  className="hidden"
                  onChange={e => {
                    if (e.target.files?.length)
                      void uploadPhotos(e.target.files);
                    e.target.value = "";
                  }}
                />
              </label>
            </div>

            <div className="mt-5">
              <p className="mb-1 text-[11px] font-bold uppercase tracking-wide text-neutral-500">
                Storage and price
              </p>
              <p className="mb-2 text-[12px] text-neutral-500">
                One row per storage size. “Was” is the crossed-out price, “Price
                now” is what the customer pays, “In stock” is how many you have
                (0 means sold out).
              </p>
              <div className="space-y-3">
                {draft.variants.map((v, i) => (
                  <div
                    key={`v${i}`}
                    className="grid grid-cols-2 gap-2 rounded-2xl bg-neutral-50 p-2.5 sm:grid-cols-5"
                  >
                    <SmallField label="Storage">
                      <select
                        value={v.storage}
                        onChange={e => {
                          const next = [...draft.variants];
                          next[i] = { ...v, storage: e.target.value };
                          update({ variants: next });
                        }}
                        className={inputClass}
                      >
                        <option value="">Pick a size…</option>
                        {(STORAGE_SIZES as unknown as string[]).map(size => (
                          <option key={size} value={size}>
                            {size}
                          </option>
                        ))}
                        {v.storage &&
                          !(STORAGE_SIZES as unknown as string[]).includes(
                            v.storage,
                          ) && <option value={v.storage}>{v.storage}</option>}
                      </select>
                    </SmallField>
                    <SmallField label="Was (R)">
                      <input
                        value={v.wasPrice ?? ""}
                        type="number"
                        min={0}
                        step={100}
                        inputMode="numeric"
                        placeholder=""
                        onChange={e => {
                          const next = [...draft.variants];
                          next[i] = {
                            ...v,
                            wasPrice: Number(e.target.value) || undefined,
                          };
                          update({ variants: next });
                        }}
                        className={inputClass}
                      />
                    </SmallField>
                    <SmallField label="Price now (R)">
                      <input
                        value={v.price === 0 ? "" : v.price}
                        type="number"
                        min={0}
                        step={100}
                        inputMode="numeric"
                        placeholder=""
                        onChange={e => {
                          const next = [...draft.variants];
                          next[i] = { ...v, price: Number(e.target.value) || 0 };
                          update({ variants: next });
                        }}
                        className={inputClass}
                      />
                    </SmallField>
                    <SmallField label="In stock (how many)">
                      <input
                        value={v.inStock === 0 ? "" : v.inStock}
                        type="number"
                        min={0}
                        step={1}
                        inputMode="numeric"
                        placeholder=""
                        onChange={e => {
                          const next = [...draft.variants];
                          next[i] = {
                            ...v,
                            inStock: Number(e.target.value) || 0,
                          };
                          update({ variants: next });
                        }}
                        className={inputClass}
                      />
                    </SmallField>
                    <div className="flex items-end">
                      <button
                        type="button"
                        onClick={() =>
                          update({
                            variants: draft.variants.filter((_, j) => j !== i),
                          })
                        }
                        className="w-full rounded-xl bg-white px-3 py-2.5 text-[13px] font-bold text-red-600 ring-1 ring-red-200"
                      >
                        Remove
                      </button>
                    </div>
                  </div>
                ))}
              </div>
              <button
                type="button"
                onClick={() =>
                  update({
                    variants: [
                      ...draft.variants,
                      { storage: "", price: 0, inStock: 1 },
                    ],
                  })
                }
                className="mt-2 rounded-full bg-neutral-900 px-4 py-2 text-[13px] font-bold text-white"
              >
                + Add storage size
              </button>
            </div>

            <div className="mt-6 flex gap-2">
              <button
                type="button"
                disabled={busy}
                onClick={() => void save()}
                className="flex-1 rounded-2xl bg-[#1257d0] py-3.5 text-sm font-bold text-white disabled:opacity-50"
              >
                {busy
                  ? "Working…"
                  : draft.id
                    ? "Save changes"
                    : "Publish phone"}
              </button>
              <button
                type="button"
                onClick={() => setDraft(null)}
                className="rounded-2xl border-2 border-neutral-200 px-5 py-3.5 text-sm font-bold text-neutral-600"
              >
                Cancel
              </button>
            </div>
          </div>
        ) : (
          <>
            <div className="flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={() => setDraft(emptyDraft(group))}
                className="rounded-full bg-[#1257d0] px-5 py-3 text-sm font-bold text-white"
              >
                + Add a phone
              </button>
              <label className="relative min-w-[210px] flex-1">
                <input
                  value={find}
                  onChange={e => setFind(e.target.value)}
                  placeholder="Search this list — e.g. iPhone 14"
                  className="w-full rounded-full border border-neutral-200 bg-white py-3 pl-10 pr-9 text-sm outline-none focus:border-[#1257d0]"
                />
                <span className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-neutral-400">
                  ⌕
                </span>
                {find && (
                  <button
                    type="button"
                    aria-label="Clear search"
                    onClick={() => setFind("")}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-lg font-bold text-neutral-400"
                  >
                    ×
                  </button>
                )}
              </label>
              {(phones ?? []).some(p => p.demo) && (
                <button
                  type="button"
                  onClick={() => void clearDemo({})}
                  className="rounded-full border-2 border-amber-500 px-5 py-3 text-sm font-bold text-amber-700"
                >
                  Delete all sample stock
                </button>
              )}
            </div>

            {/* Stock is grouped: iPhones together, Samsungs together, and so on. */}
            <div className="-mx-4 mt-4 flex gap-2 overflow-x-auto px-4 pb-1">
              {GROUPS.map(g => {
                const total = (phones ?? []).filter(
                  p => p.brand === g.key,
                ).length;
                const active = group === g.key;
                return (
                  <button
                    key={g.key}
                    type="button"
                    onClick={() => setGroup(g.key)}
                    className={`shrink-0 rounded-full px-4 py-2.5 text-[13.5px] font-bold transition ${
                      active
                        ? "bg-neutral-900 text-white"
                        : "bg-white text-neutral-700 ring-1 ring-black/10"
                    }`}
                  >
                    {g.label}
                    <span
                      className={`ml-1.5 text-[11px] ${active ? "text-white/70" : "text-neutral-400"}`}
                    >
                      {total}
                    </span>
                  </button>
                );
              })}
            </div>

            <div className="mt-3 flex gap-2">
              {(
                [
                  ["available", `Available (${inGroup.length - soldCount})`],
                  ["sold", `Sold (${soldCount})`],
                ] as const
              ).map(([key, label]) => (
                <button
                  key={key}
                  type="button"
                  onClick={() => setShelf(key)}
                  className={`rounded-full px-4 py-2 text-[13px] font-bold transition ${
                    shelf === key
                      ? "bg-[#1257d0] text-white"
                      : "bg-white text-neutral-600 ring-1 ring-black/10"
                  }`}
                >
                  {label}
                </button>
              ))}
            </div>

            {group !== "Accessory" && (
              <div className="cc-rail mt-2.5 flex gap-2 overflow-x-auto pb-1">
                {(
                  [
                    ["all", `All (${onShelf.length})`],
                    [
                      "certified_refurbished",
                      `Certified refurbished (${kindCount("certified_refurbished")})`,
                    ],
                    ["pre_owned", `Pre-owned (${kindCount("pre_owned")})`],
                  ] as const
                ).map(([key, label]) => (
                  <button
                    key={key}
                    type="button"
                    onClick={() => setKind(key)}
                    className={`shrink-0 rounded-full px-3.5 py-2 text-[12.5px] font-bold transition ${
                      kind === key
                        ? "bg-sky-100 text-[#0b3f9e] ring-1 ring-[#1257d0]/40"
                        : "bg-white text-neutral-600 ring-1 ring-black/10"
                    }`}
                  >
                    {label}
                  </button>
                ))}
              </div>
            )}

            <div className="mt-4 space-y-2">
              {shown.length === 0 && (
                <p className="rounded-2xl bg-white p-6 text-center text-sm text-neutral-500 ring-1 ring-black/5">
                  {find.trim()
                    ? `Nothing in this list matches “${find}”.`
                    : shelf === "sold"
                      ? "Nothing marked sold in here yet."
                      : "No stock in here yet. Tap “Add a phone” to put one up."}
                </p>
              )}
              {shown.map(p => {
                const sold = isSold(p);
                return (
                  <div
                    key={p._id}
                    className="flex flex-wrap items-center gap-3 rounded-2xl bg-white p-3 shadow-sm ring-1 ring-black/5"
                  >
                    <div className="size-14 shrink-0 overflow-hidden rounded-xl bg-neutral-100">
                      {p.photoUrls[0] && (
                        <img
                          src={p.photoUrls[0]}
                          alt=""
                          className="h-full w-full object-cover"
                        />
                      )}
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-[14px] font-bold">
                        {p.model}{" "}
                        {p.demo && (
                          <span className="rounded bg-amber-100 px-1.5 py-0.5 text-[10px] font-black text-amber-700">
                            SAMPLE
                          </span>
                        )}
                        {sold && (
                          <span className="ml-1 rounded bg-neutral-200 px-1.5 py-0.5 text-[10px] font-black text-neutral-700">
                            SOLD
                          </span>
                        )}
                      </p>
                      <p className="truncate text-[12px] text-neutral-500">
                        {CONDITION_LABEL[p.condition]} · {p.colour} ·{" "}
                        {p.variants
                          .map(v => `${v.storage} ${rands(v.price)}`)
                          .join(" · ")}
                      </p>
                    </div>
                    <div className="flex gap-2">
                      <button
                        type="button"
                        onClick={() => setDraft(editDraft(p))}
                        className="rounded-full bg-[#1257d0] px-4 py-2 text-[13px] font-bold text-white transition active:scale-95"
                      >
                        Edit
                      </button>
                      <button
                        type="button"
                        onClick={() =>
                          void setSold({
                            id: p._id as Id<"phones">,
                            sold: !sold,
                          })
                        }
                        className={`rounded-full px-3 py-2 text-[13px] font-bold ${
                          sold
                            ? "bg-sky-50 text-[#1257d0] ring-1 ring-sky-200"
                            : "bg-amber-50 text-amber-700 ring-1 ring-amber-200"
                        }`}
                      >
                        {sold ? "Put back on sale" : "Mark as sold"}
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          if (confirm(`Delete ${p.model}?`))
                            void deletePhone({ id: p._id as Id<"phones"> });
                        }}
                        className="rounded-full bg-red-50 px-3 py-2 text-[13px] font-bold text-red-600"
                      >
                        Delete
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Same two moves again at the foot of the list, so a long list
                never has to be scrolled back up. */}
            <div className="mt-5 flex flex-wrap items-center gap-2 border-t border-neutral-200 pt-5">
              <button
                type="button"
                onClick={() => {
                  setDraft(emptyDraft(group));
                  window.scrollTo({ top: 0, behavior: "smooth" });
                }}
                className="rounded-full bg-[#1257d0] px-5 py-3 text-sm font-bold text-white transition active:scale-95"
              >
                + Add a phone
              </button>
              <Link
                to="/"
                className="rounded-full border-2 border-[#1257d0] px-5 py-3 text-sm font-bold text-[#1257d0] transition active:scale-95"
              >
                ← Back to shop
              </Link>
            </div>
          </>
        )}
      </main>
    </div>
  );
}

const inputClass =
  "w-full rounded-xl border border-neutral-200 bg-white px-3 py-2.5 text-sm outline-none focus:border-[#1257d0]";

function Field({
  label,
  children,
}: {
  label: string;
  children: React.ReactNode;
}) {
  return (
    <label className="mt-3 block sm:mt-0">
      <span className="mb-1 block text-[11px] font-bold uppercase tracking-wide text-neutral-500">
        {label}
      </span>
      {children}
    </label>
  );
}

function SmallField({
  label,
  children,
}: {
  label: string;
  children: React.ReactNode;
}) {
  return (
    <label className="block">
      <span className="mb-1 block text-[10.5px] font-bold uppercase tracking-wide text-neutral-500">
        {label}
      </span>
      {children}
    </label>
  );
}


/**
 * A suggestion list we control, so it can carry the shop's colours and read
 * clearly on a phone. The browser's own datalist can't be styled at all.
 */
function Suggest({
  value,
  options,
  placeholder,
  swatch = false,
  onPick,
}: {
  value: string;
  options: string[];
  placeholder?: string;
  swatch?: boolean;
  onPick: (value: string) => void;
}) {
  const [open, setOpen] = useState(false);
  const [showEvery, setShowEvery] = useState(false);
  const typed = value.trim().toLowerCase();
  const list =
    typed && !showEvery
      ? options.filter(o => o.toLowerCase().includes(typed))
      : options;

  return (
    <div className="relative">
      <input
        value={value}
        placeholder={placeholder}
        onChange={e => {
          onPick(e.target.value);
          setShowEvery(false);
          setOpen(true);
        }}
        onFocus={() => setOpen(true)}
        onBlur={() => window.setTimeout(() => setOpen(false), 150)}
        className={`${inputClass} pr-9`}
      />
      <button
        type="button"
        aria-label="Show the list"
        tabIndex={-1}
        onMouseDown={e => e.preventDefault()}
        onClick={() => {
          // Always show every model / colour, even when something is already
          // typed in the box, and never close on the first tap.
          if (open && showEvery) {
            setOpen(false);
            return;
          }
          setShowEvery(true);
          setOpen(true);
        }}
        className="absolute right-1.5 top-1/2 grid size-7 -translate-y-1/2 place-items-center rounded-lg text-[#1257d0] transition hover:bg-sky-50"
      >
        <svg viewBox="0 0 24 24" className="size-4" fill="none" stroke="currentColor" strokeWidth={3} strokeLinecap="round" strokeLinejoin="round" aria-hidden>
          <path d="m6 9 6 6 6-6" />
        </svg>
      </button>
      {open && list.length > 0 && (
        <ul className="absolute z-30 mt-1 max-h-60 w-full overflow-y-auto rounded-2xl border border-[#1257d0]/25 bg-sky-50 p-1 shadow-xl">
          {list.map(o => (
            <li key={o}>
              <button
                type="button"
                onMouseDown={e => e.preventDefault()}
                onClick={() => {
                  onPick(o);
                  setShowEvery(false);
                  setOpen(false);
                }}
                className={`flex w-full items-center gap-2 rounded-xl px-3 py-2 text-left text-[13.5px] font-semibold hover:bg-white ${
                  o.toLowerCase() === typed
                    ? "bg-white text-[#0b3f9e] ring-1 ring-[#1257d0]/30"
                    : "text-neutral-700"
                }`}
              >
                {swatch && (
                  <span
                    className="inline-block size-4 shrink-0 rounded-full ring-1 ring-black/10"
                    style={{ backgroundColor: colourHex(o) }}
                  />
                )}
                {o}
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}


/** Resize a photo in the browser before it is uploaded. Long edge 1600px,
 *  which is still sharp when zoomed in, at a fraction of the weight. */
async function shrink(file: File): Promise<Blob> {
  if (!file.type.startsWith("image/")) return file;
  try {
    const bitmap = await createImageBitmap(file);
    const long = Math.max(bitmap.width, bitmap.height);
    const ratio = long > 1600 ? 1600 / long : 1;
    if (ratio === 1 && file.size < 700_000) return file;
    const canvas = document.createElement("canvas");
    canvas.width = Math.round(bitmap.width * ratio);
    canvas.height = Math.round(bitmap.height * ratio);
    const ctx = canvas.getContext("2d");
    if (!ctx) return file;
    ctx.drawImage(bitmap, 0, 0, canvas.width, canvas.height);
    bitmap.close();
    const blob = await new Promise<Blob | null>(done =>
      canvas.toBlob(done, "image/jpeg", 0.85),
    );
    return blob && blob.size < file.size ? blob : file;
  } catch {
    return file;
  }
}
