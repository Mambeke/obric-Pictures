export type Spec = { label: string; value: string };

export type Appliance = {
  _id: string;
  category: string;
  title: string;
  condition: string;
  price: number;
  wasPrice?: number;
  description?: string;
  specs: Spec[];
  testedOn?: string;
  freeDelivery: boolean;
  photos: string[];
  photoUrls: string[];
  sold: boolean;
  soldAt?: number;
  demo?: boolean;
  createdAt: number;
};

export function savePercent(item: Appliance): number | null {
  if (!item.wasPrice || item.wasPrice <= item.price) return null;
  return Math.round(((item.wasPrice - item.price) / item.wasPrice) * 100);
}
