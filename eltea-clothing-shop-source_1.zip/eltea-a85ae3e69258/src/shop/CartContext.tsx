import { createContext, type ReactNode, useContext, useMemo, useState } from "react";
import type { Piece } from "./lib";

type CartCtx = {
  items: Piece[];
  add: (p: Piece) => void;
  remove: (id: string) => void;
  clear: () => void;
  has: (id: string) => boolean;
  total: number;
  open: boolean;
  setOpen: (v: boolean) => void;
};

const Ctx = createContext<CartCtx | null>(null);

export function CartProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<Piece[]>([]);
  const [open, setOpen] = useState(false);
  const value = useMemo<CartCtx>(
    () => ({
      items,
      open,
      setOpen,
      add: p => setItems(cur => (cur.some(x => x._id === p._id) ? cur : [...cur, p])),
      remove: id => setItems(cur => cur.filter(x => x._id !== id)),
      clear: () => setItems([]),
      has: id => items.some(x => x._id === id),
      total: items.reduce((s, p) => s + p.price, 0),
    }),
    [items, open],
  );
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useCart() {
  const c = useContext(Ctx);
  if (!c) throw new Error("useCart outside CartProvider");
  return c;
}
