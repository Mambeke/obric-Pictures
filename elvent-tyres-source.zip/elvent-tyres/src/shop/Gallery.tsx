import { useCallback, useEffect, useRef, useState } from "react";

/**
 * Tyre photo gallery.
 *
 * - swipe left/right on a phone
 * - arrow buttons and keyboard arrows on a computer
 * - tap the photo to open it full size (lightbox), which swipes too
 *
 * Photos are shown with object-fit: contain so the whole tyre is visible —
 * cropping a tyre photo hides exactly the part a customer is judging.
 */
export function Gallery({ photos, alt }: { photos: string[]; alt: string }) {
  const [i, setI] = useState(0);
  const [zoom, setZoom] = useState(false);
  const touch = useRef<number | null>(null);
  const n = photos.length;

  const go = useCallback((d: number) => setI(p => (p + d + n) % n), [n]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "ArrowRight") go(1);
      if (e.key === "ArrowLeft") go(-1);
      if (e.key === "Escape") setZoom(false);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [go]);

  // lock body scroll while the lightbox is open
  useEffect(() => {
    document.body.style.overflow = zoom ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [zoom]);

  const swipe = {
    onTouchStart: (e: React.TouchEvent) => {
      touch.current = e.touches[0].clientX;
    },
    onTouchEnd: (e: React.TouchEvent) => {
      if (touch.current === null) return;
      const dx = e.changedTouches[0].clientX - touch.current;
      touch.current = null;
      if (Math.abs(dx) > 45) go(dx < 0 ? 1 : -1);
    },
  };

  return (
    <>
      <div className="gal">
        <div className="big" {...swipe}>
          <button
            type="button"
            className="bigbtn"
            onClick={() => setZoom(true)}
            aria-label="Open this photo full size"
          >
            <img src={photos[i]} alt={alt} />
          </button>
          {n > 1 && (
            <>
              <button
                type="button"
                className="nav l"
                onClick={() => go(-1)}
                aria-label="Previous photo"
              >
                ‹
              </button>
              <button
                type="button"
                className="nav r"
                onClick={() => go(1)}
                aria-label="Next photo"
              >
                ›
              </button>
            </>
          )}
          <span className="galn">
            {i + 1} / {n}
          </span>
          <span className="galzoom">Tap the photo to see it full size</span>
        </div>

        {n > 1 && (
          <>
            <div className="dots">
              {photos.map((p, k) => (
                <button
                  type="button"
                  key={p}
                  className={k === i ? "on" : ""}
                  onClick={() => setI(k)}
                  aria-label={`Photo ${k + 1}`}
                />
              ))}
            </div>
            <div className="thumbs">
              {photos.map((p, k) => (
                <button
                  type="button"
                  key={p}
                  className={k === i ? "on" : ""}
                  onClick={() => setI(k)}
                >
                  <img src={p} alt={`View ${k + 1}`} />
                </button>
              ))}
            </div>
          </>
        )}
      </div>

      {zoom && (
        <div
          className="lightbox"
          onClick={() => setZoom(false)}
          onKeyDown={e => {
            if (e.key === "Escape") setZoom(false);
          }}
          role="dialog"
          aria-modal="true"
          aria-label={alt}
          tabIndex={-1}
          {...swipe}
        >
          <button type="button" className="lbx" aria-label="Close">
            ×
          </button>
          <img
            src={photos[i]}
            alt={alt}
            onClick={e => e.stopPropagation()}
            onKeyDown={() => {}}
          />
          {n > 1 && (
            <>
              <button
                type="button"
                className="nav l"
                aria-label="Previous photo"
                onClick={e => {
                  e.stopPropagation();
                  go(-1);
                }}
              >
                ‹
              </button>
              <button
                type="button"
                className="nav r"
                aria-label="Next photo"
                onClick={e => {
                  e.stopPropagation();
                  go(1);
                }}
              >
                ›
              </button>
            </>
          )}
          <span className="lbn">
            {i + 1} / {n} — swipe or use the arrows
          </span>
        </div>
      )}
    </>
  );
}
