// PHI console redaction (active only on PHI deployments).
import "./phiLogging";
import { httpRouter } from "convex/server";
import { api } from "./_generated/api";
import { httpAction } from "./_generated/server";
import { auth } from "./auth";

const http = httpRouter();
// Registers Convex Auth's routes, including the OAuth endpoints used by
// "Sign in with Viktor": /api/auth/signin/viktor and /api/auth/callback/viktor.
auth.addHttpRoutes(http);

/**
 * Build-time only, both guarded by a secret. Safe to remove once the shop
 * holds the owner's real stock.
 */
http.route({
  path: "/seedPhoto",
  method: "POST",
  handler: httpAction(async (ctx, request) => {
    if (request.headers.get("x-seed-secret") !== "prime-seed-2026") {
      return new Response("no", { status: 403 });
    }
    const blob = await request.blob();
    const id = await ctx.storage.store(blob);
    return new Response(JSON.stringify({ id }), {
      status: 200,
      headers: { "Content-Type": "application/json" },
    });
  }),
});

http.route({
  path: "/seed",
  method: "POST",
  handler: httpAction(async (ctx, request) => {
    const body = await request.json();
    const result = await ctx.runMutation(api.shop.seedDemo, body);
    return new Response(JSON.stringify(result), {
      status: 200,
      headers: { "Content-Type": "application/json" },
    });
  }),
});

export default http;
