# Eltea Boutique — production build
- [ ] schema: pieces, categories, shopSettings
- [ ] convex/shop.ts: public reads, owner-only writes, upload url, seed
- [ ] port demo UI -> React: Shop, Item, Cart, ribbon, search, 3 tab rails, filters
- [ ] admin portal: add/edit/delete piece, photo upload, categories, settings, sold
- [ ] seed 50 demo pieces from /work/temp/zclothes
- [ ] e2e tests, screenshots
- [ ] preview deploy -> show Brandon -> production
