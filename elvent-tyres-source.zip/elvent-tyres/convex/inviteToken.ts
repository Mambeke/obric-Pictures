/**
 * Invite tokens for staff sign-up.
 *
 * WHY THIS EXISTS, in one paragraph, because the reason is not obvious:
 *
 * Who may CHANGE stock is a database question — the owner grants and revokes
 * access from the Staff tab, and every admin function checks the staff table
 * on every call. But who may CREATE an account is decided inside the auth
 * provider's `profile()` callback, and that callback is synchronous: the
 * library reads its return value directly, so it cannot await a database
 * lookup. (Verified against the installed @convex-dev/auth: `const profile =
 * config.profile?.(params, ctx) ?? defaultProfile(params)` — no await.)
 *
 * So the invite carries its own proof. When the owner adds a staff email, the
 * server signs that email with a secret and hands back a link. Sign-up checks
 * the signature — no database needed, nothing to guess, and a token only ever
 * unlocks the one address it was issued for.
 *
 * The token is not the access. It only opens the door to make an account;
 * whether that account can touch a single tyre is still decided by the staff
 * table, so revoking someone works instantly even if they kept their link.
 */

const SECRET =
  (globalThis as { process?: { env?: Record<string, string | undefined> } })
    .process?.env?.INVITE_SECRET ??
  // A fallback so the feature works without an environment variable being set
  // by hand. Rotating this invalidates outstanding invites, nothing else.
  "elvent-tyres-staff-invite-v1-9f3c1a7d";

/* ------------------------------------------------------------------ *
 * Synchronous SHA-256. crypto.subtle is async and Node's crypto is not
 * available in this runtime, so the hash is done in plain arithmetic.
 * Standard FIPS 180-4, no dependencies.
 * ------------------------------------------------------------------ */

const K = [
  0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1,
  0x923f82a4, 0xab1c5ed5, 0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3,
  0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174, 0xe49b69c1, 0xefbe4786,
  0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
  0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147,
  0x06ca6351, 0x14292967, 0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13,
  0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85, 0xa2bfe8a1, 0xa81a664b,
  0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
  0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a,
  0x5b9cca4f, 0x682e6ff3, 0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208,
  0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2,
];

function sha256Bytes(input: Uint8Array): Uint8Array {
  const h = [
    0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c,
    0x1f83d9ab, 0x5be0cd19,
  ];
  const bitLen = input.length * 8;
  // Minimal padding, exactly as the spec requires: message, 0x80, zeros, then
  // the 64-bit length. Rounding up too far still "looks" like padding but
  // produces a hash that no other SHA-256 implementation agrees with.
  const padded = new Uint8Array((((input.length + 8) >> 6) << 6) + 64);
  padded.set(input);
  padded[input.length] = 0x80;
  // Length as a 64-bit big-endian value; only the low 32 bits can matter here.
  new DataView(padded.buffer).setUint32(padded.length - 4, bitLen >>> 0, false);

  const w = new Uint32Array(64);
  const rotr = (x: number, n: number) => (x >>> n) | (x << (32 - n));

  for (let i = 0; i < padded.length; i += 64) {
    for (let t = 0; t < 16; t++) {
      const o = i + t * 4;
      w[t] =
        ((padded[o] << 24) |
          (padded[o + 1] << 16) |
          (padded[o + 2] << 8) |
          padded[o + 3]) >>>
        0;
    }
    for (let t = 16; t < 64; t++) {
      const s0 = rotr(w[t - 15], 7) ^ rotr(w[t - 15], 18) ^ (w[t - 15] >>> 3);
      const s1 = rotr(w[t - 2], 17) ^ rotr(w[t - 2], 19) ^ (w[t - 2] >>> 10);
      w[t] = (w[t - 16] + s0 + w[t - 7] + s1) >>> 0;
    }
    let [a, b, c, d, e, f, g, hh] = h;
    for (let t = 0; t < 64; t++) {
      const S1 = rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25);
      const ch = (e & f) ^ (~e & g);
      const t1 = (hh + S1 + ch + K[t] + w[t]) >>> 0;
      const S0 = rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22);
      const maj = (a & b) ^ (a & c) ^ (b & c);
      const t2 = (S0 + maj) >>> 0;
      hh = g;
      g = f;
      f = e;
      e = (d + t1) >>> 0;
      d = c;
      c = b;
      b = a;
      a = (t1 + t2) >>> 0;
    }
    const next = [a, b, c, d, e, f, g, hh];
    for (let t = 0; t < 8; t++) h[t] = (h[t] + next[t]) >>> 0;
  }

  const out = new Uint8Array(32);
  const view = new DataView(out.buffer);
  for (let t = 0; t < 8; t++) view.setUint32(t * 4, h[t], false);
  return out;
}

const enc = (s: string) => new TextEncoder().encode(s);
const hex = (b: Uint8Array) =>
  [...b].map(x => x.toString(16).padStart(2, "0")).join("");

/** HMAC-SHA256, so the secret cannot be recovered by length-extension. */
function hmac(key: string, message: string): string {
  const block = new Uint8Array(64);
  const keyBytes = enc(key);
  block.set(keyBytes.length > 64 ? sha256Bytes(keyBytes) : keyBytes);
  const inner = new Uint8Array(64);
  const outer = new Uint8Array(64);
  for (let i = 0; i < 64; i++) {
    inner[i] = block[i] ^ 0x36;
    outer[i] = block[i] ^ 0x5c;
  }
  const msg = enc(message);
  const i1 = new Uint8Array(64 + msg.length);
  i1.set(inner);
  i1.set(msg, 64);
  const ih = sha256Bytes(i1);
  const o1 = new Uint8Array(64 + 32);
  o1.set(outer);
  o1.set(ih, 64);
  return hex(sha256Bytes(o1));
}

export function normaliseEmail(email: string): string {
  return String(email ?? "")
    .trim()
    .toLowerCase();
}

/** A token that proves the shop owner invited exactly this address. */
export function makeInviteToken(email: string): string {
  return hmac(SECRET, normaliseEmail(email)).slice(0, 32);
}

/** Constant-time-ish compare; the token is short and low-value, but free. */
export function checkInviteToken(email: string, token: string): boolean {
  const want = makeInviteToken(email);
  const got = String(token ?? "");
  if (got.length !== want.length) return false;
  let diff = 0;
  for (let i = 0; i < want.length; i++)
    diff |= want.charCodeAt(i) ^ got.charCodeAt(i);
  return diff === 0;
}
