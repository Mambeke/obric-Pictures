import { useQuery } from "convex/react";
import { useEffect } from "react";
import { Link, useNavigate, useParams } from "react-router";
import { api } from "../../convex/_generated/api";
import "../shop.css";
import { Gallery } from "@/shop/Gallery";
import { Footer, Ticker, TopBar } from "@/shop/ShopChrome";
import { FALLBACK_PHOTO, SERVICES, SHOP, waLink } from "@/shop/shopConfig";
import { WaIcon } from "@/shop/WaIcon";

export function TyrePage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const data = useQuery(api.tyres.get, id ? { id } : "skip");
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  if (data === undefined) {
    return (
      <>
        <TopBar />
        <div className="wrap">
          <div className="empty">Loading…</div>
        </div>
      </>
    );
  }
  if (data === null) {
    return (
      <>
        <TopBar />
        <div className="wrap">
          <div className="empty">
            That tyre is no longer in stock.{" "}
            <Link to="/" style={{ color: "var(--green)", fontWeight: 600 }}>
              See what we have →
            </Link>
          </div>
        </div>
        <Footer />
      </>
    );
  }

  const { tyre, similar } = data;
  const photos = tyre.photos.length > 0 ? tyre.photos : [FALLBACK_PHOTO];

  return (
    <>
      <TopBar />
      <Ticker />
      <div id="detail" className="on">
        <div className="wrap">
          <button
            type="button"
            className="back"
            style={{ background: "none", border: 0, font: "inherit" }}
            onClick={() => navigate(-1)}
          >
            ← Back to all tyres
          </button>

          <div className="dwrap">
            <div>
              <Gallery
                photos={photos}
                alt={`${tyre.sizeLabel} ${tyre.brand}`}
              />
            </div>

            <div>
              <div className="dsz">{tyre.sizeLabel}</div>
              <div className="dbrand">
                {tyre.brand} · {tyre.condition === "new" ? "New" : "Used"} tyre
              </div>
              <div className="dprice">R {tyre.price}</div>
              <div className="sub">Price per tyre, fitted price on request</div>

              <table className="spec">
                <tbody>
                  <tr>
                    <td>Size</td>
                    <td>{tyre.sizeLabel}</td>
                  </tr>
                  <tr>
                    <td>Brand</td>
                    <td>{tyre.brand}</td>
                  </tr>
                  <tr>
                    <td>Condition</td>
                    <td>{tyre.condition === "new" ? "New" : "Used"}</td>
                  </tr>
                  <tr>
                    <td>Availability</td>
                    <td>
                      {tyre.stock > 1
                        ? `${tyre.stock} available`
                        : "1 available"}
                    </td>
                  </tr>
                  <tr>
                    <td>Photos</td>
                    <td>{tyre.photoCount} of this actual tyre</td>
                  </tr>
                  {tyre.notes ? (
                    <tr>
                      <td>Notes</td>
                      <td>{tyre.notes}</td>
                    </tr>
                  ) : null}
                </tbody>
              </table>

              <div className="dacts">
                <a
                  className="btn wa"
                  href={waLink(tyre)}
                  target="_blank"
                  rel="noreferrer"
                >
                  <WaIcon />
                  WhatsApp to order
                </a>
                <a className="btn cl" href={`tel:${SHOP.phoneRaw}`}>
                  Call the shop
                </a>
              </div>

              <div className="note">
                📍 {SHOP.addressFull} · {SHOP.hoursLong}
                <br />
                {SERVICES.map(s => `${s[0]} ${s[1]}`).join(" · ")}
              </div>
            </div>
          </div>

          {similar.length > 0 && (
            <>
              <div className="simtitle">Related stock in the shop</div>
              <div className="grid">
                {similar.map(s => (
                  <Link className="card simcard" to={`/t/${s.id}`} key={s.id}>
                    <div className="ph">
                      <img
                        src={s.photos[0] ?? FALLBACK_PHOTO}
                        alt={`${s.sizeLabel} ${s.brand}`}
                        loading="lazy"
                      />
                      <span className="sz">{s.sizeLabel}</span>
                      <span
                        className={`cond ${s.condition === "new" ? "n" : "u"}`}
                      >
                        {s.condition}
                      </span>
                    </div>
                    <div className="body">
                      {/* the size again in the body — a customer scanning the
                          related row must never have to guess the size */}
                      <div className="brand">
                        {s.sizeLabel} — {s.brand}
                      </div>
                      <div className="sub">
                        {s.condition === "new" ? "New" : "Used"} ·{" "}
                        {s.stock > 1 ? `${s.stock} in stock` : "single"}
                      </div>
                      <div className="price">
                        R {s.price}
                        <u>each</u>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            </>
          )}
        </div>
      </div>
      <Footer />
    </>
  );
}
