// The only accounts allowed into the admin area.
// Add another email here (and redeploy) to let a second person manage stock.
export const OWNER_EMAILS = ["brandonmambeke@gmail.com"];

export function isOwnerEmail(email: string | undefined | null): boolean {
  if (!email) return false;
  return OWNER_EMAILS.includes(email.trim().toLowerCase());
}
