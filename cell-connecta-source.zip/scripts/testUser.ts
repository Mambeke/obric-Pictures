export const TEST_USER = {
  email: "agent-gtgj6dmss3611vfg@test.local",
  password: "Cb04pmdioKfWZWedu9f6L1pRoCzksMXL",
  name: "Test Agent",
} as const;
