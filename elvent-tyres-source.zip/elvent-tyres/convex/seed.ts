import { internalMutation } from "./_generated/server";
import { normalise } from "./tyres";

/**
 * Demo stock so the shop is never empty on first open.
 * Photos are the generated placeholders in /public/demo — Brandon replaces
 * these with real shop photos through the admin area.
 *
 *   bunx convex run seed:demo
 */
const D = {
  face: "/demo/face.webp",
  angled: "/demo/angled.webp",
  side: "/demo/side.webp",
  tread: "/demo/tread.webp",
};
const USED = [D.angled, D.side, D.tread, D.face];
const NEW = [D.face, D.angled, D.tread];

const ROWS: [string, string, "used" | "new", number, number][] = [
  ["195/65R15", "Bridgestone Turanza", "used", 520, 1],
  ["205/55R16", "Michelin Primacy 4", "used", 680, 1],
  ["155/80R13", "Dunlop SP Touring", "used", 380, 1],
  ["185/65R15", "Continental EcoContact", "used", 450, 1],
  ["225/45R17", "Pirelli P Zero", "used", 950, 1],
  ["165/80R14", "Firestone F600", "used", 340, 1],
  ["215/60R17", "Hankook Ventus", "used", 780, 1],
  ["175/70R14", "Yokohama BluEarth", "used", 400, 1],
  ["195/60R15", "Goodyear EfficientGrip", "used", 490, 1],
  ["205/60R16", "Kumho Ecsta", "used", 560, 1],
  ["235/75R15", "BF Goodrich A/T", "used", 890, 1],
  ["185/60R14", "Sumitomo BC100", "used", 360, 1],
  ["195/65R15", "Goodyear Assurance", "new", 1180, 6],
  ["205/55R16", "Continental UltraContact", "new", 1620, 4],
  ["175/65R14", "Dunlop SP Touring R1", "new", 890, 10],
  ["155/80R13", "Wanli S1063", "new", 620, 12],
  ["265/65R17", "BF Goodrich KO2", "new", 3450, 4],
];

export const demo = internalMutation({
  args: {},
  handler: async ctx => {
    // Enough stock for the e2e tests to exercise a real grid. Guarding on
    // "any row at all" used to leave the suite failing after clearDemo left a
    // single hidden tyre behind.
    const existing = await ctx.db.query("tyres").take(9);
    if (existing.length >= 8) return "already seeded";

    let i = 0;
    for (const [sizeLabel, brand, condition, price, stock] of ROWS) {
      const base = condition === "new" ? NEW : USED;
      const k = i % base.length;
      const m = sizeLabel.match(/(\d{3})\D*(\d{2})\D*R?(\d{2})/);
      await ctx.db.insert("tyres", {
        sizeLabel,
        sizeKey: normalise(sizeLabel),
        width: m?.[1] ?? "",
        profile: m?.[2] ?? "",
        rim: m?.[3] ?? "",
        brand,
        condition,
        price,
        stock,
        photos: [],
        photoUrls: [...base.slice(k), ...base.slice(0, k)],
        active: true,
        createdAt: Date.now() - i * 1000,
      });
      i++;
    }
    return `seeded ${ROWS.length} tyres`;
  },
});

/**
 * Remove the seeded placeholder stock once real photos are loaded.
 *   bunx convex run seed:clearDemo
 *
 * A tyre with real uploaded photos is kept — only its leftover /demo/ images
 * are stripped. A tyre that is still pure placeholder is deleted outright.
 */
export const clearDemo = internalMutation({
  args: {},
  handler: async ctx => {
    const all = await ctx.db.query("tyres").collect();
    let deleted = 0;
    let stripped = 0;
    for (const t of all) {
      const demo = (t.photoUrls ?? []).filter(u => u.startsWith("/demo/"));
      if (demo.length === 0) continue;
      if (t.photos.length > 0) {
        await ctx.db.patch(t._id, {
          photoUrls: (t.photoUrls ?? []).filter(u => !u.startsWith("/demo/")),
        });
        stripped++;
      } else {
        await ctx.db.delete(t._id);
        deleted++;
      }
    }
    return `deleted ${deleted} demo tyres, stripped placeholders from ${stripped} real ones`;
  },
});
