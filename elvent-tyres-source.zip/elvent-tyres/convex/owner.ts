import type { GenericQueryCtx } from "convex/server";
import type { DataModel, Id } from "./_generated/dataModel";
import { normaliseEmail } from "./inviteToken";

/**
 * Two levels of access, on purpose.
 *
 *   OWNERS  — the shop's permanent accounts, written here in the code.
 *             They manage stock AND manage who else has access.
 *             They cannot be revoked from inside the app, so nobody can lock
 *             the shop owner out of his own shop by clicking the wrong button.
 *
 *   STAFF   — rows in the `staff` table, granted and revoked by an owner from
 *             the Staff tab. They manage stock. They cannot add or remove
 *             other people.
 *
 * The shop front is open to the whole internet and stays that way; none of
 * this touches a customer.
 */
const OWNERS = ["brandonmambeke@gmail.com", "thabisani@elventmarket.com"];

type Ctx = GenericQueryCtx<DataModel>;

function envList(): string[] {
  const env = (
    globalThis as { process?: { env?: Record<string, string | undefined> } }
  ).process?.env;
  const raw = env?.ADMIN_EMAILS;
  const isPreview = env?.VIKTOR_SPACES_IS_PREVIEW === "true";
  return (raw ? raw.split(",") : [])
    .map(normaliseEmail)
    .filter(Boolean)
    // Automated test accounts get access on preview only, never on the live
    // shop, whatever the environment happens to say.
    .filter(e => isPreview || !e.endsWith("@test.local"));
}

/**
 * The permanent owners. Synchronous, because the auth provider's `profile()`
 * callback needs an answer without a database round trip (see inviteToken.ts).
 * This is NOT the full list of people who can edit stock — use `canEdit` for
 * that anywhere you have a ctx.
 */
export function ownerEmails(): string[] {
  return [...new Set([...OWNERS.map(normaliseEmail), ...envList()])];
}

export function isOwnerEmail(email: string): boolean {
  return ownerEmails().includes(normaliseEmail(email));
}

/** Everyone who may change stock right now: owners plus un-revoked staff. */
export async function editorEmails(ctx: Ctx): Promise<string[]> {
  const rows = await ctx.db.query("staff").collect();
  return [
    ...new Set([
      ...ownerEmails(),
      ...rows.filter(r => r.active).map(r => normaliseEmail(r.email)),
    ]),
  ];
}

export async function canEdit(ctx: Ctx, email: string): Promise<boolean> {
  const e = normaliseEmail(email);
  if (!e) return false;
  if (isOwnerEmail(e)) return true;
  const row = await ctx.db
    .query("staff")
    .withIndex("by_email", i => i.eq("email", e))
    .unique();
  return Boolean(row?.active);
}

async function emailOf(ctx: Ctx, userId: Id<"users">): Promise<string> {
  const user = await ctx.db.get(userId);
  return normaliseEmail(user?.email ?? "");
}

/** Gate for anything that changes stock. */
export async function requireAdmin(
  ctx: Ctx,
  userId: Id<"users">,
): Promise<string> {
  const email = await emailOf(ctx, userId);
  if (!email || !(await canEdit(ctx, email)))
    throw new Error(
      "This account does not have access to Elvent Tyres stock. Ask the shop owner to give you access.",
    );
  return email;
}

/** Gate for anything that changes WHO has access. Owners only. */
export async function requireOwner(
  ctx: Ctx,
  userId: Id<"users">,
): Promise<string> {
  const email = await emailOf(ctx, userId);
  if (!email || !isOwnerEmail(email))
    throw new Error(
      "Only the shop owner can add or remove staff access.",
    );
  return email;
}
