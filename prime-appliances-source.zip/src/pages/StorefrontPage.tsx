import { useQuery } from "convex/react";
import { useMemo, useState } from "react";
import { Link, useSearchParams } from "react-router";
import { api } from "../../convex/_generated/api";
import { PhoneIcon, ShopFooter, ShopHeader, WhatsAppIcon } from "@/shop/Chrome";
import {
  CATEGORIES,
  CONDITIONS,
  rands,
  type ShopSettings,
  waLink,
} from "@/shop/config";
import { SearchBox } from "@/shop/SearchBox";
import { haystack, matches } from "@/shop/search";
import type { Appliance } from "@/shop/types";

const BANDS = [
  { key: "a", label: "Under R1 500", test: (p: number) => p < 1500 },
  { key: "b", label: "R1 500 – R3 500", test: (p: number) => p >= 1500 && p <= 3500 },
  { key: "c", label: "Over R3 500", test: (p: number) => p > 3500 },
];

const CONDITION_STYLE: Record<string, string> = {
  Excellent: "bg-[#128a5b]",
  Good: "bg-[#128a5b]",
  Fair: "bg-[#e0622a]",
  "Spares or repair": "bg-[#8a94a2]",
};

export function StorefrontPage() {
  const items = useQuery(api.shop.listAppliances) as Appliance[] | undefined;
  const settings = useQuery(api.shop.getSettings) as ShopSettings | undefined;
  const [params, setParams] = useSearchParams();
  const [filtersOpen, setFiltersOpen] = useState(false);
  const PER_PAGE = 20;

  const q = params.get("q") ?? "";
  const category = params.get("cat") ?? "";
  const conds = (params.get("cond") ?? "").split(",").filter(Boolean);
  const bands = (params.get("band") ?? "").split(",").filter(Boolean);
  const freeOnly = params.get("free") === "1";
  const showSold = params.get("sold") === "1";

  const setMany = (patch: Record<string, string>) => {
    const next = new URLSearchParams(params);
    for (const [key, value] of Object.entries(patch)) {
      if (value) next.set(key, value);
      else next.delete(key);
    }
    next.delete("page");
    setParams(next, { replace: true });
  };
  const toggleIn = (key: string, list: string[], value: string) =>
    setMany({
      [key]: (list.includes(value)
        ? list.filter(v => v !== value)
        : [...list, value]
      ).join(","),
    });

  const live = useMemo(() => (items ?? []).filter(i => !i.sold), [items]);
  const sold = useMemo(() => (items ?? []).filter(i => i.sold), [items]);

  const searched = useMemo(() => {
    const pool = showSold ? (items ?? []) : live;
    if (!q.trim()) return pool;
    return pool.filter(i =>
      matches(
        q,
        haystack([
          i.title,
          i.category,
          i.condition,
          i.description,
          ...i.specs.map(s => `${s.label} ${s.value}`),
        ]),
      ),
    );
  }, [items, live, q, showSold]);

  const results = useMemo(
    () =>
      searched.filter(i => {
        if (category && i.category !== category) return false;
        if (conds.length && !conds.includes(i.condition)) return false;
        if (bands.length) {
          const band = BANDS.find(b => b.test(i.price));
          if (!band || !bands.includes(band.key)) return false;
        }
        if (freeOnly && !i.freeDelivery) return false;
        return true;
      }),
    [searched, category, conds, bands, freeOnly],
  );

  const page = Math.max(1, Number(params.get("page") ?? "1") || 1);
  const pageCount = Math.max(1, Math.ceil(results.length / PER_PAGE));
  const safePage = Math.min(page, pageCount);
  const pageItems = results.slice((safePage - 1) * PER_PAGE, safePage * PER_PAGE);
  const goPage = (n: number) => {
    const next = new URLSearchParams(params);
    if (n <= 1) next.delete("page");
    else next.set("page", String(n));
    setParams(next, { replace: true });
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const counts = useMemo(() => {
    const c: Record<string, number> = {};
    for (const i of live) c[i.category] = (c[i.category] ?? 0) + 1;
    return c;
  }, [live]);

  const s = settings;
  if (!s) {
    return <div className="min-h-screen bg-[#f5f7fa]" />;
  }

  const filterCard = (
    <div className="rounded-2xl border border-stone-200 bg-white p-4 shadow-sm">
      <div className="flex items-start justify-between lg:block">
        <p className="text-[13px] font-bold text-[#128a5b]">
          {live.length} appliance{live.length === 1 ? "" : "s"} on the floor
        </p>
        <button
          type="button"
          onClick={() => setFiltersOpen(false)}
          className="text-lg leading-none text-stone-400 lg:hidden"
          aria-label="Close filters"
        >
          ×
        </button>
      </div>

      <div className="grid grid-cols-2 gap-x-4 lg:grid-cols-1 lg:gap-x-0">
        <div className="lg:order-2">
          <FilterGroup title="Condition">
            {CONDITIONS.map(c => (
              <Check
                key={c}
                label={c}
                checked={conds.includes(c)}
                onChange={() => toggleIn("cond", conds, c)}
              />
            ))}
          </FilterGroup>
          <div className="mt-3 border-t border-stone-200 pt-1" />
          <FilterGroup title="Delivery">
            <Check
              label={`Free delivery in ${s.town}`}
              checked={freeOnly}
              onChange={() => setMany({ free: freeOnly ? "" : "1" })}
            />
          </FilterGroup>
        </div>
        <div className="lg:order-1">
          <FilterGroup title="Price">
            {BANDS.map(b => (
              <Check
                key={b.key}
                label={b.label}
                checked={bands.includes(b.key)}
                onChange={() => toggleIn("band", bands, b.key)}
              />
            ))}
          </FilterGroup>
          <div className="hidden lg:mt-3 lg:block lg:border-t lg:border-stone-200" />
        </div>
      </div>

      {(conds.length || bands.length || freeOnly || category) && (
        <button
          type="button"
          onClick={() => setMany({ cond: "", band: "", free: "", cat: "" })}
          className="mt-4 w-full rounded-lg border border-stone-200 py-2 text-[13px] font-semibold text-stone-600"
        >
          Clear all filters
        </button>
      )}
    </div>
  );

  return (
    <div className="min-h-screen bg-[#f5f7fa] text-[#111820]">
      <ShopHeader s={s} />

      <section className="border-b border-stone-200 bg-white">
        <div className="mx-auto max-w-[1560px] px-3 py-6 sm:px-5 sm:py-8">
          <h1 className="text-center text-[22px] font-extrabold sm:text-3xl">
            {s.tagline}
          </h1>
          <p className="mt-1.5 text-center text-[13.5px] text-stone-500 sm:text-[15px]">
            Every appliance switched on and checked before it goes on the floor.
          </p>
          <div className="mx-auto mt-4 max-w-2xl">
            <SearchBox value={q} onChange={v => setMany({ q: v })} />
          </div>
        </div>
      </section>

      <div className="sticky top-[86px] z-30 border-b border-stone-200 bg-white/95 backdrop-blur">
        <div className="pa-rail mx-auto flex max-w-[1560px] gap-2 overflow-x-auto px-3 py-2.5 sm:px-5">
          <Pill active={!category} onClick={() => setMany({ cat: "" })}>
            All
          </Pill>
          {CATEGORIES.filter(c => counts[c]).map(c => (
            <Pill key={c} active={category === c} onClick={() => setMany({ cat: c })}>
              {c} <span className="opacity-55">({counts[c]})</span>
            </Pill>
          ))}
        </div>
      </div>

      <main className="mx-auto grid max-w-[1560px] grid-cols-1 gap-5 px-3 py-5 sm:px-5 lg:grid-cols-[250px_minmax(0,1fr)]">
        <div className="lg:hidden">
          <button
            type="button"
            onClick={() => setFiltersOpen(o => !o)}
            className="w-full rounded-xl bg-[#e0622a] py-2.5 text-sm font-bold text-white shadow-sm active:scale-[.99]"
          >
            {filtersOpen ? "Hide filters ▲" : "Show filters ▼"}
          </button>
          {filtersOpen && <div className="mt-3">{filterCard}</div>}
        </div>
        <aside className="hidden self-start lg:block">{filterCard}</aside>

        <section className="min-w-0">
          <p className="mb-3 text-[13.5px] font-semibold text-stone-600">
            {results.length} showing
            {pageCount > 1 ? ` · page ${safePage} of ${pageCount}` : ""}
            {q.trim() ? ` for “${q.trim()}”` : ""}
          </p>

          {items === undefined ? (
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 xl:grid-cols-4">
              {[0, 1, 2, 3, 4, 5].map(n => (
                <div
                  key={n}
                  className="h-72 animate-pulse rounded-2xl border border-stone-200 bg-white"
                />
              ))}
            </div>
          ) : results.length === 0 ? (
            <Empty s={s} />
          ) : (
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 sm:gap-4 lg:grid-cols-4">
              {pageItems.map(item => (
                <Card key={item._id} item={item} />
              ))}
            </div>
          )}

          {pageCount > 1 && (
            <Pager page={safePage} pageCount={pageCount} onGo={goPage} />
          )}

          <SellSection s={s} />

          {!showSold && sold.length > 0 && (
            <div className="mt-10">
              <h2 className="text-[15px] font-extrabold text-stone-600">Recently sold</h2>
              <p className="mt-0.5 mb-3 text-[13px] text-stone-500">
                Gone already — but this is the kind of stock that comes through.
              </p>
              <div className="pa-rail flex gap-3 overflow-x-auto pb-2">
                {sold.slice(0, 10).map(item => (
                  <div key={item._id} className="w-40 shrink-0 sm:w-48">
                    <Card item={item} />
                  </div>
                ))}
              </div>
            </div>
          )}
        </section>
      </main>

      <ShopFooter s={s} />
    </div>
  );
}

function Pager({
  page,
  pageCount,
  onGo,
}: {
  page: number;
  pageCount: number;
  onGo: (n: number) => void;
}) {
  const nums: number[] = [];
  for (let n = 1; n <= pageCount; n++) {
    if (n === 1 || n === pageCount || Math.abs(n - page) <= 1) nums.push(n);
  }
  return (
    <div className="mt-6 flex flex-wrap items-center justify-center gap-2">
      <button
        type="button"
        disabled={page === 1}
        onClick={() => onGo(page - 1)}
        className="rounded-lg border border-stone-200 bg-white px-4 py-2 text-[13.5px] font-semibold text-stone-700 disabled:opacity-40"
      >
        ← Back
      </button>
      {nums.map((n, idx) => (
        <span key={n} className="flex items-center gap-2">
          {idx > 0 && n - nums[idx - 1] > 1 && (
            <span className="text-stone-400">…</span>
          )}
          <button
            type="button"
            onClick={() => onGo(n)}
            className={`h-9 min-w-9 rounded-lg border px-3 text-[13.5px] font-bold ${
              n === page
                ? "border-[#e0622a] bg-[#e0622a] text-white"
                : "border-stone-200 bg-white text-stone-700"
            }`}
          >
            {n}
          </button>
        </span>
      ))}
      <button
        type="button"
        disabled={page === pageCount}
        onClick={() => onGo(page + 1)}
        className="rounded-lg bg-[#e0622a] px-4 py-2 text-[13.5px] font-bold text-white disabled:opacity-40"
      >
        Next →
      </button>
    </div>
  );
}

function Pill({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`shrink-0 whitespace-nowrap rounded-full border px-4 py-1.5 text-[13.5px] font-semibold transition ${
        active
          ? "border-[#111820] bg-[#111820] text-white"
          : "border-stone-200 bg-white text-stone-600 hover:border-stone-300"
      }`}
    >
      {children}
    </button>
  );
}

function FilterGroup({
  title,
  children,
}: {
  title: string;
  children: React.ReactNode;
}) {
  return (
    <div className="mt-4">
      <h4 className="mb-1.5 text-[11.5px] font-bold uppercase tracking-wider text-stone-400">
        {title}
      </h4>
      <div className="space-y-0.5">{children}</div>
    </div>
  );
}

function Check({
  label,
  checked,
  onChange,
}: {
  label: string;
  checked: boolean;
  onChange: () => void;
}) {
  return (
    <label className="flex cursor-pointer items-center gap-2 py-1 text-[14px] text-stone-700">
      <input
        type="checkbox"
        checked={checked}
        onChange={onChange}
        className="size-4 accent-[#e0622a]"
      />
      {label}
    </label>
  );
}

function Card({ item }: { item: Appliance }) {
  return (
    <Link
      to={`/item/${item._id}`}
      className="group flex flex-col overflow-hidden rounded-2xl border border-stone-200 bg-white transition hover:-translate-y-0.5 hover:border-stone-300 hover:shadow-md"
    >
      <div className="relative aspect-square bg-[#eef1f5]">
        {item.photoUrls[0] ? (
          <img
            src={item.photoUrls[0]}
            alt={item.title}
            loading="lazy"
            decoding="async"
            className="size-full object-contain mix-blend-multiply"
          />
        ) : (
          <div className="grid size-full place-items-center text-[12px] text-stone-400">
            Photo coming
          </div>
        )}
        {!item.sold && Date.now() - item.createdAt < 5 * 864e5 && (
          <span className="absolute right-2 top-2 rounded-md bg-[#e0622a] px-2 py-1 text-[10.5px] font-bold uppercase tracking-wide text-white">
            Just in
          </span>
        )}
        <span
          className={`absolute left-2 top-2 rounded-md px-2 py-1 text-[11px] font-bold text-white ${
            item.sold ? "bg-[#8a94a2]" : (CONDITION_STYLE[item.condition] ?? "bg-[#128a5b]")
          }`}
        >
          {item.sold ? "SOLD" : item.condition}
        </span>
      </div>
      <div className="flex flex-1 flex-col gap-0.5 p-3">
        <h3 className="text-[13.5px] font-semibold leading-snug sm:text-[14.5px]">
          {item.title}
        </h3>
        {item.testedOn && !item.sold && (
          <p className="text-[11.5px] font-semibold text-[#128a5b]">
            Tested {item.testedOn}
            {item.freeDelivery ? " · free delivery" : ""}
          </p>
        )}
        <p className="mt-1 border-b border-stone-200 pb-1.5 text-[17px] font-extrabold tracking-tight sm:text-[19px]">
          {rands(item.price)}
          {item.wasPrice && item.wasPrice > item.price ? (
            <span className="ml-2 text-[13px] font-medium text-stone-400 line-through">
              {rands(item.wasPrice)}
            </span>
          ) : null}
        </p>
      </div>
    </Link>
  );
}

function Empty({ s }: { s: ShopSettings }) {
  return (
    <div className="rounded-2xl border border-dashed border-stone-300 bg-white p-10 text-center">
      <p className="text-[15px] font-bold">Nothing matches that yet</p>
      <p className="mx-auto mt-1.5 max-w-sm text-[13.5px] text-stone-500">
        Stock changes every week. Tell us what you are looking for and we will
        let you know when one comes in.
      </p>
      <a
        href={waLink(s.whatsapp, `Hi ${s.shopName}, I'm looking for an appliance. Can you help?`)}
        target="_blank"
        rel="noreferrer"
        className="mt-4 inline-flex items-center gap-2 rounded-full bg-[#25d366] px-5 py-2.5 text-sm font-bold text-white"
      >
        <WhatsAppIcon /> Tell us what you need
      </a>
    </div>
  );
}

function SellSection({ s }: { s: ShopSettings }) {
  const steps = [
    ["1. Send a photo", "WhatsApp us a picture and tell us what it is."],
    ["2. We test and price it", "We switch it on, check it, and agree a price with you."],
    ["3. It goes on this page", "Photographed and listed, usually the same day."],
    ["4. You get paid", "When it sells. No listing fee, no risk to you."],
  ];
  return (
    <section id="sell" className="mt-12 scroll-mt-32 rounded-2xl border-2 border-[#e0622a]/25 bg-white p-5 shadow-sm sm:p-7">
      <span className="inline-block rounded-full bg-[#e0622a]/10 px-3 py-1 text-[12px] font-bold tracking-wide text-[#e0622a] uppercase">
        Got something to sell? Talk to us
      </span>
      <h2 className="mt-2.5 text-[19px] font-extrabold sm:text-[22px]">
        Selling an appliance?
      </h2>
      <p className="mt-1.5 max-w-2xl text-[14px] leading-relaxed text-stone-600">
        Bring it in or send us a photo. We test it, price it, put it on this page
        and it sells from here.
      </p>
      <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {steps.map(([t, b]) => (
          <div key={t} className="rounded-xl bg-[#f5f7fa] p-4">
            <p className="text-[14px] font-bold">{t}</p>
            <p className="mt-1 text-[13px] leading-relaxed text-stone-600">{b}</p>
          </div>
        ))}
      </div>
      <div className="mt-5 flex flex-wrap items-center gap-2.5">
        <a
          href={waLink(s.whatsapp, `Hi ${s.shopName}, I have an appliance I'd like to sell.`)}
          target="_blank"
          rel="noreferrer"
          className="inline-flex items-center gap-2 rounded-full bg-[#25d366] px-6 py-3 text-sm font-bold text-white shadow-sm transition hover:bg-[#1eb85a] active:scale-95"
        >
          <WhatsAppIcon /> WhatsApp us about your appliance
        </a>
        <a
          href={`tel:${s.phoneDial}`}
          className="inline-flex items-center gap-2 rounded-full border-2 border-[#111820]/15 px-6 py-3 text-sm font-bold text-[#111820] transition hover:border-[#e0622a] hover:text-[#e0622a] active:scale-95"
        >
          <PhoneIcon /> {s.phoneDisplay}
        </a>
      </div>
    </section>
  );
}
