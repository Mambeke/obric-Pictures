import { useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";

function Chevron({ back = false }: { back?: boolean }) {
  return (
    <svg
      viewBox="0 0 24 24"
      className={`size-6 ${back ? "rotate-180" : ""}`}
      fill="none"
      stroke="currentColor"
      strokeWidth={3}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden
    >
      <path d="m9 5 7 7-7 7" />
    </svg>
  );
}

/**
 * Photo gallery: swipe on mobile, big arrows on every screen, dots and
 * thumbnails underneath. Wraps around both ways — past the last photo returns
 * to the first, and back from the first goes to the last.
 */
export function Gallery({ photos, alt }: { photos: string[]; alt: string }) {
  const [index, setIndex] = useState(0);
  const [zoomOpen, setZoomOpen] = useState(false);
  const startX = useRef<number | null>(null);
  const count = photos.length;

  useEffect(() => {
    setIndex(0);
  }, [photos]);

  const go = (dir: number) => {
    if (count === 0) return;
    setIndex(prev => (prev + dir + count) % count);
  };

  if (count === 0) {
    return (
      <div className="flex aspect-[4/5] w-full items-center justify-center rounded-2xl border border-dashed border-sky-200 bg-sky-50/60">
        <div className="text-center">
          <div className="mx-auto grid size-14 place-items-center rounded-2xl bg-white shadow-sm">
            <svg viewBox="0 0 24 24" className="size-7 text-sky-600" fill="currentColor" aria-hidden>
              <path d="M9 3 7.17 5H4a2 2 0 0 0-2 2v11a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2h-3.17L15 3H9zm3 5a5 5 0 1 1 0 10 5 5 0 0 1 0-10z" />
            </svg>
          </div>
          <p className="mt-3 text-sm font-semibold text-slate-800">
            Photo coming
          </p>
          <p className="mt-0.5 text-xs text-sky-700/70">
            WhatsApp us for real pictures of this one
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="select-none">
      <div
        className="group relative aspect-[4/5] w-full overflow-hidden rounded-2xl bg-neutral-100 shadow-sm ring-1 ring-black/5"
        onTouchStart={e => {
          startX.current = e.touches[0].clientX;
        }}
        onTouchEnd={e => {
          if (startX.current === null) return;
          const dx = e.changedTouches[0].clientX - startX.current;
          if (Math.abs(dx) > 40) go(dx < 0 ? 1 : -1);
          startX.current = null;
        }}
      >
        <div
          className="flex h-full w-full transition-transform duration-300 ease-out"
          style={{ transform: `translateX(-${index * 100}%)` }}
        >
          {photos.map(src => (
            /* The blurred copy behind fills the frame edge to edge, while the
               photo itself stays whole — nothing of the phone is cropped. */
            <div key={src} className="relative h-full w-full shrink-0 overflow-hidden">
              <img
                src={src}
                alt=""
                aria-hidden
                draggable={false}
                className="absolute inset-0 h-full w-full scale-110 object-cover blur-2xl brightness-105 saturate-150"
              />
              <img
                src={src}
                alt={alt}
                draggable={false}
                onClick={() => setZoomOpen(true)}
                className="relative h-full w-full cursor-zoom-in object-contain"
              />
            </div>
          ))}
        </div>

        {count > 1 && (
          <>
            <button
              type="button"
              aria-label="Previous photo"
              onClick={() => go(-1)}
              className="absolute left-2.5 top-1/2 grid size-11 -translate-y-1/2 place-items-center rounded-full bg-white text-[#1257d0] shadow-lg ring-1 ring-black/5 transition hover:bg-sky-50 active:scale-90"
            >
              <Chevron back />
            </button>
            <button
              type="button"
              aria-label="Next photo"
              onClick={() => go(1)}
              className="absolute right-2.5 top-1/2 grid size-11 -translate-y-1/2 place-items-center rounded-full bg-white text-[#1257d0] shadow-lg ring-1 ring-black/5 transition hover:bg-sky-50 active:scale-90"
            >
              <Chevron />
            </button>
            <span className="absolute bottom-2 right-2 rounded-full bg-black/55 px-2 py-0.5 text-[11px] font-semibold text-white">
              {index + 1} / {count}
            </span>
          </>
        )}

        <button
          type="button"
          onClick={() => setZoomOpen(true)}
          aria-label="Zoom this photo"
          className="absolute bottom-2 left-2 flex items-center gap-1 rounded-full bg-white/90 px-2.5 py-1 text-[11.5px] font-bold text-[#1257d0] shadow ring-1 ring-black/5 transition hover:bg-white active:scale-95"
        >
          <svg viewBox="0 0 24 24" className="size-3.5" fill="none" stroke="currentColor" strokeWidth={3} strokeLinecap="round" aria-hidden>
            <circle cx="11" cy="11" r="7" />
            <path d="m20 20-3.2-3.2M11 8v6M8 11h6" />
          </svg>
          Zoom
        </button>
      </div>

      {zoomOpen && (
        <Lightbox
          photos={photos}
          alt={alt}
          index={index}
          setIndex={setIndex}
          onClose={() => setZoomOpen(false)}
        />
      )}

      {count > 1 && (
        <>
          <div className="mt-3 flex justify-center gap-1.5">
            {photos.map((src, i) => (
              <button
                key={src}
                type="button"
                aria-label={`Photo ${i + 1}`}
                onClick={() => setIndex(i)}
                className={
                  i === index
                    ? "h-2 w-5 rounded-full bg-[#1257d0] transition-all"
                    : "size-2 rounded-full bg-sky-900/20 transition-all"
                }
              />
            ))}
          </div>
          <div className="mt-3 flex gap-2 overflow-x-auto pb-1">
            {photos.map((src, i) => (
              <button
                key={`t-${src}`}
                type="button"
                onClick={() => setIndex(i)}
                className={`size-16 shrink-0 overflow-hidden rounded-xl bg-white ring-2 transition ${
                  i === index ? "ring-[#1257d0]" : "ring-black/5"
                }`}
              >
                <img src={src} alt="" className="h-full w-full object-cover" />
              </button>
            ))}
          </div>
        </>
      )}
    </div>
  );
}


/**
 * Full-screen photo viewer.
 *
 * On a phone it behaves like the photo app: pinch with two fingers to zoom,
 * drag with one to move around, swipe down to close. No little buttons in the
 * way. On a desktop, where there is no pinching, there are set zoom steps
 * (100–200%) and a plain Close button that puts you back on the same phone,
 * next to the order buttons — not on the home page.
 */
function Lightbox({
  photos,
  alt,
  index,
  setIndex,
  onClose,
}: {
  photos: string[];
  alt: string;
  index: number;
  setIndex: (i: number) => void;
  onClose: () => void;
}) {
  const [scale, setScale] = useState(1);
  const [offset, setOffset] = useState({ x: 0, y: 0 });
  const [touch, setTouch] = useState(false);
  const [easing, setEasing] = useState(true);
  const live = useRef({ scale: 1, x: 0, y: 0 });
  const drag = useRef<{ x: number; y: number; ox: number; oy: number } | null>(
    null,
  );
  const pinch = useRef<{
    dist: number;
    scale: number;
    mx: number;
    my: number;
    ox: number;
    oy: number;
  } | null>(null);
  const stage = useRef<HTMLDivElement | null>(null);
  const img = useRef<HTMLImageElement | null>(null);
  const clamp = (n: number) => Math.min(4, Math.max(1, n));

  // How far the photo may be pushed before its edge would leave the black.
  // Without this the picture slides away into a corner and feels loose.
  const limits = (s: number) => {
    const el = img.current;
    const box = stage.current;
    if (!el || !box) return { x: 0, y: 0 };
    const ratio =
      el.naturalWidth && el.naturalHeight
        ? el.naturalWidth / el.naturalHeight
        : 1;
    const w = Math.min(el.offsetWidth, el.offsetHeight * ratio);
    const h = w / ratio;
    return {
      x: Math.max(0, (w * s - box.clientWidth) / 2),
      y: Math.max(0, (h * s - box.clientHeight) / 2),
    };
  };

  const apply = (s: number, x: number, y: number) => {
    const lim = limits(s);
    const next = {
      scale: s,
      x: s === 1 ? 0 : Math.max(-lim.x, Math.min(lim.x, x)),
      y: s === 1 ? 0 : Math.max(-lim.y, Math.min(lim.y, y)),
    };
    live.current = next;
    setScale(next.scale);
    setOffset({ x: next.x, y: next.y });
  };
  const swipe = useRef<{ y: number } | null>(null);
  const count = photos.length;
  const STEPS = [1, 1.2, 1.4, 1.6, 2];

  useEffect(() => {
    setTouch(
      typeof window !== "undefined" &&
        window.matchMedia("(pointer: coarse)").matches,
    );
  }, []);

  const reset = () => {
    setEasing(true);
    apply(1, 0, 0);
  };
  const go = (dir: number) => {
    setIndex((index + dir + count) % count);
    reset();
  };
  // Button and double-click zoom always works from the middle of the photo,
  // so it never runs off into a corner.
  const zoomTo = (next: number) => {
    setEasing(true);
    apply(clamp(Number(next.toFixed(2))), 0, 0);
  };

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
      if (e.key === "ArrowRight") go(1);
      if (e.key === "ArrowLeft") go(-1);
    };
    window.addEventListener("keydown", onKey);
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = previous;
    };
  });

  // The browser's own pinch and pull-to-refresh have to be switched off, or
  // the page reloads while a customer is trying to look at a phone. React
  // listens passively, so these are wired natively with passive: false.
  useEffect(() => {
    const el = stage.current;
    if (!el) return;

    const spread = (t: TouchList) =>
      Math.hypot(t[0].clientX - t[1].clientX, t[0].clientY - t[1].clientY);
    const middle = (t: TouchList) => ({
      x: (t[0].clientX + t[1].clientX) / 2,
      y: (t[0].clientY + t[1].clientY) / 2,
    });

    const start = (e: TouchEvent) => {
      setEasing(false);
      if (e.touches.length === 2) {
        const m = middle(e.touches);
        pinch.current = {
          dist: spread(e.touches),
          scale: live.current.scale,
          mx: m.x,
          my: m.y,
          ox: live.current.x,
          oy: live.current.y,
        };
        drag.current = null;
        swipe.current = null;
        return;
      }
      if (live.current.scale > 1) {
        drag.current = {
          x: e.touches[0].clientX,
          y: e.touches[0].clientY,
          ox: live.current.x,
          oy: live.current.y,
        };
      } else {
        swipe.current = { y: e.touches[0].clientY };
      }
    };

    const move = (e: TouchEvent) => {
      // Always swallow the gesture inside the viewer.
      e.preventDefault();

      if (e.touches.length === 2 && pinch.current) {
        const p = pinch.current;
        const next = clamp(p.scale * (spread(e.touches) / p.dist));
        const m = middle(e.touches);
        // Keep whatever is between the two fingers under the two fingers,
        // and let the midpoint drift move the photo as well.
        const grow = next / p.scale;
        const box = el.getBoundingClientRect();
        const cx = box.left + box.width / 2;
        const cy = box.top + box.height / 2;
        // The point held between the fingers stays under the fingers. Both
        // the anchor and the midpoint are measured from the middle of the
        // stage, because that is where the photo is scaled from.
        apply(
          next,
          m.x - cx - grow * (p.mx - cx - p.ox),
          m.y - cy - grow * (p.my - cy - p.oy),
        );
        return;
      }
      if (drag.current) {
        const d = drag.current;
        apply(
          live.current.scale,
          d.ox + (e.touches[0].clientX - d.x),
          d.oy + (e.touches[0].clientY - d.y),
        );
      }
    };

    const end = (e: TouchEvent) => {
      if (pinch.current) {
        pinch.current = null;
        drag.current = null;
        if (live.current.scale <= 1.02) {
          setEasing(true);
          apply(1, 0, 0);
        }
        return;
      }
      if (swipe.current) {
        const dy = e.changedTouches[0].clientY - swipe.current.y;
        swipe.current = null;
        if (dy > 110) onClose();
      }
      drag.current = null;
    };

    el.addEventListener("touchstart", start, { passive: false });
    el.addEventListener("touchmove", move, { passive: false });
    el.addEventListener("touchend", end, { passive: false });
    el.addEventListener("touchcancel", end, { passive: false });
    return () => {
      el.removeEventListener("touchstart", start);
      el.removeEventListener("touchmove", move);
      el.removeEventListener("touchend", end);
      el.removeEventListener("touchcancel", end);
    };
  }, [index, onClose]);

  return createPortal(
    <div
      className="fixed inset-0 z-[999] flex flex-col bg-black/95 backdrop-blur-sm"
      role="dialog"
      aria-label="Photo viewer"
    >
      <div className="flex items-center justify-between gap-2 px-3 py-2.5 text-white">
        <span className="hidden truncate text-[13px] font-semibold opacity-80 sm:block">
          {alt}
          {count > 1 ? ` · ${index + 1} / ${count}` : ""}
        </span>

        {/* Always here, on every device — there must never be a moment where
            the only way out is the browser's own back button. */}
        {true && (
          <button
            type="button"
            onClick={onClose}
            className="shrink-0 rounded-full bg-white px-4 py-2 text-[13px] font-bold text-[#0b3f9e] shadow-lg transition hover:bg-sky-50 active:scale-95"
          >
            ← Back to the phone
          </button>
        )}

        {/* Set zoom steps and a clear way out — mouse and keyboard only.
            On a phone the fingers do all of this. */}
        {!touch && (
          <div className="flex shrink-0 items-center gap-1.5">
            {STEPS.map(step => (
              <button
                key={step}
                type="button"
                onClick={() => zoomTo(step)}
                className={`rounded-full px-3 py-1.5 text-[12px] font-bold tabular-nums transition ${
                  Math.abs(scale - step) < 0.05
                    ? "bg-white text-[#0b3f9e]"
                    : "bg-white/15 text-white hover:bg-white/25"
                }`}
              >
                {Math.round(step * 100)}%
              </button>
            ))}
          </div>
        )}
      </div>

      <div
        ref={stage}
        style={{ touchAction: "none", overscrollBehavior: "contain" }}
        className="relative flex-1 overflow-hidden"
        onMouseDown={e => {
          if (scale === 1) return;
          drag.current = {
            x: e.clientX,
            y: e.clientY,
            ox: offset.x,
            oy: offset.y,
          };
        }}
        onMouseMove={e => {
          if (!drag.current) return;
          setEasing(false);
          apply(
            live.current.scale,
            drag.current.ox + (e.clientX - drag.current.x),
            drag.current.oy + (e.clientY - drag.current.y),
          );
        }}
        onMouseUp={() => {
          drag.current = null;
        }}
        onMouseLeave={() => {
          drag.current = null;
        }}
        onDoubleClick={() => zoomTo(scale > 1 ? 1 : 2)}
      >
        {/* Tapping the empty black around the photo closes it too. */}
        <button
          type="button"
          aria-label="Close the photo"
          onClick={onClose}
          className="absolute inset-0 h-full w-full cursor-zoom-out"
        />

        <img
          ref={img}
          src={photos[index]}
          alt={alt}
          draggable={false}
          onClick={e => {
            e.stopPropagation();
            if (!touch && !drag.current) zoomTo(scale > 1 ? 1 : 1.6);
          }}
          style={{
            transform: `translate(${offset.x}px, ${offset.y}px) scale(${scale})`,
            transformOrigin: "50% 50%",
          }}
          className={`pointer-events-auto absolute inset-0 m-auto max-h-full max-w-full select-none object-contain ${
            easing ? "transition-transform duration-200" : ""
          } ${
            scale > 1 ? "cursor-grab" : "cursor-zoom-in"
          }`}
        />

        {count > 1 && scale === 1 && (
          <>
            <button
              type="button"
              aria-label="Previous photo"
              onClick={() => go(-1)}
              className="absolute left-3 top-1/2 grid size-12 -translate-y-1/2 place-items-center rounded-full bg-white/90 text-[#1257d0] shadow-lg transition active:scale-90"
            >
              <Chevron back />
            </button>
            <button
              type="button"
              aria-label="Next photo"
              onClick={() => go(1)}
              className="absolute right-3 top-1/2 grid size-12 -translate-y-1/2 place-items-center rounded-full bg-white/90 text-[#1257d0] shadow-lg transition active:scale-90"
            >
              <Chevron />
            </button>
          </>
        )}
      </div>

      {touch ? (
        <p className="px-4 pb-5 pt-2 text-center text-[12px] text-white/60">
          Pinch with two fingers to zoom · drag to move · swipe down or tap Back
        </p>
      ) : (
        <div className="flex justify-center px-4 pb-5 pt-2">
          <button
            type="button"
            onClick={onClose}
            className="rounded-full bg-white/15 px-5 py-2.5 text-[13px] font-bold text-white transition hover:bg-white/25"
          >
            ← Back to the price and order buttons
          </button>
        </div>
      )}
    </div>,
    document.body,
  );
}
