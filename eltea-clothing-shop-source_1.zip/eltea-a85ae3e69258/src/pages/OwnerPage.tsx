import { useAuthActions } from "@convex-dev/auth/react";
import { useMutation, useQuery } from "convex/react";
import { useState } from "react";
import { useNavigate } from "react-router";
import { toast } from "sonner";
import { api } from "../../convex/_generated/api";
import { CAT_ORDER, money, type Piece, type Settings } from "@/shop/lib";
import "@/shop/shop.css";

const CONDITIONS = [
  "Brand new with tags",
  "Like new",
  "Excellent",
  "Excellent — worn twice",
  "Very good",
  "Good",
];

type Shot = { id: string; url: string; ref?: string; file?: File };

const empty = {
  name: "",
  brand: "",
  price: "",
  wasPrice: "",
  section: "Ladies",
  category: "Dresses",
  state: "Pre-owned",
  size: "",
  cond: "Excellent",
  meas: "",
  desc: "",
  badge: "",
};

export function OwnerPage() {
  const nav = useNavigate();
  const { signOut } = useAuthActions();
  const owner = useQuery(api.shop.amIOwner) as
    | { isOwner: boolean; email: string | null }
    | undefined;
  const pieces = useQuery(api.shop.listAllPieces, owner?.isOwner ? {} : "skip") as
    | Piece[]
    | undefined;
  const settings = useQuery(api.shop.getSettings) as Settings | undefined;
  const cats = useQuery(api.shop.listCategories) as
    | { _id: string | null; name: string; section: string }[]
    | undefined;

  const uploadUrl = useMutation(api.shop.generateUploadUrl);
  const addPiece = useMutation(api.shop.addPiece);
  const updatePiece = useMutation(api.shop.updatePiece);
  const setSold = useMutation(api.shop.setSold);
  const deletePiece = useMutation(api.shop.deletePiece);
  const addCategory = useMutation(api.shop.addCategory);
  const saveSettings = useMutation(api.shop.saveSettings);
  const loadDemo = useMutation(api.shop.loadDemoStock);
  const clearDemo = useMutation(api.shop.clearDemoStock);

  const [form, setForm] = useState({ ...empty });
  const [shots, setShots] = useState<Shot[]>([]);
  const [dragFrom, setDragFrom] = useState<number | null>(null);
  const [stockTab, setStockTab] = useState<"live" | "sold">("live");
  const [q, setQ] = useState("");
  const [fSection, setFSection] = useState("All");
  const [fCat, setFCat] = useState("All");
  const [fState, setFState] = useState("All");
  const [editing, setEditing] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [dropping, setDropping] = useState(false);
  const [newCat, setNewCat] = useState("");
  const [tab, setTab] = useState<"add" | "stock" | "shop">("add");
  const [s, setS] = useState<Settings | null>(null);

  if (owner === undefined) return <div className="adminwrap"><div className="panel">Opening your owner panel…</div></div>;
  if (!owner?.isOwner) {
    return (
      <div className="adminwrap">
        <div className="panel">
          <h2>Not your shop</h2>
          <div className="small">
            You are signed in as {owner?.email ?? "someone else"}, which is not an owner account for
            this shop.
          </div>
          <button type="button" className="adminbtn" onClick={() => void signOut()}>
            Sign out
          </button>
        </div>
      </div>
    );
  }

  const set = (k: string, v: string) => setForm(f => ({ ...f, [k]: v }));

  function addFiles(fl: FileList | null) {
    const list = Array.from(fl ?? []);
    if (!list.length) return;
    setShots(a => [
      ...a,
      ...list.map((file, n) => ({
        id: `${Date.now()}-${n}-${file.name}`,
        url: URL.createObjectURL(file),
        file,
      })),
    ]);
  }

  function move(from: number | null, to: number) {
    if (from === null || from === to) return;
    setShots(a => {
      const out = [...a];
      const [x] = out.splice(from, 1);
      out.splice(to, 0, x);
      return out;
    });
  }

  async function submit() {
    if (!form.name || !form.brand || !form.price) {
      toast.error("Give it at least a name, a brand and a price.");
      return;
    }
    setBusy(true);
    try {
      const photos: string[] = [];
      for (const sh of shots) {
        if (sh.file) {
          const url = await uploadUrl();
          const res = await fetch(url, { method: "POST", body: sh.file });
          const { storageId } = (await res.json()) as { storageId: string };
          photos.push(storageId);
        } else if (sh.ref) {
          photos.push(sh.ref);
        }
      }
      const payload = {
        name: form.name,
        brand: form.brand,
        price: Number(form.price),
        wasPrice: form.wasPrice ? Number(form.wasPrice) : undefined,
        section: form.section,
        category: form.category,
        state: form.state,
        size: form.size,
        cond: form.cond,
        meas: form.meas,
        desc: form.desc,
        badge: form.badge,
      };
      if (editing) {
        const old = pieces?.find(p => p._id === editing);
        await updatePiece({
          id: editing as never,
          ...payload,
          photos: photos.length ? photos : (old?.photos ?? []),
        });
        toast.success("Piece updated.");
        setEditing(null);
      } else {
        if (photos.length === 0) {
          toast.error("Add a photo — the shop lives on the photos.");
          setBusy(false);
          return;
        }
        await addPiece({ ...payload, photos });
        toast.success("It is on the rail.");
      }
      setForm({ ...empty });
      setShots([]);
    } catch (e) {
      toast.error(String(e));
    }
    setBusy(false);
  }

  function edit(p: Piece) {
    setEditing(p._id);
    setTab("add");
    setShots(
      p.photos.map((ref, n) => ({ id: `${p._id}-${n}`, ref, url: p.photoUrls[n] ?? ref })),
    );
    setForm({
      name: p.name,
      brand: p.brand,
      price: String(p.price),
      wasPrice: p.wasPrice ? String(p.wasPrice) : "",
      section: p.section,
      category: p.category,
      state: p.state,
      size: p.size,
      cond: p.cond,
      meas: p.meas ?? "",
      desc: p.desc ?? "",
      badge: p.badge ?? "",
    });
    window.scrollTo(0, 0);
  }

  const catNames = [...new Set([...CAT_ORDER, ...(cats ?? []).map(c => c.name)])];
  const allPieces = pieces ?? [];
  const live = allPieces.filter(p => !p.sold);
  const soldList = allPieces.filter(p => p.sold);
  const qq = q.trim().toLowerCase();
  const shown = (stockTab === "sold" ? soldList : live).filter(
    p =>
      (fSection === "All" || p.section === fSection) &&
      (fCat === "All" || p.category === fCat) &&
      (fState === "All" || p.state === fState) &&
      (!qq ||
        `${p.brand} ${p.name} ${p.size} ${p.category} ${p.section} ${p.state}`
          .toLowerCase()
          .includes(qq)),
  );
  const conf = s ?? settings ?? null;

  return (
    <div className="adminwrap">
      <div className="ownerbar">
        <b>{settings?.shopName ?? "Your shop"}</b>
        <span className="obtag">owner panel</span>
        <div className="sp" />
        <button type="button" className="back ownerbtn" onClick={() => nav("/")}>
          View the shop
        </button>
        <button type="button" className="back ownerbtn" onClick={() => void signOut()}>
          Sign out
        </button>
      </div>

      <div className="ownertabs">
        {(["add", "stock", "shop"] as const).map(t => (
          <button
            key={t}
            type="button"
            className={`tab${tab === t ? " on" : ""}`}
            onClick={() => setTab(t)}
          >
            {t === "add" ? (editing ? "Edit piece" : "Add a piece") : t === "stock" ? `My stock (${pieces?.length ?? 0})` : "Shop settings"}
          </button>
        ))}
      </div>

      {tab === "add" && (
        <div className="panel">
          <h2>{editing ? "Edit this piece" : "Add a piece"}</h2>
          <div className="small">
            Everything the customer sees is built from this one form. About 40 seconds per item.
          </div>
          <div className="fld">
            <label>Photos</label>
            {shots.length > 0 && (
              <div className="shots">
                {shots.map((sh, n) => (
                  <div
                    key={sh.id}
                    className={`shot${n === 0 ? " cover" : ""}${dragFrom === n ? " lifting" : ""}`}
                    draggable
                    onDragStart={() => setDragFrom(n)}
                    onDragOver={e => e.preventDefault()}
                    onDrop={e => {
                      e.preventDefault();
                      move(dragFrom, n);
                      setDragFrom(null);
                    }}
                    onDragEnd={() => setDragFrom(null)}
                    onTouchStart={() => setDragFrom(n)}
                    onTouchMove={e => {
                      const t = e.touches[0];
                      const el = document
                        .elementFromPoint(t.clientX, t.clientY)
                        ?.closest("[data-shot]") as HTMLElement | null;
                      const to = el ? Number(el.dataset.shot) : -1;
                      if (to >= 0 && dragFrom !== null && to !== dragFrom) {
                        move(dragFrom, to);
                        setDragFrom(to);
                      }
                    }}
                    onTouchEnd={() => setDragFrom(null)}
                    data-shot={n}
                  >
                    <img src={sh.url} alt={`Photo ${n + 1}`} />
                    {n === 0 && <span className="ctag">COVER</span>}
                    <div className="sacts">
                      {n !== 0 && (
                        <button type="button" onClick={() => move(n, 0)}>
                          Make cover
                        </button>
                      )}
                      <button
                        type="button"
                        className="x"
                        onClick={() => setShots(a => a.filter((_, k) => k !== n))}
                      >
                        Remove
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
            <label
              className={`dz${dropping ? " on" : ""}`}
              onDragOver={e => {
                e.preventDefault();
                setDropping(true);
              }}
              onDragLeave={() => setDropping(false)}
              onDrop={e => {
                e.preventDefault();
                setDropping(false);
                addFiles(e.dataTransfer.files);
              }}
            >
              <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2.4} strokeLinecap="round" strokeLinejoin="round" aria-hidden>
                <path d="M12 16V4m0 0L7.5 8.5M12 4l4.5 4.5" />
                <path d="M4 16v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2" />
              </svg>
              <span>
                {dropping
                  ? "Drop the photos here"
                  : shots.length
                    ? "Add another photo — tap to choose or drag and drop"
                    : "Tap to choose or drag and drop the photos here"}
              </span>
              <input
                type="file"
                accept="image/*"
                multiple
                onChange={e => {
                  addFiles(e.target.files);
                  e.target.value = "";
                }}
              />
            </label>
            <div className="small">
              On a phone this opens the camera. Add as many photos as you like — drag a thumbnail to
              the front to make it the cover photo the customer sees first.
            </div>
          </div>
          <div className="two">
            <div className="fld">
              <label>Brand / label</label>
              <input value={form.brand} onChange={e => set("brand", e.target.value)} placeholder="Zara" />
            </div>
            <div className="fld">
              <label>Price (USD)</label>
              <input
                type="number"
                value={form.price}
                onChange={e => set("price", e.target.value)}
                placeholder="14"
              />
            </div>
          </div>
          <div className="fld">
            <label>What is it</label>
            <input
              value={form.name}
              onChange={e => set("name", e.target.value)}
              placeholder="Floral summer midi dress"
            />
          </div>
          <div className="two">
            <div className="fld">
              <label>Section</label>
              <select value={form.section} onChange={e => set("section", e.target.value)}>
                {["Ladies", "Men", "Kids"].map(x => (
                  <option key={x}>{x}</option>
                ))}
              </select>
            </div>
            <div className="fld">
              <label>Category</label>
              <select value={form.category} onChange={e => set("category", e.target.value)}>
                {catNames.map(x => (
                  <option key={x}>{x}</option>
                ))}
              </select>
            </div>
          </div>
          <div className="two">
            <div className="fld">
              <label>New or pre-owned</label>
              <select value={form.state} onChange={e => set("state", e.target.value)}>
                <option>Pre-owned</option>
                <option>New</option>
              </select>
            </div>
            <div className="fld">
              <label>Size</label>
              <input value={form.size} onChange={e => set("size", e.target.value)} placeholder="M / 34 / 8" />
            </div>
          </div>
          <div className="two">
            <div className="fld">
              <label>Condition</label>
              <select value={form.cond} onChange={e => set("cond", e.target.value)}>
                {CONDITIONS.map(c => (
                  <option key={c}>{c}</option>
                ))}
              </select>
            </div>
            <div className="fld">
              <label>Was price (optional)</label>
              <input
                type="number"
                value={form.wasPrice}
                onChange={e => set("wasPrice", e.target.value)}
                placeholder="18"
              />
            </div>
          </div>
          <div className="fld">
            <label>Measurements</label>
            <input
              value={form.meas}
              onChange={e => set("meas", e.target.value)}
              placeholder="Chest 102cm · Sleeve 63cm"
            />
            <div className="small">
              How the customer checks it will fit. Clothes: chest, waist, length in cm. Shoes: just
              the shoe size, e.g. "UK 8" or "UK 1 child".
            </div>
          </div>
          <div className="fld">
            <label>Description (optional)</label>
            <textarea
              value={form.desc}
              onChange={e => set("desc", e.target.value)}
              placeholder="Say anything the photo does not show — fabric, small marks, how it fits."
            />
          </div>
          <div className="fld">
            <label>Corner badge (optional)</label>
            <select value={form.badge} onChange={e => set("badge", e.target.value)}>
              <option value="">No badge</option>
              <option>NEW IN</option>
              <option>SALE</option>
              <option>BEST SELLER</option>
            </select>
          </div>
          <div className="btnline">
            <button type="button" className="adminbtn" disabled={busy} onClick={() => void submit()}>
              {busy ? "Working…" : editing ? "Save changes" : "Put it on the rail"}
            </button>
            {editing && (
              <button
                type="button"
                className="adminbtn ghost"
                onClick={() => {
                  setEditing(null);
                  setForm({ ...empty });
                  setShots([]);
                }}
              >
                Cancel
              </button>
            )}
          </div>

          <hr style={{ border: 0, borderTop: "1px solid var(--line)", margin: "20px 0" }} />
          <h2>My categories</h2>
          <div className="small">
            Add your own — hair, nails, wigs, perfume, anything. It becomes a tab in the shop.
          </div>
          <div className="two">
            <div className="fld">
              <label>New category</label>
              <input value={newCat} onChange={e => setNewCat(e.target.value)} placeholder="Hair" />
            </div>
            <div className="fld">
              <label>&nbsp;</label>
              <button
                type="button"
                className="adminbtn"
                onClick={() => {
                  if (!newCat.trim()) return;
                  void addCategory({ name: newCat, section: "All" }).then(() => {
                    toast.success("Category added.");
                    setNewCat("");
                  });
                }}
              >
                Add category tab
              </button>
            </div>
          </div>
          <div className="tagrow">
            {catNames.map(c => (
              <span key={c} className="tag">
                {c}
              </span>
            ))}
          </div>
        </div>
      )}

      {tab === "stock" && (
        <div className="panel">
          <h2>My stock</h2>
          <div className="small">
            Search it, filter it, edit a piece, or mark it sold so it comes off the shop. Sold
            pieces move to the Sold tab — put them back any time.
          </div>

          <div className="stocktabs">
            <button
              type="button"
              className={`stab${stockTab === "live" ? " on" : ""}`}
              onClick={() => setStockTab("live")}
            >
              On the shop ({live.length})
            </button>
            <button
              type="button"
              className={`stab sold${stockTab === "sold" ? " on" : ""}`}
              onClick={() => setStockTab("sold")}
            >
              Sold ({soldList.length})
            </button>
          </div>

          <div className="stockfilters">
            <input
              className="ssearch"
              value={q}
              onChange={e => setQ(e.target.value)}
              placeholder="Search brand, name, size…"
            />
            <select value={fSection} onChange={e => setFSection(e.target.value)}>
              <option value="All">All sections</option>
              {["Ladies", "Men", "Kids"].map(x => (
                <option key={x}>{x}</option>
              ))}
            </select>
            <select value={fCat} onChange={e => setFCat(e.target.value)}>
              <option value="All">All categories</option>
              {catNames.map(x => (
                <option key={x}>{x}</option>
              ))}
            </select>
            <select value={fState} onChange={e => setFState(e.target.value)}>
              <option value="All">New &amp; pre-owned</option>
              {["New", "Pre-owned"].map(x => (
                <option key={x}>{x}</option>
              ))}
            </select>
            {(q || fSection !== "All" || fCat !== "All" || fState !== "All") && (
              <button
                type="button"
                className="sclear"
                onClick={() => {
                  setQ("");
                  setFSection("All");
                  setFCat("All");
                  setFState("All");
                }}
              >
                Clear
              </button>
            )}
          </div>
          <div className="small">
            {shown.length} {shown.length === 1 ? "piece" : "pieces"} shown
          </div>

          {(pieces ?? []).length === 0 && (
            <button type="button" className="adminbtn" onClick={() => void loadDemo().then(r => toast.success(r.note))}>
              Load the 50-piece demo rail
            </button>
          )}
          <div className="stocklist">
            {shown.map(p => (
              <div key={p._id} className={`srow${p.sold ? " sold" : ""}`}>
                <img src={p.photoUrls[0]} alt={p.name} />
                <div className="t">
                  <b>{p.brand}</b>
                  {p.name}
                  <br />
                  {p.section} · {p.category} · {p.state} · size {p.size} · {money(p.price)}
                  {p.photoUrls.length > 1 ? ` · ${p.photoUrls.length} photos` : ""}
                  {p.sold ? " · SOLD" : ""}
                </div>
                <div className="acts">
                  <button type="button" className="sbtn edit" onClick={() => edit(p)}>
                    Edit
                  </button>
                  <button
                    type="button"
                    className="sbtn sold"
                    onClick={() => void setSold({ id: p._id as never, sold: !p.sold })}
                  >
                    {p.sold ? "Put back" : "Mark sold"}
                  </button>
                  <button
                    type="button"
                    className="sbtn del"
                    onClick={() => {
                      if (confirm(`Delete "${p.name}" for good?`)) void deletePiece({ id: p._id as never });
                    }}
                  >
                    Delete
                  </button>
                </div>
              </div>
            ))}
            {shown.length === 0 && (pieces ?? []).length > 0 && (
              <div className="small" style={{ padding: "14px 0" }}>
                Nothing matches that. Try clearing the filters.
              </div>
            )}
          </div>
          {(pieces ?? []).some(p => p.demo) && (
            <button
              type="button"
              className="adminbtn"
              style={{ background: "var(--ink)" }}
              onClick={() => void clearDemo().then(r => toast.success(`${r.removed} demo pieces removed.`))}
            >
              Remove all demo pieces
            </button>
          )}
        </div>
      )}

      {tab === "shop" && conf && (
        <div className="panel">
          <h2>Shop settings</h2>
          <div className="small">Change the name, the WhatsApp number, the moving ribbon and delivery fees.</div>
          <div className="two">
            <div className="fld">
              <label>Shop name</label>
              <input value={conf.shopName} onChange={e => setS({ ...conf, shopName: e.target.value })} />
            </div>
            <div className="fld">
              <label>WhatsApp number (digits only)</label>
              <input value={conf.whatsapp} onChange={e => setS({ ...conf, whatsapp: e.target.value })} />
            </div>
          </div>
          <div className="fld">
            <label>Footer line</label>
            <input value={conf.footerLine} onChange={e => setS({ ...conf, footerLine: e.target.value })} />
          </div>
          <div className="fld">
            <label>Moving ribbon — one line each</label>
            <textarea
              rows={6}
              value={conf.ribbon.join("\n")}
              onChange={e => setS({ ...conf, ribbon: e.target.value.split("\n") })}
            />
          </div>
          <div className="fld">
            <label>Delivery towns — town, fee, days</label>
            <textarea
              rows={7}
              value={conf.deliveryTowns.map(t => `${t.town}, ${t.fee}, ${t.days}`).join("\n")}
              onChange={e =>
                setS({
                  ...conf,
                  deliveryTowns: e.target.value
                    .split("\n")
                    .map(l => l.split(","))
                    .filter(p => p[0]?.trim())
                    .map(p => ({
                      town: p[0].trim(),
                      fee: Number(p[1] ?? 5) || 0,
                      days: Number(p[2] ?? 4) || 2,
                    })),
                })
              }
            />
          </div>
          <button
            type="button"
            className="adminbtn"
            onClick={() =>
              void saveSettings({
                shopName: conf.shopName,
                whatsapp: conf.whatsapp.replace(/\D/g, ""),
                footerLine: conf.footerLine,
                ribbon: conf.ribbon.filter(Boolean),
                deliveryTowns: conf.deliveryTowns,
                laybyeEnabled: conf.laybyeEnabled,
                laybyeMinPrice: conf.laybyeMinPrice,
                laybyeMonths: conf.laybyeMonths,
              }).then(() => toast.success("Saved. The shop updates straight away."))
            }
          >
            Save settings
          </button>
        </div>
      )}
    </div>
  );
}
