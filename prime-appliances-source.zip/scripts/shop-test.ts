import { runTest } from "./auth";

runTest("Prime Appliances storefront", async helper => {
  const { page } = helper;
  await helper.goto("/");

  await page.waitForSelector("text=Defy 235L double door fridge", { timeout: 20000 });

  // Sold stock must not sit among the live stock.
  const soldBadges = await page.locator("span:text-is('SOLD')").count();
  if (soldBadges > 0 && (await page.locator("text=Recently sold").count()) === 0) {
    throw new Error("Sold items are showing without the sold shelf");
  }

  // Forgiving search: a misspelling and a glued word must still find things.
  await page.fill("input[aria-label='Search appliances']", "washingmachine");
  await page.waitForTimeout(600);
  if (!(await page.locator("text=Samsung 7kg front loader").isVisible())) {
    throw new Error("Search 'washingmachine' did not find the washing machine");
  }

  await page.fill("input[aria-label='Search appliances']", "");
  await page.waitForTimeout(400);

  // Category pill filters.
  await page.click("button:has-text('Microwaves')");
  await page.waitForTimeout(600);
  if (await page.locator("text=Defy 235L double door fridge").isVisible()) {
    throw new Error("Category filter did not narrow the grid");
  }

  // Item page.
  await page.click("button:has-text('All')");
  await page.waitForTimeout(500);
  await page.click("text=Defy 235L double door fridge");
  await page.waitForSelector("text=WhatsApp about this one", { timeout: 15000 });
  const specs = await page.locator("text=235 litres").count();
  if (specs === 0) throw new Error("Specs missing on the item page");
  if (!(await page.locator("text=Tested on").isVisible())) {
    throw new Error("Tested-on line missing on the item page");
  }

  // No sideways scroll on a phone.
  await page.setViewportSize({ width: 375, height: 812 });
  await helper.goto("/");
  await page.waitForTimeout(1200);
  const [sw, cw] = await page.evaluate(() => [
    document.documentElement.scrollWidth,
    document.documentElement.clientWidth,
  ]);
  if (sw > cw) throw new Error(`Page overflows sideways on mobile: ${sw} > ${cw}`);

  console.log("storefront ok");
}).catch(() => process.exit(1));
