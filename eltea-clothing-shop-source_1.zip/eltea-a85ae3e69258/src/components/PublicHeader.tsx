import { Link, useLocation } from "react-router";
import { APP_NAME } from "@/lib/constants";

export function PublicHeader() {
  const location = useLocation();
  const isAuthPage =
    location.pathname === "/login" || location.pathname === "/signup";

  return (
    <header className="sticky top-0 z-50 border-b bg-background/80 backdrop-blur-md">
      <div className="container">
        <div className="flex h-16 items-center justify-between">
          <Link
            to="/"
            className="flex items-center gap-2.5 font-semibold text-lg hover:opacity-80 transition-opacity"
          >
            <span
              className="size-2.5 rounded-full"
              style={{ background: "#c2185b", boxShadow: "0 0 0 4px rgba(194,24,91,.16)" }}
            />
            <span style={{ fontFamily: "Fraunces, Georgia, serif", color: "#181017" }}>
              {APP_NAME}
            </span>
          </Link>

          <nav className="flex items-center gap-2">
            {isAuthPage ? null : null}
          </nav>
        </div>
      </div>
    </header>
  );
}
