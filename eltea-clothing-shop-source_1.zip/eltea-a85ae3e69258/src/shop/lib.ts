export type Piece = {
  _id: string;
  name: string;
  brand: string;
  price: number;
  wasPrice?: number;
  section: string;
  category: string;
  state: string;
  size: string;
  cond: string;
  meas?: string;
  desc?: string;
  badge?: string;
  photos: string[];
  photoUrls: string[];
  sold?: boolean;
  demo?: boolean;
  createdAt: number;
};

export type Settings = {
  shopName: string;
  whatsapp: string;
  footerLine: string;
  ribbon: string[];
  deliveryTowns: { town: string; fee: number; days: number }[];
  laybyeEnabled: boolean;
  laybyeMinPrice: number;
  laybyeMonths: number;
};

export const money = (n: number) => `$${n}`;

export const SECTIONS = ["All", "Ladies", "Men", "Kids"];
export const STATES = ["New", "Pre-owned"];
export const CAT_ORDER = [
  "Dresses",
  "Tops",
  "Shirts",
  "Jeans & trousers",
  "Skirts",
  "Jackets",
  "Tracksuits",
  "Shoes",
  "Bags",
];

export const PRICE_BANDS: [string, number, number][] = [
  ["All", 0, 1e9],
  ["Under $10", 0, 9.99],
  ["$10–20", 10, 20],
  ["$20–35", 20, 35],
  ["Over $35", 35, 1e9],
];
export const SORTS = ["New first", "Price low to high", "Price high to low"];

export const SEARCH_HINTS = [
  "dress",
  "size 34 jeans",
  "Nike",
  "men's shoes size 8",
  "tote bag",
  "kids hoodie",
  "leather jacket",
  "medium blouse",
  "new tracksuit",
];

/* ------------------------- forgiving search ------------------------- */

export function lev(a: string, b: string): number {
  const m = a.length;
  const n = b.length;
  if (Math.abs(m - n) > 2) return 9;
  let prev = Array.from({ length: n + 1 }, (_, j) => j);
  for (let i = 1; i <= m; i++) {
    const cur = [i];
    for (let j = 1; j <= n; j++) {
      cur[j] = Math.min(
        prev[j] + 1,
        cur[j - 1] + 1,
        prev[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1),
      );
    }
    prev = cur;
  }
  return prev[n];
}

const hay = (p: Piece) =>
  `${p.name} ${p.brand} ${p.section} ${p.category} ${p.state} ${p.size} ${p.cond}`.toLowerCase();

function near(word: string, text: string) {
  if (text.includes(word)) return true;
  const tol = word.length <= 4 ? 1 : 2;
  return text.split(/[^a-z0-9]+/).some(w => w && lev(word, w) <= tol);
}

export function matchTerm(p: Piece, t: string) {
  if (!t) return true;
  const h = hay(p);
  return t
    .split(/\s+/)
    .filter(Boolean)
    .every(w => near(w, h));
}

/** "shors" -> "shoes": the closest word that actually exists in the stock. */
export function suggest(term: string, pieces: Piece[]): string | null {
  const words = new Set<string>();
  for (const p of pieces) {
    for (const w of hay(p).split(/[^a-z0-9]+/)) if (w.length > 2) words.add(w);
  }
  const arr = [...words];
  let changed = false;
  const out = term
    .split(/\s+/)
    .filter(Boolean)
    .map(w => {
      if (arr.some(x => x.includes(w))) return w;
      let best: string | null = null;
      let bd = 9;
      for (const x of arr) {
        const d = lev(w, x);
        if (d < bd) {
          bd = d;
          best = x;
        }
      }
      if (best && bd <= (w.length <= 4 ? 1 : 2)) {
        changed = true;
        return best;
      }
      return w;
    })
    .join(" ");
  return changed ? out : null;
}

export function sortSizes(sizes: string[]) {
  const ORD = ["XS", "S", "M", "L", "XL", "XXL", "One size"];
  return [...sizes].sort((a, b) => {
    const ia = ORD.indexOf(a);
    const ib = ORD.indexOf(b);
    if (ia > -1 || ib > -1) return (ia > -1 ? ia : 99) - (ib > -1 ? ib : 99);
    const na = Number.parseFloat(a);
    const nb = Number.parseFloat(b);
    if (!Number.isNaN(na) && !Number.isNaN(nb)) return na - nb;
    return a.localeCompare(b);
  });
}

/* --------------------------- WhatsApp --------------------------- */

const SIZEWORD: Record<string, string> = {
  XS: "Extra small",
  S: "Small",
  M: "Medium",
  L: "Large",
  XL: "Extra large",
  XXL: "2XL",
};
export const sizeWord = (s: string) => SIZEWORD[s] ?? s;

export function waLink(number: string, message: string) {
  return `https://wa.me/${number}?text=${encodeURIComponent(message)}`;
}

export function deliveryDate(days: number) {
  const d = new Date();
  let left = days;
  while (left > 0) {
    d.setDate(d.getDate() + 1);
    if (d.getDay() !== 0) left--; // no Sunday deliveries
  }
  return d.toLocaleDateString("en-GB", {
    weekday: "long",
    day: "numeric",
    month: "long",
  });
}

export function orderMessage(
  shopName: string,
  p: Piece,
  delivery: { town: string; fee: number; days: number } | null,
) {
  const tail = delivery
    ? `. Delivery : Yes I am in ${delivery.town} + $${delivery.fee}  (latest delivery date ${deliveryDate(delivery.days)})\n. Total with delivery : $${p.price + delivery.fee}`
    : `. Delivery : No, I will collect\n. Total : $${p.price}`;
  return `Hi ${shopName}, I want this piece:\n. ${p.name} : ${p.brand}\n. Size : ${sizeWord(p.size)}\n. Price : $${p.price}\n${tail}`;
}

export function holdMessage(shopName: string, p: Piece) {
  return `Hi ${shopName}, please hold this for me for 24 hours:\n. ${p.name} : ${p.brand}\n. Size : ${sizeWord(p.size)}\n. Price : $${p.price}`;
}

export function cartMessage(shopName: string, items: Piece[]) {
  const lines = items
    .map(
      p =>
        `. ${p.name} : ${p.brand}\n. Size : ${sizeWord(p.size)}\n. Price : $${p.price}`,
    )
    .join("\n\n");
  const total = items.reduce((s, p) => s + p.price, 0);
  return `Hi ${shopName}, I would like these:\n${lines}\n\n. Total : $${total}\n. My area : `;
}

/**
 * Shop-front wording for a condition string.
 * Buyers do not want to read that a piece was "worn" — we say how it was
 * prepared instead. Applied at display time so it also fixes stock that is
 * already in the database.
 */
export function prettyCond(cond: string) {
  const c = (cond || "").trim();
  if (!c) return "";
  if (/worn|used|second[- ]?hand/i.test(c)) {
    const grade = c.split(/[—–\-·,]/)[0].trim() || "Excellent";
    return `${grade} · cleaned & pressed`;
  }
  return c;
}
