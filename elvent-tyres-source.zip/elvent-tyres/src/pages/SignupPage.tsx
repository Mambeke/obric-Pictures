import { useAuthActions } from "@convex-dev/auth/react";
import { useState } from "react";
import { Link, useNavigate, useSearchParams } from "react-router";
import "../shop.css";
import { PasswordField } from "@/components/PasswordField";

/**
 * Staff sign-up, styled like the shop. See LoginPage for why.
 *
 * Two steps, because the backend emails a verification code before the
 * account becomes usable. The first version of this page ignored that: it
 * created the account, showed no error, and left the owner unable to sign in
 * while the site insisted the email was already registered. Do not drop the
 * code step.
 */
export function SignupPage() {
  const { signIn } = useAuthActions();
  const navigate = useNavigate();
  // The owner's invite link carries the address it was issued for and a
  // signature proving he issued it. Both travel with the sign-up form.
  const [search] = useSearchParams();
  const invite = search.get("i") ?? "";
  const invitedEmail = search.get("e") ?? "";
  const [step, setStep] = useState<"details" | "code">("details");
  const [email, setEmail] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function createAccount(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError("");
    const form = new FormData(e.currentTarget);
    const pw = String(form.get("password") ?? "");
    if (pw !== String(form.get("password2") ?? "")) {
      setError("Those two passwords are not the same. Tap Show to check them.");
      return;
    }
    form.delete("password2");
    form.set("flow", "signUp");
    if (invite) form.set("invite", invite);
    const addr = String(form.get("email") ?? "").trim();
    setLoading(true);
    try {
      const result = await signIn("password", form);
      setEmail(addr);
      // signingIn false means the backend wants an emailed code first
      if (result?.signingIn) navigate("/admin");
      else setStep("code");
    } catch {
      setError(
        invite
          ? "Could not create that account. This email may already be registered — try Sign in. If you forgot the password, ask the shop owner to wipe it for you."
          : "Could not create that account. Staff accounts need an invite link from the shop owner.",
      );
    } finally {
      setLoading(false);
    }
  }

  async function submitCode(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError("");
    const form = new FormData(e.currentTarget);
    form.set("email", email);
    form.set("flow", "email-verification");
    setLoading(true);
    try {
      await signIn("password", form);
      navigate("/admin");
    } catch {
      setError(
        "That code was wrong or has expired. Codes last 15 minutes — start again to get a new one.",
      );
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="adm">
      <div className="admbar">
        <div className="wrap">
          <Link to="/" className="logo">
            <span className="ring">E</span>
            <b>
              ELVENT <i>TYRES</i>
            </b>
          </Link>
          <Link to="/" className="lnk" style={{ marginLeft: "auto" }}>
            View shop
          </Link>
        </div>
      </div>

      <div className="loginwrap">
        <div className="panel">
          {step === "details" ? (
            <>
              <h2>Create your staff account</h2>
              <p className="hint" style={{ marginTop: -8, marginBottom: 16 }}>
                {invite
                  ? "You were invited by the shop owner. Pick a password you will remember — nobody else can see it, not even him."
                  : "Staff accounts are created from an invite link sent by the shop owner."}
              </p>

              <form onSubmit={createAccount}>
                <div className="field" style={{ marginBottom: 14 }}>
                  <label htmlFor="email">Email</label>
                  <input
                    id="email"
                    name="email"
                    type="email"
                    autoComplete="email"
                    placeholder="you@example.com"
                    defaultValue={invitedEmail}
                    readOnly={Boolean(invite && invitedEmail)}
                    required
                  />
                </div>

                <PasswordField
                  id="password"
                  name="password"
                  label="Password"
                  placeholder="At least 8 characters"
                  autoComplete="new-password"
                />
                <PasswordField
                  id="password2"
                  name="password2"
                  label="Type it again"
                  placeholder="The same password"
                  autoComplete="new-password"
                />

                {error && <div className="formerr">{error}</div>}

                <button type="submit" className="pbtn wide" disabled={loading}>
                  {loading ? "Creating…" : "Create account"}
                </button>
              </form>
            </>
          ) : (
            <>
              <h2>Check your email</h2>
              <p className="hint" style={{ marginTop: -8, marginBottom: 16 }}>
                We sent a code to <b>{email}</b>. Enter it to finish. Check spam
                if it's not there in a minute.
              </p>

              <form onSubmit={submitCode}>
                <div className="field" style={{ marginBottom: 16 }}>
                  <label htmlFor="code">Code from the email</label>
                  <input
                    id="code"
                    name="code"
                    inputMode="numeric"
                    autoComplete="one-time-code"
                    placeholder="12345678"
                    required
                  />
                </div>

                {error && <div className="formerr">{error}</div>}

                <button type="submit" className="pbtn wide" disabled={loading}>
                  {loading ? "Checking…" : "Finish sign-up"}
                </button>
              </form>
            </>
          )}

          <p className="hint" style={{ marginTop: 16, textAlign: "center" }}>
            <Link
              to="/recover"
              style={{ color: "var(--green)", fontWeight: 700 }}
            >
              Forgot your password?
            </Link>
            <br />
            Already have one?{" "}
            <Link
              to="/login"
              style={{ color: "var(--green)", fontWeight: 700 }}
            >
              Sign in
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}
