import { useAuthActions } from "@convex-dev/auth/react";
import { useMutation, useQuery } from "convex/react";
import { useEffect, useRef, useState } from "react";
import { Link } from "react-router";
import { toast } from "sonner";
import { api } from "../../convex/_generated/api";
import { StaffPanel } from "@/admin/StaffPanel";
import type { Id } from "../../convex/_generated/dataModel";
import { autoFormatSize, SA_TYRE_BRANDS } from "../brands";
import "../shop.css";

type Draft = {
  id?: Id<"tyres">;
  sizeLabel: string;
  brand: string;
  condition: "used" | "new";
  price: string;
  stock: string;
  notes: string;
  /** The single source of truth for uploaded photos: id and URL travel
   *  together, always the same length, always in the same order. They used to
   *  live in two arrays filled by two different queries, which desynced the
   *  moment one URL failed to resolve — and the delete button then removed
   *  the wrong photo, permanently. */
  photos: { id: Id<"_storage">; url: string }[];
  /** Photos the form was opened with, so the server can reject a stale save. */
  opened: Id<"_storage">[];
  /** Seeded placeholder images still attached to this tyre. */
  demos: string[];
};

const EMPTY: Draft = {
  sizeLabel: "",
  brand: "",
  condition: "used",
  price: "",
  stock: "1",
  notes: "",
  photos: [],
  opened: [],
  demos: [],
};

export function AdminPage() {
  const { signOut } = useAuthActions();
  const isAdmin = useQuery(api.admin.amIAdmin, {});
  const [filter, setFilter] = useState("");
  const [pane, setPane] = useState<"live" | "sold">("live");
  const [page, setPage] = useState(1);
  // Searching and paging happen on the server. Pulling every row to the
  // browser and filtering there meant the query resolved a thumbnail for all
  // of them — fine at 13 tyres, fatal at 300.
  const listing = useQuery(
    api.admin.listAll,
    isAdmin ? { pane, q: filter, page } : "skip",
  );
  const rows = listing?.rows;

  const accounts = useQuery(api.admin.accountAudit, isAdmin ? {} : "skip");
  const purge = useMutation(api.admin.purgeStranger);
  const strangers = (accounts ?? []).filter(a => !a.staff);

  const uploadUrl = useMutation(api.admin.uploadUrl);
  const create = useMutation(api.admin.create);
  const update = useMutation(api.admin.update);
  const setActive = useMutation(api.admin.setActive);
  const remove = useMutation(api.admin.remove);

  const [d, setD] = useState<Draft>(EMPTY);
  const editPhotos = useQuery(
    api.admin.photosFor,
    d.id ? { id: d.id } : "skip",
  );
  // The list query returns one thumbnail per row, so when a tyre is opened for
  // editing we fetch its full photo set once and drop it into the form.
  const filledFor = useRef<string | null>(null);
  useEffect(() => {
    if (!d.id) {
      filledFor.current = null;
      return;
    }
    if (editPhotos && filledFor.current !== d.id) {
      filledFor.current = d.id;
      setD(p => {
        if (p.id !== d.id) return p;
        // MERGE, do not replace. Photos dropped in while this query was still
        // loading used to be wiped out by the arriving result: gone from the
        // form, impossible to remove, and live on the shop after save with
        // nobody aware. Anything already in the form wins; the server's copy
        // fills in the rest.
        const have = new Set(p.photos.map(x => String(x.id)));
        const fromServer = editPhotos.filter(x => !have.has(String(x.id)));
        return {
          ...p,
          photos: [...fromServer, ...p.photos],
          opened: editPhotos.map(x => x.id),
        };
      });
    }
  }, [d.id, editPhotos]);
  const [busy, setBusy] = useState(false);
  const [uploading, setUploading] = useState(0);
  const [hot, setHot] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const formRef = useRef<HTMLDivElement>(null);

  const shown = rows;
  const liveCount = listing?.counts.live ?? 0;
  const soldCount = listing?.counts.sold ?? 0;
  const totalShown = listing?.total ?? 0;
  const pages = listing?.pages ?? 1;

  // Any change to what is being looked at starts again at page 1.
  // biome-ignore lint/correctness/useExhaustiveDependencies: reset on view change
  useEffect(() => {
    setPage(1);
  }, [pane, filter]);

  /** Load a row into the form AND take the user to it — on a phone the form is
   *  off-screen, so tapping Edit used to look like nothing happened. */
  function startEdit(r: {
    id: string;
    sizeLabel: string;
    brand: string;
    condition: "used" | "new";
    price: number;
    stock: number;
    notes: string;
    thumb: string | null;
    photoCount: number;
    demoUrls: string[];
  }) {
    setD({
      id: r.id as Id<"tyres">,
      sizeLabel: r.sizeLabel,
      brand: r.brand,
      condition: r.condition,
      price: String(r.price),
      stock: String(r.stock),
      notes: r.notes,
      // Left empty on purpose: the effect above fills these from photosFor.
      // The list query only carries one thumbnail per row now.
      photos: [],
      opened: [],
      demos: r.demoUrls,
    });
    formRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
  }

  if (isAdmin === undefined) {
    return <div className="gate">Checking your access…</div>;
  }
  if (isAdmin === false) {
    return (
      <div className="gate">
        <h2
          style={{ fontFamily: "'Barlow Condensed',sans-serif", fontSize: 28 }}
        >
          Not an admin account
        </h2>
        <p style={{ color: "var(--mid)", margin: "10px 0 18px", fontSize: 14 }}>
          You're signed in, but this email isn't on the Elvent Tyres admin list.
          Ask the shop owner to add it.
        </p>
        <button type="button" className="gbtn" onClick={() => void signOut()}>
          Sign out
        </button>
      </div>
    );
  }

  async function addFiles(files: FileList | null) {
    if (!files || files.length === 0) return;
    setUploading(files.length);
    const added: { id: Id<"_storage">; url: string }[] = [];
    try {
      for (const file of Array.from(files)) {
        const url = await uploadUrl({});
        const res = await fetch(url, {
          method: "POST",
          headers: { "Content-Type": file.type },
          body: file,
        });
        if (!res.ok) throw new Error(`Upload failed for ${file.name}`);
        const { storageId } = (await res.json()) as {
          storageId: Id<"_storage">;
        };
        added.push({ id: storageId, url: URL.createObjectURL(file) });
        setUploading(n => n - 1);
      }
      setD(p => ({ ...p, photos: [...p.photos, ...added] }));
      toast.success(
        `${added.length} photo${added.length > 1 ? "s" : ""} added`,
      );
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Upload failed");
    } finally {
      setUploading(0);
      if (fileRef.current) fileRef.current.value = "";
    }
  }

  async function save() {
    if (!d.sizeLabel.trim() || !d.brand.trim() || !d.price) {
      toast.error("Size, brand and price are needed");
      return;
    }
    setBusy(true);
    try {
      const payload = {
        sizeLabel: d.sizeLabel,
        brand: d.brand,
        condition: d.condition,
        price: Number(d.price),
        // Number("0") is falsy, so `|| 1` used to turn "sold out" into
        // "1 in stock". Only fall back when the box is genuinely empty.
        stock: d.stock === "" ? 1 : Number(d.stock),
        notes: d.notes || undefined,
        photos: d.photos.map(x => x.id),
      };
      if (d.id) {
        await update({
          id: d.id,
          ...payload,
          photoUrls: d.demos,
          expectedPhotos: d.opened,
        });
        toast.success("Tyre updated");
      } else {
        await create(payload);
        toast.success("Tyre added to the shop");
      }
      setD(EMPTY);
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Could not save");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="adm">
      <div className="admbar">
        <div className="wrap">
          <Link to="/" className="logo">
            <span className="ring">E</span>
            <b>
              ELVENT <i>ADMIN</i>
            </b>
          </Link>
          <span className="who">
            {liveCount} live · {liveCount + soldCount} total
          </span>
          <Link to="/" className="lnk">
            View shop
          </Link>
          <button type="button" className="lnk" onClick={() => void signOut()}>
            Sign out
          </button>
        </div>
      </div>

      <div className="wrap">
        <div className="panel" ref={formRef}>
          <h2>{d.id ? `Edit ${d.sizeLabel || "tyre"}` : "Add a tyre"}</h2>
          {d.id && (
            <div className="editflag">
              You are editing an existing tyre. Press <b>Save changes</b> when
              done, or Cancel to go back to adding a new one.
            </div>
          )}
          <div className="frow">
            <div className="field">
              <label htmlFor="f-size">Tyre size</label>
              <input
                id="f-size"
                value={d.sizeLabel}
                placeholder="195/65R15"
                inputMode="text"
                autoCapitalize="characters"
                onChange={e =>
                  setD({
                    ...d,
                    sizeLabel: autoFormatSize(e.target.value, d.sizeLabel),
                  })
                }
              />
              <div className="hint">
                Type 1956515 and it becomes 195/65R15. Bakkie and van sizes —
                195R15C, 750R16, 31x10.50R15 — type as they are.
              </div>
            </div>
            <div className="field">
              <label htmlFor="f-brand">Brand / name</label>
              <input
                id="f-brand"
                list="sa-brands"
                value={d.brand}
                placeholder="Start typing — Bridge…, Lanvi…"
                onChange={e => setD({ ...d, brand: e.target.value })}
              />
              {/* A suggestion list, not a cage: pick a brand or type anything,
                  including the pattern name — "Bridgestone Turanza". */}
              <datalist id="sa-brands">
                {SA_TYRE_BRANDS.map(b => (
                  <option key={b} value={b} />
                ))}
              </datalist>
            </div>
            <div className="field">
              <label htmlFor="f-cond">Condition</label>
              <select
                id="f-cond"
                value={d.condition}
                onChange={e =>
                  setD({ ...d, condition: e.target.value as "used" | "new" })
                }
              >
                <option value="used">Used</option>
                <option value="new">New</option>
              </select>
            </div>
            <div className="field">
              <label htmlFor="f-price">Price (R)</label>
              <input
                id="f-price"
                type="number"
                value={d.price}
                placeholder="520"
                onChange={e => setD({ ...d, price: e.target.value })}
              />
            </div>
            <div className="field">
              <label htmlFor="f-stock">How many</label>
              <input
                id="f-stock"
                type="number"
                value={d.stock}
                onChange={e => setD({ ...d, stock: e.target.value })}
              />
            </div>
          </div>

          <div className="field" style={{ marginBottom: 12 }}>
            <label htmlFor="f-notes">Notes for the customer (optional)</label>
            <textarea
              id="f-notes"
              value={d.notes}
              placeholder="Good tread, no plugs. Pair available."
              onChange={e => setD({ ...d, notes: e.target.value })}
            />
          </div>

          <div
            className={`drop ${hot ? "hot" : ""}`}
            onClick={() => fileRef.current?.click()}
            onKeyDown={e => {
              if (e.key === "Enter") fileRef.current?.click();
            }}
            onDragOver={e => {
              e.preventDefault();
              setHot(true);
            }}
            onDragLeave={() => setHot(false)}
            onDrop={e => {
              e.preventDefault();
              setHot(false);
              void addFiles(e.dataTransfer.files);
            }}
            role="button"
            tabIndex={0}
          >
            {uploading > 0
              ? `Uploading… ${uploading} to go`
              : "📷 Tap to add photos — you can pick many at once"}
            <div className="hint">
              Straight from your phone. First photo is the one on the card.
            </div>
          </div>
          <input
            ref={fileRef}
            type="file"
            accept="image/*"
            multiple
            hidden
            onChange={e => void addFiles(e.target.files)}
          />

          {(d.photos.length > 0 || d.demos.length > 0) && (
            <div className="shots">
              {/* Keyed and removed by storage id, not by array position and
                  not by URL. Two identical URLs used to collide as React keys,
                  and index-based removal deleted the wrong photo whenever the
                  two arrays had drifted apart. */}
              {d.photos.map((ph, i) => (
                <div className="s" key={ph.id}>
                  {ph.url ? (
                    <img src={ph.url} alt={`Tyre ${i + 1}`} />
                  ) : (
                    <span className="missing" title="This photo did not load">
                      ?
                    </span>
                  )}
                  <button
                    type="button"
                    aria-label={`Remove photo ${i + 1}`}
                    onClick={() =>
                      setD({
                        ...d,
                        photos: d.photos.filter(x => x.id !== ph.id),
                      })
                    }
                  >
                    ×
                  </button>
                </div>
              ))}
              {d.demos.map((p, i) => (
                <div className="s demo" key={p}>
                  <img src={p} alt={`Placeholder ${i + 1}`} />
                  <span className="tag">demo</span>
                  <button
                    type="button"
                    aria-label="Remove this placeholder photo"
                    onClick={() =>
                      setD({ ...d, demos: d.demos.filter((_, j) => j !== i) })
                    }
                  >
                    ×
                  </button>
                </div>
              ))}
            </div>
          )}

          <div style={{ display: "flex", gap: 10, marginTop: 16 }}>
            <button
              type="button"
              className="pbtn"
              disabled={busy}
              onClick={() => void save()}
            >
              {busy ? "Saving…" : d.id ? "Save changes" : "Add to the shop"}
            </button>
            {d.id && (
              <button
                type="button"
                className="gbtn"
                onClick={() => setD(EMPTY)}
              >
                Cancel
              </button>
            )}
          </div>
        </div>

        <div className="panel">
          <div className="stockhead">
            <h2>Stock</h2>
            <div className="stocktabs" role="tablist" aria-label="Stock view">
              <button
                type="button"
                role="tab"
                aria-selected={pane === "live"}
                className={`stab ${pane === "live" ? "on" : ""}`}
                onClick={() => setPane("live")}
              >
                In stock · {liveCount}
              </button>
              <button
                type="button"
                role="tab"
                aria-selected={pane === "sold"}
                className={`stab ${pane === "sold" ? "on" : ""}`}
                onClick={() => setPane("sold")}
              >
                Sold out · {soldCount}
              </button>
            </div>
            <input
              className="stocksearch"
              value={filter}
              onChange={e => setFilter(e.target.value)}
              placeholder="Find a tyre to edit or delete — 155/80R13, Dunlop…"
              aria-label="Find a tyre in your stock"
            />
          </div>
          {rows === undefined ? (
            <div className="hint">Loading…</div>
          ) : liveCount + soldCount === 0 ? (
            <div className="hint">No tyres yet — add the first one above.</div>
          ) : (
            <>
              {shown && shown.length === 0 && (
                <div className="hint">
                  {filter
                    ? `Nothing in ${pane === "live" ? "your in-stock tyres" : "your sold-out tyres"} matches "${filter}".`
                    : pane === "sold"
                      ? "Nothing is marked sold out. Tyres you hide from the shop land here."
                      : "Everything is marked sold out — check the Sold out tab."}
                </div>
              )}
              <table className="rowlist">
                <thead>
                  <tr>
                    <th>Photo</th>
                    <th>Size</th>
                    <th>Brand</th>
                    <th>Price</th>
                    <th>Qty</th>
                    <th>Status</th>
                    <th />
                  </tr>
                </thead>
                <tbody>
                  {(shown ?? []).map(r => (
                    <tr key={r.id} className={r.active ? "" : "off"}>
                      <td>
                        <img
                          src={r.thumb ?? r.demoUrls[0] ?? "/demo/face.webp"}
                          alt=""
                        />
                      </td>
                      <td>
                        <b>{r.sizeLabel}</b>
                      </td>
                      <td>{r.brand}</td>
                      <td>R {r.price}</td>
                      <td>{r.stock}</td>
                      <td>
                        <span
                          className={`pill ${r.active ? (r.condition === "new" ? "n" : "u") : "x"}`}
                        >
                          {r.active ? r.condition : "sold out"}
                        </span>
                      </td>
                      <td>
                        <div className="tools">
                          <button type="button" onClick={() => startEdit(r)}>
                            Edit ↑
                          </button>
                          <button
                            type="button"
                            onClick={() =>
                              void setActive({
                                id: r.id as Id<"tyres">,
                                active: !r.active,
                              })
                            }
                          >
                            {r.active ? "Mark sold out" : "Back in stock"}
                          </button>
                          <button
                            type="button"
                            className="dbtn"
                            onClick={() => {
                              if (
                                confirm(`Delete the ${r.sizeLabel} ${r.brand}?`)
                              )
                                void remove({ id: r.id as Id<"tyres"> });
                            }}
                          >
                            Delete
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>

              {strangers.length > 0 && (
                <div className="strangers">
                  <b>
                    {strangers.length} account
                    {strangers.length === 1 ? "" : "s"} that should not be here
                  </b>
                  <p>
                    Made while the shop still allowed public sign-up. They
                    cannot touch stock, but they can still log in. Remove them.
                  </p>
                  {strangers.map(a => (
                    <div className="srow" key={a.id}>
                      <span>{a.email}</span>
                      <button
                        type="button"
                        className="dbtn"
                        onClick={() => {
                          if (confirm(`Remove the account ${a.email}?`))
                            void purge({ id: a.id }).then(
                              () => toast.success("Account removed"),
                              e =>
                                toast.error(
                                  e instanceof Error ? e.message : "Failed",
                                ),
                            );
                        }}
                      >
                        Remove
                      </button>
                    </div>
                  ))}
                </div>
              )}

              {pages > 1 && (
                <div className="apager">
                  <button
                    type="button"
                    disabled={page <= 1}
                    onClick={() => setPage(n => Math.max(1, n - 1))}
                  >
                    ‹ Back
                  </button>
                  <span>
                    Page {page} of {pages} · {totalShown} tyre
                    {totalShown === 1 ? "" : "s"}
                  </span>
                  <button
                    type="button"
                    disabled={page >= pages}
                    onClick={() => setPage(n => Math.min(pages, n + 1))}
                  >
                    Next ›
                  </button>
                </div>
              )}
            </>
          )}
        </div>

        <StaffPanel />
      </div>
    </div>
  );
}
