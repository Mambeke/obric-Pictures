import { v } from "convex/values";
import { authenticatedMutation, authenticatedQuery } from "./functions";
import { makeInviteToken, normaliseEmail } from "./inviteToken";
import { isOwnerEmail, ownerEmails, requireOwner } from "./owner";

/**
 * Staff access: grant it, revoke it, give it back.
 *
 * Modelled on how a shop actually runs, not on how software usually does it.
 * The owner types a man's email, hands him a link, and he sets his own
 * password — the owner never learns it. When that man leaves, one click and
 * he is out, even though his account and his link still exist.
 */

/** Everyone with access, owners first. Owners can see this; nobody else. */
export const list = authenticatedQuery({
  args: {},
  handler: async ctx => {
    await requireOwner(ctx, ctx.userId);
    const rows = await ctx.db.query("staff").collect();
    const users = await ctx.db.query("users").collect();
    const hasAccount = new Set(
      users.map(u => normaliseEmail(u.email ?? "")).filter(Boolean),
    );

    return {
      owners: ownerEmails().map(email => ({
        email,
        hasAccount: hasAccount.has(email),
      })),
      staff: rows
        .filter(r => !isOwnerEmail(r.email))
        .sort((a, b) => b.invitedAt - a.invitedAt)
        .map(r => ({
          id: r._id,
          email: r.email,
          active: r.active,
          note: r.note ?? "",
          invitedBy: r.invitedBy,
          invitedAt: r.invitedAt,
          revokedAt: r.revokedAt,
          hasAccount: hasAccount.has(normaliseEmail(r.email)),
          // The link stays valid for as long as the grant does, so the owner
          // can resend it to someone who lost the message.
          inviteToken: makeInviteToken(r.email),
        })),
    };
  },
});

export const grant = authenticatedMutation({
  args: { email: v.string(), note: v.optional(v.string()) },
  handler: async (ctx, { email, note }) => {
    const by = await requireOwner(ctx, ctx.userId);
    const addr = normaliseEmail(email);
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(addr))
      throw new Error("That does not look like an email address.");
    if (isOwnerEmail(addr))
      throw new Error(
        "That address is already a permanent owner of this shop.",
      );

    const existing = await ctx.db
      .query("staff")
      .withIndex("by_email", i => i.eq("email", addr))
      .unique();

    if (existing) {
      // Re-granting a revoked person is the normal case: a man comes back to
      // work. Reuse the row so the history stays in one place.
      await ctx.db.patch(existing._id, {
        active: true,
        note: note ?? existing.note,
        invitedBy: by,
        invitedAt: Date.now(),
        revokedBy: undefined,
        revokedAt: undefined,
      });
    } else {
      await ctx.db.insert("staff", {
        email: addr,
        active: true,
        invitedBy: by,
        invitedAt: Date.now(),
        note,
      });
    }
    return { email: addr, inviteToken: makeInviteToken(addr) };
  },
});

/**
 * Revoke. The account survives; the access does not. Deliberately not a
 * delete — a deleted row loses the record that this person was ever here,
 * and a shop owner deserves to be able to look back and see who had the keys.
 */
export const revoke = authenticatedMutation({
  args: { id: v.id("staff") },
  handler: async (ctx, { id }) => {
    const by = await requireOwner(ctx, ctx.userId);
    const row = await ctx.db.get(id);
    if (!row) return;
    await ctx.db.patch(id, {
      active: false,
      revokedBy: by,
      revokedAt: Date.now(),
    });
  },
});

/** Remove the record entirely, once the owner no longer needs the history. */
export const forget = authenticatedMutation({
  args: { id: v.id("staff") },
  handler: async (ctx, { id }) => {
    await requireOwner(ctx, ctx.userId);
    const row = await ctx.db.get(id);
    if (row?.active)
      throw new Error("Revoke this person's access before removing the record.");
    await ctx.db.delete(id);
  },
});

/**
 * "He forgot his password."
 *
 * Password-reset emails only go to the permanent owners — the reset provider
 * mails a code to anyone who asks it to, so opening that up to every staff
 * address would hand a stranger a way to spend the shop's email quota and
 * probe which addresses exist. Instead the owner fixes it directly: this
 * wipes the person's login (not their access), and their invite link, which
 * is still valid, lets them set a new password in a minute.
 */
export const resetLogin = authenticatedMutation({
  args: { id: v.id("staff") },
  handler: async (ctx, { id }) => {
    await requireOwner(ctx, ctx.userId);
    const row = await ctx.db.get(id);
    if (!row) throw new Error("That staff member is no longer on the list.");
    const addr = normaliseEmail(row.email);

    const users = await ctx.db.query("users").collect();
    const target = users.find(u => normaliseEmail(u.email ?? "") === addr);
    if (!target)
      throw new Error(
        "There is no account for that email yet — just send them the invite link.",
      );
    if (isOwnerEmail(addr))
      throw new Error("An owner's login cannot be wiped from here.");

    for (const acc of await ctx.db.query("authAccounts").collect())
      if (acc.userId === target._id) await ctx.db.delete(acc._id);
    for (const sess of await ctx.db.query("authSessions").collect())
      if (sess.userId === target._id) await ctx.db.delete(sess._id);
    await ctx.db.delete(target._id);
  },
});

/** Does the signed-in account manage people, or only stock? */
export const amIOwner = authenticatedQuery({
  args: {},
  handler: async ctx => {
    const user = await ctx.db.get(ctx.userId);
    return isOwnerEmail(user?.email ?? "");
  },
});
