// The only accounts allowed into the owner area.
// Add another email here (and redeploy) to let a second person manage stock.
export const OWNER_EMAILS = [
  "brandonmambeke@gmail.com",
  "zimpoint.brandon.mambeke@gmail.com",
];

export function isOwnerEmail(email: string | undefined | null): boolean {
  if (!email) return false;
  return OWNER_EMAILS.includes(email.trim().toLowerCase());
}

export const DEFAULT_SETTINGS = {
  shopName: "Prime Appliances",
  tagline: "Used appliances, tested and guaranteed",
  town: "Cape Town",
  address: "",
  phoneDisplay: "072 677 9489",
  phoneDial: "+27726779489",
  whatsapp: "27726779489",
  hours: "Mon–Fri 8am–5pm · Sat 8am–1pm",
  deliveryFee: 250,
  deliveryNote: "Free delivery in town on the items marked free. Collection welcome.",
  warrantyDays: 14,
};
