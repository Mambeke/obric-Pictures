import { v } from "convex/values";
import type { Doc } from "./_generated/dataModel";
import { type QueryCtx, query } from "./_generated/server";

/**
 * PUBLIC shop endpoints. Deliberately anonymous — this is a shop window,
 * there is nothing private here. Everything that changes data lives in
 * admin.ts behind an owner check.
 */

export const PER_PAGE = 12;

/** Digits only: "195/65 R15", "195 65 15" and "1956515" all become "1956515". */
export function normalise(s: string): string {
  return s
    .toUpperCase()
    .replace(/R(?=\d)/g, "")
    .replace(/[^0-9A-Z]/g, "");
}

type Card = {
  id: string;
  sizeLabel: string;
  brand: string;
  condition: "used" | "new";
  price: number;
  stock: number;
  notes?: string;
  photos: string[];
  photoCount: number;
};

async function toCard(
  ctx: QueryCtx,
  t: Doc<"tyres">,
  mode: "thumb" | "full" = "full",
): Promise<Card> {
  // A grid card shows ONE photo. Resolving all of them was fine at 13 tyres
  // and is 12 x (photos per tyre) storage lookups per page at 300 — the same
  // silent-death pattern that killed the admin list. The detail page asks for
  // "full"; every grid asks for "thumb".
  const extra = t.photoUrls ?? [];
  let urls: string[];
  if (mode === "thumb") {
    const first = t.photos.length
      ? await ctx.storage.getUrl(t.photos[0])
      : null;
    urls = first ? [first] : extra.slice(0, 1);
  } else {
    const stored = await Promise.all(
      t.photos.map(id => ctx.storage.getUrl(id)),
    );
    urls = [...stored.filter((u): u is string => Boolean(u)), ...extra];
  }
  return {
    id: t._id,
    sizeLabel: t.sizeLabel,
    brand: t.brand,
    condition: t.condition,
    price: t.price,
    stock: t.stock,
    notes: t.notes,
    photos: urls,
    photoCount: t.photos.length + extra.length,
  };
}

function matches(
  t: Doc<"tyres">,
  q: string,
  width: string,
  profile: string,
  rim: string,
): boolean {
  if (width && t.width !== width) return false;
  if (profile && t.profile !== profile) return false;
  if (rim && t.rim !== rim) return false;
  if (!q) return true;
  // People type "195 michelin" — a size AND a brand in one box. Test each
  // word separately: number-ish words against the size, the rest against the
  // brand. Every word must match something, so the two together now narrow
  // the results instead of returning nothing.
  const words = q.trim().toLowerCase().split(/\s+/).filter(Boolean);
  if (words.length === 0) return true;
  const brand = t.brand.toLowerCase();
  return words.every(w => {
    const n = normalise(w);
    if (n && /\d/.test(n) && t.sizeKey.includes(n)) return true;
    return brand.includes(w);
  });
}

export const list = query({
  args: {
    tab: v.union(v.literal("used"), v.literal("new"), v.literal("all")),
    q: v.optional(v.string()),
    width: v.optional(v.string()),
    profile: v.optional(v.string()),
    rim: v.optional(v.string()),
    page: v.optional(v.number()),
  },
  handler: async (ctx, args) => {
    const all = await ctx.db
      .query("tyres")
      .withIndex("by_active", i => i.eq("active", true))
      .collect();

    const filtered = all
      .filter(t => (args.tab === "all" ? true : t.condition === args.tab))
      .filter(t =>
        matches(
          t,
          args.q ?? "",
          args.width ?? "",
          args.profile ?? "",
          args.rim ?? "",
        ),
      )
      .sort((a, b) => b.createdAt - a.createdAt);

    const total = filtered.length;
    const pages = Math.max(1, Math.ceil(total / PER_PAGE));
    const page = Math.min(Math.max(1, args.page ?? 1), pages);
    const slice = filtered.slice((page - 1) * PER_PAGE, page * PER_PAGE);

    // A customer who searches for a used 195/65R15 we don't have, while two
    // new ones sit in the next tab, is a sale walking out of the shop. When
    // the current tab comes back empty, look in the other one and offer it
    // right here instead of making him find the tab himself.
    let alt: {
      condition: "used" | "new";
      total: number;
      items: Card[];
    } | null = null;
    if (total === 0 && args.tab !== "all") {
      const other = args.tab === "used" ? "new" : "used";
      const found = all
        .filter(t => t.condition === other)
        .filter(t =>
          matches(
            t,
            args.q ?? "",
            args.width ?? "",
            args.profile ?? "",
            args.rim ?? "",
          ),
        )
        .sort((a, b) => b.createdAt - a.createdAt);
      if (found.length)
        alt = {
          condition: other,
          total: found.length,
          items: await Promise.all(
            found.slice(0, PER_PAGE).map(t => toCard(ctx, t, "thumb")),
          ),
        };
    }

    return {
      items: await Promise.all(slice.map(t => toCard(ctx, t, "thumb"))),
      alt,
      total,
      page,
      pages,
      perPage: PER_PAGE,
      counts: {
        used: all.filter(t => t.condition === "used").length,
        new: all.filter(t => t.condition === "new").length,
        all: all.length,
      },
    };
  },
});

/** Values that actually exist in stock, so the dropdowns never offer a dead end. */
export const facets = query({
  args: {},
  handler: async ctx => {
    const all = await ctx.db
      .query("tyres")
      .withIndex("by_active", i => i.eq("active", true))
      .collect();
    const metric = all.filter(t => (t.sizeSystem ?? "metric") === "metric");
    const uniq = (xs: string[]) =>
      [...new Set(xs)].filter(Boolean).sort((a, b) => Number(a) - Number(b));
    return {
      // Only metric sizes feed the width/profile dropdowns. A bakkie tyre
      // stored as 31x10.50R15 would otherwise put "31" among the widths and
      // "10.5" among the profiles, which means nothing to someone reading a
      // sidewall. Bakkie stock stays findable by typing the size or by rim.
      widths: uniq(metric.map(t => t.width)),
      profiles: uniq(metric.map(t => t.profile)),
      rims: uniq(all.map(t => t.rim)),
    };
  },
});

export const get = query({
  args: { id: v.string() },
  handler: async (ctx, { id }) => {
    // Fetch the one document directly. This used to read the whole table to
    // find a single row, then read it again for the related-stock pool.
    //
    // normalizeId, not a cast: Convex THROWS on a malformed id string, and a
    // cast is a lie that turns a mistyped or truncated link into a server
    // error page. Traffic here arrives through WhatsApp, which clips long
    // URLs, so a broken product link is an ordinary Tuesday. Return null and
    // let the page show "that tyre is no longer in stock".
    const real = ctx.db.normalizeId("tyres", id);
    if (!real) return null;
    const t = await ctx.db.get(real);
    if (!t || !t.active) return null;

    // Same rim size first, then anything else — and always carry the size
    // through so the "related stock" cards show what size they are.
    // Prefer the same rim size, so the pool stays small as stock grows.
    // withIndex, not .filter(): a .filter() after an index scan is a
    // post-filter, so .take(12) on a rare rim size used to walk every active
    // tyre before giving up.
    const sameRim = await ctx.db
      .query("tyres")
      .withIndex("by_rim", i => i.eq("active", true).eq("rim", t.rim))
      .take(12);
    const pool =
      sameRim.length > 1
        ? sameRim
        : await ctx.db
            .query("tyres")
            .withIndex("by_active", i => i.eq("active", true))
            .take(12);
    const similar = pool
      .filter(r => r._id !== t._id)
      .sort((a, b) => {
        const rank = (x: Doc<"tyres">) =>
          (x.rim === t.rim ? 0 : 2) + (x.width === t.width ? 0 : 1);
        return rank(a) - rank(b);
      })
      .slice(0, 4);

    return {
      tyre: await toCard(ctx, t),
      similar: await Promise.all(similar.map(r => toCard(ctx, r, "thumb"))),
    };
  },
});
