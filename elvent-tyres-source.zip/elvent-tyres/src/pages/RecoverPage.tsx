import { useAuthActions } from "@convex-dev/auth/react";
import { useState } from "react";
import { Link, useNavigate } from "react-router";
import "../shop.css";
import { PasswordField } from "@/components/PasswordField";

/**
 * Password reset by emailed code.
 *
 * The backend already wires a reset provider into Convex Auth, so this is a
 * real reset, not a "phone the person who built it" note: step one mails a
 * code, step two swaps the password. Codes last 15 minutes.
 */
export function RecoverPage() {
  const { signIn } = useAuthActions();
  const navigate = useNavigate();
  const [step, setStep] = useState<"email" | "code">("email");
  const [email, setEmail] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function requestCode(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError("");
    setLoading(true);
    const form = new FormData(e.currentTarget);
    const addr = String(form.get("email") ?? "").trim();
    form.set("flow", "reset");
    try {
      await signIn("password", form);
      setEmail(addr);
      setStep("code");
    } catch {
      setError(
        "Could not send a code to that address. Check the spelling — it must be the email you signed up with.",
      );
    } finally {
      setLoading(false);
    }
  }

  async function submitCode(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError("");
    const form = new FormData(e.currentTarget);
    const pw = String(form.get("newPassword") ?? "");
    if (pw !== String(form.get("password2") ?? "")) {
      setError("Those two passwords are not the same. Tap Show to check them.");
      return;
    }
    form.delete("password2");
    form.set("email", email);
    form.set("flow", "reset-verification");
    setLoading(true);
    try {
      await signIn("password", form);
      navigate("/admin");
    } catch {
      setError(
        "That code was wrong or has expired. Codes last 15 minutes — send yourself a new one.",
      );
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="adm">
      <div className="admbar">
        <div className="wrap">
          <Link to="/" className="logo">
            <span className="ring">E</span>
            <b>
              ELVENT <i>TYRES</i>
            </b>
          </Link>
          <Link to="/" className="lnk" style={{ marginLeft: "auto" }}>
            View shop
          </Link>
        </div>
      </div>

      <div className="loginwrap">
        <div className="panel recover">
          <h2>Reset your password</h2>

          {step === "email" ? (
            <>
              <p className="hint" style={{ marginTop: -8, marginBottom: 16 }}>
                We'll email you an 8-digit code. It works for 15 minutes.
              </p>
              <form onSubmit={requestCode}>
                <div className="field" style={{ marginBottom: 16 }}>
                  <label htmlFor="email">Your email</label>
                  <input
                    id="email"
                    name="email"
                    type="email"
                    autoComplete="email"
                    placeholder="you@example.com"
                    required
                  />
                </div>
                {error && <div className="formerr">{error}</div>}
                <button type="submit" className="pbtn wide" disabled={loading}>
                  {loading ? "Sending…" : "Email me a code"}
                </button>
              </form>
            </>
          ) : (
            <>
              <p className="hint" style={{ marginTop: -8, marginBottom: 16 }}>
                Code sent to <b>{email}</b>. Check spam if it's not there in a
                minute.
              </p>
              <form onSubmit={submitCode}>
                <div className="field" style={{ marginBottom: 16 }}>
                  <label htmlFor="code">Code from the email</label>
                  <input
                    id="code"
                    name="code"
                    inputMode="numeric"
                    autoComplete="one-time-code"
                    placeholder="12345678"
                    required
                  />
                </div>

                <PasswordField
                  id="newPassword"
                  name="newPassword"
                  label="New password"
                  placeholder="At least 8 characters"
                  autoComplete="new-password"
                />
                <PasswordField
                  id="password2"
                  name="password2"
                  label="Type it again"
                  placeholder="The same password"
                  autoComplete="new-password"
                />

                {error && <div className="formerr">{error}</div>}
                <button type="submit" className="pbtn wide" disabled={loading}>
                  {loading ? "Saving…" : "Set new password"}
                </button>
              </form>
              <p
                className="hint"
                style={{ marginTop: 14, textAlign: "center" }}
              >
                <button
                  type="button"
                  className="peek"
                  onClick={() => {
                    setStep("email");
                    setError("");
                  }}
                >
                  Use a different email
                </button>
              </p>
            </>
          )}

          <div className="callout" style={{ marginTop: 18 }}>
            <b>Your stock is safe.</b> Tyres, photos and prices are stored
            separately from logins. Resetting a password does not touch a single
            tyre.
          </div>

          <p className="hint" style={{ marginTop: 18, textAlign: "center" }}>
            <Link
              to="/login"
              style={{ color: "var(--green)", fontWeight: 700 }}
            >
              Back to sign in
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}
