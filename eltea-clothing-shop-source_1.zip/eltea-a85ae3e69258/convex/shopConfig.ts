// The accounts allowed into the owner panel.
// Add another email here (and redeploy) to let a second person manage stock.
export const OWNER_EMAILS = [
  "zimpoint.brandon.mambeke@gmail.com",
  "brandonmambeke@gmail.com",
];

export function isOwnerEmail(email: string | undefined | null): boolean {
  // Dev/preview convenience: OWNER_OPEN is set only on the dev deployment so
  // the e2e tests and screenshots can reach the owner panel. Never set in prod.
  const env = (globalThis as { process?: { env?: Record<string, string | undefined> } }).process?.env;
  if (env?.OWNER_OPEN === "true") return true;
  if (!email) return false;
  return OWNER_EMAILS.includes(email.trim().toLowerCase());
}

export const DEFAULT_SETTINGS = {
  shopName: "Eltea Boutique",
  whatsapp: "27685302223",
  footerLine: "Avondale, Harare",
  ribbon: [
    "ONE OF EACH — WHEN IT'S GONE IT'S GONE",
    "NEW PIECES EVERY TUESDAY",
    "DELIVERY IN HARARE $2 · OTHER TOWNS $5",
    "LAY-BYE ON NEW STOCK — PAY OVER TWO MONTHS",
    "ECOCASH · INNBUCKS · BANK TRANSFER · CASH",
  ],
  deliveryTowns: [
    { town: "Harare", fee: 2, days: 2 },
    { town: "Chitungwiza", fee: 2, days: 2 },
    { town: "Bulawayo", fee: 5, days: 4 },
    { town: "Gweru", fee: 5, days: 4 },
    { town: "Mutare", fee: 5, days: 4 },
    { town: "Masvingo", fee: 5, days: 4 },
    { town: "Other town", fee: 5, days: 4 },
  ],
  laybyeEnabled: true,
  laybyeMinPrice: 20,
  laybyeMonths: 2,
};

export const DEFAULT_CATEGORIES = [
  "Dresses",
  "Tops",
  "Shirts",
  "Jeans & trousers",
  "Skirts",
  "Jackets",
  "Tracksuits",
  "Shoes",
  "Bags",
];
