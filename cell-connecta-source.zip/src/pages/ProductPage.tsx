import { useQuery } from "convex/react";
import { useEffect, useState } from "react";
import { Link, useParams, useSearchParams } from "react-router";
import { api } from "../../convex/_generated/api";
import type { Id } from "../../convex/_generated/dataModel";
import { colourHex, colourText, coloursFor } from "@/shop/catalogue";
import { PhoneIcon, ShopFooter, ShopHeader, WhatsAppIcon } from "@/shop/Chrome";
import {
  CONDITION_LABEL,
  PHONE_DIAL,
  PHONE_DISPLAY,
  PROMISES,
  rands,
  SHOP_NAME,
  waLink,
} from "@/shop/config";
import { Gallery } from "@/shop/Gallery";
import { type Phone, savePercent } from "@/shop/types";

function Description({ text, className = "" }: { text: string; className?: string }) {
  return (
    <div
      className={`rounded-2xl bg-white p-4 shadow-sm ring-1 ring-black/5 ${className}`}
    >
      <h2 className="text-[13px] font-black uppercase tracking-wide text-neutral-500">
        About this phone
      </h2>
      <p className="mt-2 whitespace-pre-wrap text-[14.5px] leading-relaxed text-neutral-700">
        {text}
      </p>
    </div>
  );
}

export function ProductPage() {
  const { id } = useParams();
  const [params] = useSearchParams();
  const back = params.get("from") ?? "";
  const phone = useQuery(api.shop.getPhone, {
    id: id as Id<"phones">,
  }) as Phone | null | undefined;
  const all = useQuery(api.shop.listPhones) as Phone[] | undefined;

  const [variantIndex, setVariantIndex] = useState(0);
  const [copied, setCopied] = useState(false);
  // The colour the customer has picked on this page. It starts as the colour
  // of the listing and only changes the wording of the order — clicking a
  // colour never sends anyone away to WhatsApp on its own.
  const [chosenColour, setChosenColour] = useState<string>("");

  useEffect(() => {
    if (!phone) return;
    const first = phone.variants.findIndex(v => v.inStock > 0);
    setVariantIndex(first >= 0 ? first : 0);
    setChosenColour(phone.colour);
  }, [phone]);

  if (phone === undefined) {
    return (
      <div className="min-h-screen bg-[#f4f7fd]">
        <ShopHeader />
        <div className="mx-auto max-w-[1400px] p-5">
          <div className="h-80 animate-pulse rounded-3xl bg-white" />
        </div>
      </div>
    );
  }

  if (phone === null) {
    return (
      <div className="min-h-screen bg-[#f4f7fd]">
        <ShopHeader />
        <div className="mx-auto max-w-lg p-10 text-center">
          <p className="text-lg font-bold">That phone is no longer listed.</p>
          <Link
            to="/"
            className="mt-4 inline-block rounded-full bg-[#1257d0] px-6 py-3 text-sm font-bold text-white"
          >
            ← Back to phones
          </Link>
        </div>
      </div>
    );
  }

  const isRefurb = phone.condition === "certified_refurbished";
  const variant = phone.variants[variantIndex];
  const save = savePercent(variant);
  const accent = isRefurb ? "#1257d0" : "#b45309";

  // The same phone in other colours, so a customer can switch without going back.
  const otherColours = (all ?? []).filter(
    p =>
      p.model === phone.model &&
      p.condition === phone.condition &&
      p.brand === phone.brand,
  );

  const colour = chosenColour || phone.colour;
  const colourIsOurs = colour.toLowerCase() === phone.colour.toLowerCase();
  const title = `${phone.model} ${variant?.storage ?? ""} ${colour}`.trim();
  const soldOut = variant ? variant.inStock === 0 : true;

  const orderMessage = soldOut
    ? `Hi ${SHOP_NAME}, the ${title} (${
        CONDITION_LABEL[phone.condition]
      }) shows as sold out. Can you source one for me?`
    : `Hi ${SHOP_NAME}, I'm interested in the ${title} (${
        CONDITION_LABEL[phone.condition]
      }) at ${rands(variant.price)}. Is it available?${
        colourIsOurs
          ? ""
          : ` The photos show ${phone.colour} — can you source it in ${colour} for me?`
      }`;

  return (
    <div className="min-h-screen bg-[#f4f7fd]">
      <ShopHeader />

      <main className="mx-auto max-w-[1400px] px-3 pb-6 pt-4 sm:px-5">
        <Link
          to={back ? `/?${back}` : "/"}
          className="inline-flex items-center gap-1 text-[13.5px] font-bold text-[#1257d0]"
        >
          ← Back to phones
        </Link>

        <div className="mt-3 grid gap-5 md:grid-cols-[minmax(0,0.92fr)_minmax(0,1.08fr)] md:gap-8 lg:grid-cols-[minmax(0,0.8fr)_minmax(0,1.2fr)] lg:gap-10">
          <div className="min-w-0 md:sticky md:top-28 md:self-start">
            <Gallery photos={phone.photoUrls} alt={title} />
            {phone.description && (
              <Description
                text={phone.description}
                className="mt-4 hidden md:block"
              />
            )}
          </div>

          <div className="min-w-0">
            <span
              className="inline-block rounded-full px-3 py-1 text-[11px] font-black uppercase tracking-wide text-white"
              style={{ backgroundColor: accent }}
            >
              {isRefurb
                ? "Certified refurbished · in the box"
                : `Pre-owned${phone.grade ? ` · ${phone.grade}` : ""}`}
            </span>

            <h1 className="mt-2.5 text-2xl font-black leading-tight text-neutral-900 sm:text-3xl">
              {phone.model}
            </h1>

            {/* Memory first, then the colour, then the battery on its own
                line so nothing ever sits on top of anything else. */}
            <div className="mt-2 flex flex-wrap items-center gap-2">
              {!isRefurb && variant && (
                <span className="rounded-lg bg-neutral-100 px-2 py-0.5 text-[14px] font-black text-neutral-800">
                  {variant.storage}
                </span>
              )}
              <span
                className="text-[15px] font-bold"
                style={{ color: colourText(colour) }}
              >
                {colour}
              </span>
              <ColourPicker
                phone={phone}
                siblings={otherColours}
                chosen={colour}
                onChoose={setChosenColour}
              />
            </div>

            {phone.battery ? (
              <p className="mt-1.5 text-[13px] font-semibold text-neutral-500">
                Battery health {phone.battery}%
              </p>
            ) : null}

            {/* A colour tap must always answer back, even when that colour is
                not a listing of its own. */}
            {chosenColour && (
              <p
                key={colour}
                className="cc-fade mt-1.5 text-[12.5px] font-semibold text-neutral-500"
              >
                {colour.toLowerCase() === phone.colour.toLowerCase()
                  ? "This is the one in the photos."
                  : "We can get this colour — say so when you message us."}
              </p>
            )}

            {variant && (
              <div className="mt-4 flex flex-wrap items-end gap-2.5">
                <span
                  key={variant.storage}
                  className="cc-price text-3xl font-black text-neutral-900 sm:text-4xl"
                >
                  {rands(variant.price)}
                </span>
                {variant.wasPrice && variant.wasPrice > variant.price && (
                  <span className="pb-1 text-base text-neutral-400 line-through">
                    {rands(variant.wasPrice)}
                  </span>
                )}
                {save && (
                  <span className="mb-1 rounded-full bg-amber-400 px-2.5 py-1 text-[11.5px] font-black text-amber-950">
                    Save {save}%
                  </span>
                )}
              </div>
            )}

            {isRefurb && phone.variants.length > 0 && (
              <div className="mt-5">
                <p className="mb-2 text-[11.5px] font-bold uppercase tracking-wide text-neutral-500">
                  Choose your storage
                </p>
                <div className="flex flex-wrap gap-2">
                  {phone.variants.map((v, i) => {
                    const active = i === variantIndex;
                    const out = v.inStock === 0;
                    return (
                      <button
                        key={v.storage}
                        type="button"
                        onClick={() => setVariantIndex(i)}
                        className={`rounded-2xl border-2 px-3.5 py-2 text-left transition active:scale-95 ${
                          active
                            ? "border-[#1257d0] bg-sky-50"
                            : "border-neutral-200 bg-white hover:border-neutral-300"
                        } ${out ? "opacity-55" : ""}`}
                      >
                        <span className="block text-[14px] font-black text-neutral-900">
                          {v.storage}
                        </span>
                        <span className="block text-[11.5px] font-semibold text-neutral-500">
                          {rands(v.price)}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            <p
              className="mt-4 text-[13.5px] font-bold"
              style={{ color: soldOut ? "#b45309" : accent }}
            >
              {soldOut
                ? "Sold out — ask us to source it"
                : isRefurb
                  ? "Available to order"
                  : `In stock — ${variant.inStock} available`}
            </p>

            {/* One line of actions; on a narrow phone it slides sideways. */}
            <div className="cc-rail -mx-3 mt-4 flex gap-2.5 overflow-x-auto px-3 pb-1 sm:mx-0 sm:px-0">
              <a
                href={waLink(orderMessage)}
                target="_blank"
                rel="noreferrer"
                className="flex shrink-0 items-center justify-center gap-2 rounded-2xl bg-[#25d366] px-5 py-3.5 text-[14.5px] font-bold text-white shadow-lg shadow-emerald-900/20 transition hover:bg-[#1eb85a] active:scale-[0.98]"
              >
                <WhatsAppIcon className="size-5" />
                {soldOut ? "Ask us to source it" : "Order on WhatsApp"}
              </a>
              <a
                href={`tel:${PHONE_DIAL}`}
                className="flex shrink-0 items-center justify-center gap-2 whitespace-nowrap rounded-2xl border-2 border-[#1257d0] px-4 py-3.5 text-[14px] font-bold text-[#1257d0] transition active:scale-95"
              >
                <PhoneIcon /> Call now
              </a>
              <a
                href={waLink(
                  `Hi ${SHOP_NAME}, I'd like to trade in my old phone against the ${title}.`,
                )}
                target="_blank"
                rel="noreferrer"
                className="flex shrink-0 items-center justify-center gap-1.5 whitespace-nowrap rounded-2xl border-2 border-amber-500 px-4 py-3.5 text-[14px] font-bold text-amber-700 transition active:scale-95"
              >
                Trade in my phone
              </a>
            </div>

            <button
              type="button"
              onClick={() => {
                navigator.clipboard
                  ?.writeText(window.location.href)
                  .then(() => {
                    setCopied(true);
                    setTimeout(() => setCopied(false), 2000);
                  })
                  .catch(() => undefined);
              }}
              className="group mt-3 inline-flex items-center gap-1.5 text-[13.5px] font-bold text-[#1257d0] transition hover:text-[#0b3f9e]"
            >
              <svg viewBox="0 0 24 24" className="size-4 transition-transform duration-300 group-hover:-translate-y-0.5" fill="none" stroke="currentColor" strokeWidth={2.5} strokeLinecap="round" strokeLinejoin="round" aria-hidden>
                <path d="M12 16V4m0 0L8 8m4-4 4 4" />
                <path d="M4 15v3a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-3" />
              </svg>
              <span className="relative">
                {copied ? "Link copied ✓" : "Share this phone"}
                <span className="absolute -bottom-0.5 left-0 h-[2px] w-0 rounded-full bg-[#1257d0] transition-all duration-300 group-hover:w-full" />
              </span>
              <span className="translate-x-0 opacity-0 transition-all duration-300 group-hover:translate-x-1 group-hover:opacity-100">
                →
              </span>
            </button>

          <section className="mt-4 overflow-hidden rounded-3xl bg-gradient-to-br from-[#1257d0] via-[#1a6fe0] to-[#3b8ef5] p-[3px] shadow-lg shadow-sky-900/10">
            <div className="rounded-[21px] bg-gradient-to-br from-white via-white to-sky-50 px-3 py-4 sm:px-7 sm:py-6">
              <h2 className="mb-3 text-[13px] font-black uppercase tracking-wide text-[#0b3f9e]">
                Full specification
              </h2>
              <div className="grid gap-x-10 sm:grid-cols-2">
                {(
                  [
                    ["Make", phone.brand === "Apple" ? "Apple" : phone.brand],
                    ["Model", phone.model],
                    ["Condition", CONDITION_LABEL[phone.condition]],
                    ["Storage", variant?.storage ?? "—"],
                    ["Colour", colour],
                    phone.grade ? ["Cosmetic grade", phone.grade] : null,
                    phone.battery ? ["Battery health", `${phone.battery}%`] : null,
                    ["Warranty", isRefurb ? "6 months" : "2 months"],
                    ["Returns", "3 days"],
                    ["Delivery", "Free in Cape Town"],
                  ].filter(Boolean) as [string, string][]
                ).map(([k, val]) => (
                  <div
                    key={k}
                    className="flex items-center justify-between gap-4 border-b border-sky-100 py-2.5 last:border-0"
                  >
                    <span className="text-[13.5px] text-neutral-500">{k}</span>
                    <span className="text-right text-[14px] font-bold text-neutral-900">
                      {val}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          </section>

            {phone.description && (
              <Description text={phone.description} className="mt-5 md:hidden" />
            )}


            <ul className="mt-4 grid gap-2 sm:grid-cols-2">
              {PROMISES.map(p => (
                <li
                  key={p.title}
                  className="rounded-2xl bg-sky-50/70 p-3 ring-1 ring-sky-100"
                >
                  <p className="text-[13px] font-black text-slate-800">
                    {p.title}
                  </p>
                  <p className="mt-0.5 text-[12px] text-sky-800/70">
                    {p.body}
                  </p>
                </li>
              ))}
            </ul>
          </div>
        </div>


      </main>

      <div className="sticky bottom-0 z-30 border-t border-black/5 bg-white/95 p-2.5 backdrop-blur md:hidden">
        <div className="flex gap-2">
          <a
            href={waLink(orderMessage)}
            target="_blank"
            rel="noreferrer"
            className="flex flex-1 items-center justify-center gap-2 rounded-2xl bg-[#25d366] py-3 text-sm font-bold text-white"
          >
            <WhatsAppIcon /> WhatsApp
          </a>
          <a
            href={`tel:${PHONE_DIAL}`}
            aria-label={`Call ${PHONE_DISPLAY}`}
            className="flex items-center justify-center gap-2 rounded-2xl border-2 border-[#1257d0] px-5 py-3 text-sm font-bold text-[#1257d0]"
          >
            <PhoneIcon /> Call
          </a>
        </div>
      </div>

      <ShopFooter />
    </div>
  );
}


/**
 * Colour row under the model name. Colours we actually list are links; the
 * rest of that model's real colour range can be asked for on WhatsApp, so a
 * customer never has to go back and hunt.
 */
function ColourPicker({
  phone,
  siblings,
  chosen,
  onChoose,
}: {
  phone: Phone;
  siblings: Phone[];
  chosen: string;
  onChoose: (c: string) => void;
}) {
  const [showAll, setShowAll] = useState(false);
  const listed = new Map(siblings.map(p => [p.colour.toLowerCase(), p]));
  const range = coloursFor(phone.brand);
  const all = [
    phone.colour,
    ...siblings.map(p => p.colour),
    ...range,
  ].filter(
    (c, i, arr) =>
      arr.findIndex(o => o.toLowerCase() === c.toLowerCase()) === i,
  );
  const shown = showAll ? all : all.slice(0, 6);
  if (all.length <= 1) return null;

  return (
    <div className="flex flex-wrap items-center gap-1.5">
      {shown.map(c => {
        const active = c.toLowerCase() === chosen.toLowerCase();
        const match = listed.get(c.toLowerCase());
        const isThisListing = c.toLowerCase() === phone.colour.toLowerCase();
        return (
          <button
            key={c}
            type="button"
            title={
              isThisListing || match
                ? `${c} — we have this one`
                : `${c} — we will source this colour`
            }
            aria-label={c}
            aria-pressed={active}
            onClick={() => {
              onChoose(c);
              // If this colour is a listing of its own, show that listing —
              // its own photos and price are the honest ones.
              // Nothing else happens. Jumping to another listing changed the
              // photos under the customer and was confusing; the colour is
              // simply recorded and carried into the WhatsApp message.
            }}
            className={`size-7 rounded-full transition active:scale-90 ${
              active
                ? "ring-[3px] ring-[#1257d0] ring-offset-2"
                : isThisListing || match
                  ? "ring-2 ring-black/15 hover:ring-[#1257d0]"
                  : "opacity-70 ring-2 ring-dashed ring-black/20 hover:opacity-100"
            }`}
            style={{ backgroundColor: colourHex(c) }}
          />
        );
      })}
      {all.length > 6 && (
        <button
          type="button"
          onClick={() => setShowAll(v => !v)}
          className="rounded-full bg-white px-2.5 py-1 text-[11.5px] font-bold text-[#1257d0] ring-1 ring-black/10"
        >
          {showAll ? "fewer colours" : `+${all.length - 6} more colours`}
        </button>
      )}
    </div>
  );
}
